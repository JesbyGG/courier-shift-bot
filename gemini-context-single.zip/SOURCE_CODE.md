﻿# SOURCE CODE

All JavaScript/JSON source files of courier-shift-bot.


---

## FILE: package.json

```javascript
{
  "name": "courier-shift-bot",
  "version": "1.0.0",
  "description": "Telegram bot for courier shifts, mileage tracking and odometer photo forwarding.",
  "main": "bot.js",
  "scripts": {
    "start": "node bot.js",
    "dev": "nodemon bot.js",
    "test": "node tests/run.js"
  },
  "dependencies": {
    "axios": "^1.7.9",
    "better-sqlite3": "^12.10.0",
    "docx": "^9.6.1",
    "dotenv": "^16.4.7",
    "google-auth-library": "^9.15.1",
    "https-proxy-agent": "^7.0.6",
    "socks-proxy-agent": "^8.0.5",
    "telegraf": "^4.16.3"
  },
  "devDependencies": {
    "nodemon": "^3.1.9"
  }
}

```


---

## FILE: .env.example

```javascript
# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ
# РљСѓСЂСЊРµСЂСЃРєРёР№ Р±РѕС‚ вЂ” РїРµСЂРµРјРµРЅРЅС‹Рµ РѕРєСЂСѓР¶РµРЅРёСЏ
# РЎРєРѕРїРёСЂСѓР№С‚Рµ СЌС‚РѕС‚ С„Р°Р№Р» РІ .env Рё Р·Р°РїРѕР»РЅРёС‚Рµ Р·РЅР°С‡РµРЅРёСЏ РґР»СЏ СЃРІРѕРµРіРѕ СЃРµСЂРІРµСЂР°.
# в”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђв”Ђ

# === Telegram ===
# РўРѕРєРµРЅ Р±РѕС‚Р° РѕС‚ @BotFather (РѕР±СЏР·Р°С‚РµР»СЊРЅРѕ)
BOT_TOKEN=

# Telegram-IDs Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂРѕРІ С‡РµСЂРµР· Р·Р°РїСЏС‚СѓСЋ (РЅР°РїСЂРёРјРµСЂ: 12345,67890)
# РўРѕР»СЊРєРѕ РѕРЅРё РІРёРґСЏС‚ /sheet, /sheet_access, /chatid Рё РїРѕР»СѓС‡Р°СЋС‚
# СѓРІРµРґРѕРјР»РµРЅРёСЏ Рѕ РЅРѕРІС‹С… РїРѕР»СЊР·РѕРІР°С‚РµР»СЏС… Рё РѕР±РЅРѕРІР»РµРЅРёСЏС… Р±РѕС‚Р°.
ADMIN_IDS=

# РџСЂРѕРєСЃРё РґР»СЏ Telegram (РѕРїС†РёРѕРЅР°Р»СЊРЅРѕ). РџРѕРґРґРµСЂР¶РёРІР°РµС‚ HTTP/HTTPS/SOCKS5.
# РџСЂРёРјРµСЂ: socks5://user:pass@host:1080
TELEGRAM_PROXY_URL=

# === Р§Р°С‚С‹ РґР»СЏ РїРµСЂРµСЃС‹Р»РєРё С„РѕС‚Рѕ (РѕРїС†РёРѕРЅР°Р»СЊРЅРѕ) ===
# WORK_CHAT_ID вЂ” РєСѓРґР° СѓС…РѕРґСЏС‚ С„РѕС‚Рѕ РїСЂРѕР±РµРіР°
# ROUTE_SHEET_CHAT_ID вЂ” С„РѕС‚Рѕ РјР°СЂС€СЂСѓС‚РЅС‹С… Р»РёСЃС‚РѕРІ
# RECONCILIATION_CHAT_ID вЂ” С„РѕС‚Рѕ СЃРІРµСЂРѕРє (РўРµСЂРјРёРЅР°Р»/РџРёРЅ-РџР°РЅРµР»СЊ)
# THREAD_ID вЂ” id С‚РѕРїРёРєР° РІ С‡Р°С‚Рµ СЃ С‚РѕРїРёРєР°РјРё (РѕРїС†РёРѕРЅР°Р»СЊРЅРѕ)
# Р•СЃР»Рё ROUTE_SHEET_CHAT_ID РёР»Рё RECONCILIATION_CHAT_ID РЅРµ Р·Р°РґР°РЅС‹ вЂ”
# С„РѕС‚Рѕ СѓС…РѕРґСЏС‚ РІ WORK_CHAT_ID РєР°Рє fallback.
WORK_CHAT_ID=
WORK_THREAD_ID=
ROUTE_SHEET_CHAT_ID=
ROUTE_SHEET_THREAD_ID=
RECONCILIATION_CHAT_ID=
RECONCILIATION_THREAD_ID=

# РљСѓРґР° РѕС‚РїСЂР°РІР»СЏС‚СЊ СѓРІРµРґРѕРјР»РµРЅРёСЏ РѕР± РѕС‚РєСЂС‹С‚РёРё/Р·Р°РєСЂС‹С‚РёРё РјР°РіР°Р·РёРЅР° (id РіСЂСѓРїРїС‹)
SHOP_STATUS_CHAT_ID=

# === Google Sheets ===
# РЎРµСЂРІРёСЃРЅС‹Р№ Р°РєРєР°СѓРЅС‚ РґР»СЏ РґРѕСЃС‚СѓРїР° Рє Google Sheets API.
# РЎРѕР·РґР°С‘С‚СЃСЏ РІ Google Cloud Console, РїРѕС‚РѕРј РЅР°РґРѕ РґР°С‚СЊ РµРіРѕ e-mail
# РґРѕСЃС‚СѓРї "Editor" Рє РЅСѓР¶РЅС‹Рј С‚Р°Р±Р»РёС†Р°Рј.
GOOGLE_SHEET_ID=
GOOGLE_SERVICE_ACCOUNT_EMAIL=
GOOGLE_PRIVATE_KEY=

# Р§Р°СЃРѕРІРѕР№ РїРѕСЏСЃ РґР»СЏ СЂР°СЃС‡С‘С‚Р° РґРЅСЏ СЃРјРµРЅС‹ Рё РѕРєСЂСѓРіР»РµРЅРёСЏ РІСЂРµРјРµРЅРё
APP_TIMEZONE=Europe/Moscow

# === OCR вЂ” СЂР°СЃРїРѕР·РЅР°РІР°РЅРёРµ РїСЂРѕР±РµРіР° РїРѕ С„РѕС‚Рѕ ===
# RapidOCR (Р·Р°РїСѓСЃРєР°РµС‚СЃСЏ РєР°Рє Р»РѕРєР°Р»СЊРЅС‹Р№ HTTP-СЃРµСЂРІРµСЂ РЅР° VPS)
RAPIDOCR_ENABLED=true
RAPIDOCR_URL=http://127.0.0.1:9527

# Р’Р°Р»РёРґР°С†РёСЏ СЂР°СЃРїРѕР·РЅР°РЅРЅРѕРіРѕ Р·РЅР°С‡РµРЅРёСЏ
OCR_MIN_MILEAGE=1000          # РјРёРЅРёРјР°Р»СЊРЅРѕ РґРѕРїСѓСЃС‚РёРјС‹Р№ РїСЂРѕР±РµРі РІ РєРј
OCR_MAX_SHIFT_DELTA=800       # РјР°РєСЃРёРјР°Р»СЊРЅС‹Р№ РїСЂРёСЂРѕСЃС‚ РїСЂРѕР±РµРіР° Р·Р° СЃРјРµРЅСѓ РІ РєРј

# РџРѕСЂРѕРіРё СѓРІРµСЂРµРЅРЅРѕСЃС‚Рё OCR вЂ” РєР°РЅРґРёРґР°С‚ РґРѕР»Р¶РµРЅ РїСЂРѕР№С‚Рё РѕР±Р°
RAPIDOCR_MIN_COUNT=1          # РјРёРЅРёРјСѓРј СЂР°Р·РЅС‹С… СЂР°СЃРїРѕР·РЅР°РІР°РЅРёР№ РѕРґРЅРѕРіРѕ С‡РёСЃР»Р°
RAPIDOCR_MIN_AVG_CONF=0.40   # СЃСЂРµРґРЅСЏСЏ СѓРІРµСЂРµРЅРЅРѕСЃС‚СЊ
RAPIDOCR_MIN_MAX_CONF=0.50   # РјР°РєСЃРёРјР°Р»СЊРЅР°СЏ СѓРІРµСЂРµРЅРЅРѕСЃС‚СЊ

# === UX-РЅР°СЃС‚СЂРѕР№РєРё ===
# РўРѕРЅ СЃРѕРѕР±С‰РµРЅРёР№: false = РґРµР»РѕРІРѕР№ (РїРѕ СѓРјРѕР»С‡Р°РЅРёСЋ), true = СЃ С€СѓС‚РєР°РјРё
# (В«РљРѕС‚РѕРєРѕРЅС‚СЂРѕР»СЊ РЅРµ РґСЂРµРјР»РµС‚В», В«РђР№-Р°Р№, РґРµРЅСЋР¶РєРёВ» Рё РїСЂ.)
FUN_TONE=false

# РљР°СЃС‚РѕРјРЅС‹Рµ РїСѓРЅРєС‚С‹ РІ СѓРІРµРґРѕРјР»РµРЅРёРё РѕР± РѕР±РЅРѕРІР»РµРЅРёРё (С‡РµСЂРµР· СЃРёРјРІРѕР» "|")
# РџСЂРёРјРµСЂ: UPDATE_NOTES=РџРѕС‡РёРЅРёР»Рё Р±Р°Рі X|РЈСЃРєРѕСЂРёР»Рё Y|Р”РѕР±Р°РІРёР»Рё Z
UPDATE_NOTES=

# === РЎС‚РёРєРµСЂ- Рё GIF-СЂРµР°РєС†РёРё (РЅРµРѕР±СЏР·Р°С‚РµР»СЊРЅРѕ) ===
# РџРѕ СѓРјРѕР»С‡Р°РЅРёСЋ РІС‹РєР»СЋС‡РµРЅС‹. Р’РєР»СЋС‡Р°СЋС‚СЃСЏ С‚РѕР»СЊРєРѕ РµСЃР»Рё РµСЃС‚СЊ РєРѕРЅС‚РµРЅС‚ РІ
# РєР°РєРѕРј-Р»РёР±Рѕ РёР· СЃРїРёСЃРєРѕРІ РЅРёР¶Рµ.
FUN_REACTIONS_ENABLED=false
FUN_REACTION_COOLDOWN_MS=30000
FUN_IMPORT_STICKER_SETS=true
FUN_STICKER_SETS=https://t.me/addstickers/TikTok_cats_animals
FUN_ERROR_STICKERS=
FUN_ERROR_GIFS=
FUN_SUCCESS_STICKERS=
FUN_SUCCESS_GIFS=

# === РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј вЂ” СЃСЃС‹Р»РєРё РЅР° С‡Р°С‚С‹ ===
# РџСЂРё РЅР°Р¶Р°С‚РёРё РєРЅРѕРїРєРё В«РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРјВ» Р±РѕС‚ РїРѕРєР°Р·С‹РІР°РµС‚ inline-РєРЅРѕРїРєРё
# СЃ СЃСЃС‹Р»РєР°РјРё РЅР° РЅСѓР¶РЅС‹Рµ С‡Р°С‚С‹. Р•СЃР»Рё URL РЅРµ Р·Р°РґР°РЅ вЂ” РєРЅРѕРїРєР° РЅРµ РїРѕРєР°Р·С‹РІР°РµС‚СЃСЏ.
ISSUE_DELIVERY_URL=https://t.me/c/1703163982/1
ISSUE_FLOWWOW_URL=https://t.me/c/1703163982/182754
ISSUE_TECHSUPPORT_URL=https://t.me/HelpRetail_bot

# РћС‚РєР»СЋС‡РµРЅРёРµ Р±РѕС‚Р° (РґР»СЏ Р»РѕРєР°Р»СЊРЅРѕР№ СЂР°Р·СЂР°Р±РѕС‚РєРё)
# BOT_DISABLED=true вЂ” Р±РѕС‚ РЅРµ РїРѕРґРєР»СЋС‡Р°РµС‚СЃСЏ Рє Telegram (Р±РµР·РѕРїР°СЃРЅРѕ РґР»СЏ Р»РѕРєР°Р»СЊРЅРѕРіРѕ Р·Р°РїСѓСЃРєР°)

```


---

## FILE: version.json

```javascript
{
  "version": "2.4.1",
  "lastHash": "2673fafe7b30eb9ed111583e55dd33f6ebb2f0cd28293357f460ee480403abc3",
  "files": {
    "bot.js": "53499ddcfb47e7ed6f78f9300da171d6b862ec0732fa49c53b25236102d43e69",
    "check_tables.js": "be6be30a6655c0802ed994260d0b22acce22b90ae1cf63b3ec1898e9565da5a4",
    "config.js": "4953df93a7cbfcbe3187d18b6c121a7dc3cbba72a0ae64874d04bab5f3cbc495",
    "db.js": "c9965a821855897fddeb1a0272248ff887e89122b96b679f60e00167599950cd",
    "ecosystem.config.js": "1306e135e7da044054dfac7ff27d6e2df7cd02d9ce3380ede050e7af683c7a8f",
    "fix_db.js": "f28b56759d8df92bd386033747fce6227d24a9d4746f6dc8dfadcf057e44afad",
    "logger.js": "462ab85a6796741b062b71e67cb0ddbe04d705e616f57a59014bba7acd1626f2",
    "sheetCommand.js": "41bcd024a670eebee7b2dabb77b515ac6200aeb302ea8847f4081573c0c392c1",
    "utils.js": "db7ba8ba0da85d9e35b21b3697fbeb8fef8edf44244a8d0a05e69b117d714642"
  },
  "updatedAt": "2026-05-21T11:36:30.163Z",
  "gitHash": "9b24682039ee6517cc6ed0339ff9ea78727be824",
  "updates": [
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Background OCR does not stop on back_to_menu",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Background OCR СЃРѕС…СЂР°РЅСЏРµС‚ СЂРµР·СѓР»СЊС‚Р°С‚ РґР°Р¶Рµ РїСЂРё РЅР°Р¶Р°С‚РёРё РєРЅРѕРїРѕРє",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Background OCR processing + ocr_debug photo saving",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Р—Р°С‰РёС‚Р° РїРѕРґС‚РІРµСЂР¶РґРµРЅРёСЏ РЅР°Р»РёС‡РЅС‹С… + РґРѕСЂР°Р±РѕС‚РєРё OCR СЃРІРµСЂРєРё",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Notifications v2 - fix first record/overtake bugs, add workplace record, daily leader, top3 change, notification settings",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Add weekly challenges button to leaderboard menu",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Add missing imports for achievements and streak getters",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Add pedestrian couriers, XP ranks, achievements, streaks, challenges, leaderboard 2.0",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Add pedestrian couriers, XP ranks, achievements, streaks, challenges, leaderboard 2.0",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: РџРѕРґС‚РІРµСЂР¶РґРµРЅРёРµ РїРµСЂРµРґ РїСЂРѕРїСѓСЃРєРѕРј РїСЂРѕР±РµРіР°, СѓРґР°Р»С‘РЅ dead code OCR",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Р”РѕР±Р°РІР»РµРЅ isSheetAccessUser РёРјРїРѕСЂС‚ РІ menus/keyboards.js",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: РџРµСЂРµРЅРѕСЃ BUTTONS РІ config.js, РёСЃРїСЂР°РІР»РµРЅ settingsMenu",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Р”РѕР±Р°РІР»РµРЅ WORKPLACE_KEY_MAP РІ РёРјРїРѕСЂС‚ bot.js",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: РћС‚РґРµР»СЊРЅР°СЏ С‚Р°Р±Р»РёС†Р° pending_cash СЃ РёРЅРґРµРєСЃРѕРј РїРѕ workplace, РјРёРіСЂР°С†РёСЏ РёР· users.data",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Р”РёРЅР°РјРёС‡РµСЃРєРёРµ РјР°РіР°Р·РёРЅС‹ С‡РµСЂРµР· WORKPLACE_FEATURES, СѓР±СЂР°РЅ С…Р°СЂРґРєРѕРґ Р’РѕСЃС‚РѕРє/Р¦РµРЅС‚СЂ",
    "в™»пёЏ РџРµСЂРµСЂР°Р±РѕС‚Р°РЅРѕ: Р’С‹РЅРѕСЃ РєР»Р°РІРёР°С‚СѓСЂ РІ menus/keyboards.js, auth РІ services/auth.js, С‚РёС…РёРµ РѕС€РёР±РєРё СЃРІРµСЂРєРё",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Pending updates persistence across restarts",
    "рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ: Cash_submit_no undefined telegramId",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: РњРµРЅСЋ Р»РѕРіРёСЃС‚РѕРІ РїРѕ РјР°РіР°Р·РёРЅСѓ, Р¤РРћ РІ Р»СЋР±РѕРј РїРѕСЂСЏРґРєРµ, С†РµРЅС‚СЂ-Р»РѕРіРёСЃС‚РёРєР°, РїРѕРјРѕС‰СЊ РїРѕ СЂРѕР»СЏРј",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: BOT_DISABLED env flag for local dev",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Р СѓСЃСЃРєРёРµ РїСЂРµС„РёРєСЃС‹ РІ СѓРІРµРґРѕРјР»РµРЅРёСЏС… РѕР± РѕР±РЅРѕРІР»РµРЅРёСЏС…",
    "рџ”§ РўРµС…РЅРёС‡РµСЃРєРѕРµ: Revert test comment",
    "рџ”§ РўРµС…РЅРёС‡РµСЃРєРѕРµ: Add version header comment",
    "вњЁ Р”РѕР±Р°РІР»РµРЅРѕ: Auto-generate update notes from git commit history"
  ]
}
```


---

## FILE: config.js

```javascript
// Р¦РµРЅС‚СЂР°Р»РёР·РѕРІР°РЅРЅС‹Рµ РєРѕРЅСЃС‚Р°РЅС‚С‹ Рё РјР°РіРёС‡РµСЃРєРёРµ С‡РёСЃР»Р°.
// Р Р°РЅСЊС€Рµ Р±С‹Р»Рё СЂР°Р·Р±СЂРѕСЃР°РЅС‹ РїРѕ bot.js / storage.js / googleSheets.js вЂ” РїСЂРё
// РёР·РјРµРЅРµРЅРёСЏС… Р»РµРіРєРѕ Р·Р°Р±С‹С‚СЊ СЃРёРЅС…СЂРѕРЅРёР·РёСЂРѕРІР°С‚СЊ. РўРµРїРµСЂСЊ вЂ” РµРґРёРЅР°СЏ С‚РѕС‡РєР° РёСЃС‚РёРЅС‹.

const WORKPLACES = ['РРњ Р’РѕСЃС‚РѕРє', 'РРњ Р¦РµРЅС‚СЂ'];
const DEVICES = ['РўРµСЂРјРёРЅР°Р»', 'РџРёРЅ-РџР°РЅРµР»СЊ'];
const ROLES = ['РљСѓСЂСЊРµСЂ', 'Р›РѕРіРёСЃС‚'];

// РњР°РїРїРёРЅРі СЂСѓСЃСЃРєРёС… РЅР°Р·РІР°РЅРёР№ РјР°РіР°Р·РёРЅРѕРІ РІ РєРѕСЂРѕС‚РєРёРµ РєР»СЋС‡Рё (РґР»СЏ storage / sheet IDs).
const WORKPLACE_KEY_MAP = {
  'РРњ Р’РѕСЃС‚РѕРє': 'east',
  'РРњ Р¦РµРЅС‚СЂ': 'center'
};

// Р¤РёС‡Рё РїРѕ РјР°РіР°Р·РёРЅР°Рј (С‡С‚РѕР±С‹ РЅРµ С…Р°СЂРґРєРѕРґРёС‚СЊ 'РРњ Р’РѕСЃС‚РѕРє' / 'РРњ Р¦РµРЅС‚СЂ' РІ Р±РёР·РЅРµСЃ-Р»РѕРіРёРєРµ).
// Р”РѕР±Р°РІР»СЏСЏ РЅРѕРІС‹Р№ РјР°РіР°Р·РёРЅ вЂ” РїСЂРѕСЃС‚Рѕ СѓРєР°Р¶Рё Р·РґРµСЃСЊ, РєР°РєРёРµ С„СѓРЅРєС†РёРё РґРѕСЃС‚СѓРїРЅС‹.
const WORKPLACE_FEATURES = {
  'РРњ Р’РѕСЃС‚РѕРє': { cashCollection: true, leaderboard: true },
  'РРњ Р¦РµРЅС‚СЂ': { cashCollection: false, leaderboard: true }
};

// Р–С‘СЃС‚РєРёРµ РѕРіСЂР°РЅРёС‡РµРЅРёСЏ РѕРєСЂСѓР¶РµРЅРёСЏ. РњРѕР¶РЅРѕ РїРµСЂРµРѕРїСЂРµРґРµР»СЏС‚СЊ С‡РµСЂРµР· .env.
const LIMITS = {
  // РњР°РєСЃРёРјР°Р»СЊРЅС‹Р№ РѕР±СЉС‘Рј С„Р°Р№Р»Р° Р»РѕРіР° РЅР° РґРёСЃРєРµ (50 MB)
  MAX_LOG_SIZE_BYTES: 50 * 1024 * 1024,

  // РљРѕР»-РІРѕ OCR feedback-Р·Р°РїРёСЃРµР№ РІ С„Р°Р№Р»Рµ
  MAX_OCR_FEEDBACK: 500,

  // РђРІС‚Рѕ-Р±СЌРєР°РїС‹ РґР°РЅРЅС‹С…
  BACKUP_INTERVAL_MS: 60 * 60 * 1000, // РєР°Р¶РґС‹Р№ С‡Р°СЃ
  BACKUP_RETENTION_MS: 7 * 24 * 60 * 60 * 1000, // С…СЂР°РЅРёРј 7 РґРЅРµР№

  // РћС‡РёСЃС‚РєР° in-memory РєСЌС€Р° cooldown'РѕРІ С„Р°РЅ-СЂРµР°РєС†РёР№
  FUN_REACTION_CLEANUP_INTERVAL_MS: 3600000,

  // Р›РёРјРёС‚ caption Сѓ Telegram (РќР• 4096 вЂ” СЌС‚Рѕ Р»РёРјРёС‚ РґР»СЏ С‚РµРєСЃС‚Р°)
  TELEGRAM_CAPTION_LIMIT: 1024,

  // Р Р°Р·РјРµСЂС‹ РїСЂРѕР±РµРіР° РІ РєРј (РІР°Р»РёРґР°С†РёСЏ)
  MILEAGE_MIN_DIGITS: 2,
  MILEAGE_MAX_DIGITS: 6,

  // Р”Р»РёРЅР° РіРѕСЃ. РЅРѕРјРµСЂР° РјР°С€РёРЅС‹
  CAR_NUMBER_MIN_LENGTH: 4,
  CAR_NUMBER_MAX_LENGTH: 12,

  // Р—Р°РїСѓСЃРє Р±РѕС‚Р° вЂ” РїР°СЂР°РјРµС‚СЂС‹ СЂРµС‚СЂР°СЏ
  LAUNCH_RETRIES: 10,
  LAUNCH_BASE_DELAY_MS: 5000,
  LAUNCH_MAX_DELAY_MS: 120000
};

// РЁР°Р±Р»РѕРЅ Google Sheets вЂ” РєРѕР»РѕРЅРєРё Рё Р±Р»РѕРєРё. Р•СЃР»Рё РІ С‚Р°Р±Р»РёС†Рµ РјРµРЅСЏРµС‚СЃСЏ
// СЃС‚СЂСѓРєС‚СѓСЂР° (РґРѕР±Р°РІРёР»Рё/СѓР±СЂР°Р»Рё РєРѕР»РѕРЅРєСѓ), РїСЂР°РІРёС‚СЃСЏ Р·РґРµСЃСЊ.
const SHEET_TEMPLATE = {
  // РљСѓСЂСЊРµСЂС‹: РєРѕР»РѕРЅРєРё (start, end, hours) РїРѕРІС‚РѕСЂСЏСЋС‚СЃСЏ Р±Р»РѕРєР°РјРё РїРѕ 3
  // РЅР°С‡РёРЅР°СЏ СЃ РґРЅСЏ 1. Р”РµРЅСЊ 1 в†’ СЃС‚Р°СЂС‚=6 (F), РєРѕРЅРµС†=7 (G), С‡Р°СЃС‹=8 (H).
  courier: {
    firstDayStartCol: 6,
    blockSize: 3,
    fioStartRow: 3 // РїРµСЂРІР°СЏ СЃС‚СЂРѕРєР° СЃ РґР°РЅРЅС‹РјРё РєСѓСЂСЊРµСЂР° (РїРѕСЃР»Рµ Р·Р°РіРѕР»РѕРІРєРѕРІ)
  },
  // РџСЂРѕР±РµРі: Р±Р»РѕРєРё (start, end, total) СЃ РєРѕР»РѕРЅРєРё 4 (D)
  mileage: {
    firstDayStartCol: 4,
    blockSize: 3,
    fioStartRow: 3
  }
};

const BUTTONS = {
  punchTime: 'вЏ± Р—Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ',
  mileage: 'рџљ— Р¤РѕС‚Рѕ РїСЂРѕР±РµРіР°',
  routeSheet: 'рџ“„ РћС‚РїСЂР°РІРёС‚СЊ РјР°СЂС€СЂСѓС‚РЅРёРє',
  reconciliation: 'рџ“Љ РћС‚РїСЂР°РІРёС‚СЊ СЃРІРµСЂРєСѓ',
  cashCheck: 'рџ’µ РЎРґР°С‚СЊ РЅР°Р»РёС‡РЅС‹Рµ',
  issues: 'вљ пёЏ РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј',
  leaderBoard: 'рџЏ† Р РµР№С‚РёРЅРі',
  settings: 'вљ™пёЏ РќР°СЃС‚СЂРѕР№РєРё',
  help: 'вќ“ РџРѕРјРѕС‰СЊ',
  profile: 'вњЏпёЏ РџСЂРѕС„РёР»СЊ',
  changeCar: 'вњЏпёЏ РР·РјРµРЅРёС‚СЊ РЅРѕРјРµСЂ РјР°С€РёРЅС‹',
  changeWorkplace: 'вњЏпёЏ РџРѕРјРµРЅСЏС‚СЊ РјР°РіР°Р·РёРЅ',
  changeDevice: 'вњЏпёЏ РР·РјРµРЅРёС‚СЊ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ',
  switchUser: 'вњЏпёЏ РџРѕРјРµРЅСЏС‚СЊ СЃРѕС‚СЂСѓРґРЅРёРєР°',
  sheetInfo: 'рџ“‹ РўР°Р±Р»РёС†С‹',
  myId: 'рџ†” РњРѕР№ ID',
  cashCollect: 'рџ’і РџСЂРёРЅСЏС‚СЊ РЅР°Р»РёС‡РЅС‹Рµ',
  cashHistory: 'рџ“‹ РСЃС‚РѕСЂРёСЏ СЃР±РѕСЂРѕРІ',
  openShop: 'рџ”“ РћС‚РєСЂС‹С‚СЊ РРњ',
  backToSettings: 'в†©пёЏ Рљ РЅР°СЃС‚СЂРѕР№РєР°Рј',
  back: 'рџЏ  Р’ РјРµРЅСЋ'
};

// РРјСЏ С„Р°Р№Р»Р°, РІ РєРѕС‚РѕСЂС‹Р№ РїРµСЂРµРёРјРµРЅРѕРІС‹РІР°СЋС‚СЃСЏ Р±РёС‚С‹Рµ С„Р°Р№Р»С‹ РїСЂРё Р·Р°РіСЂСѓР·РєРµ.
const STORAGE_BROKEN_SUFFIX = '.broken';

module.exports = {
  WORKPLACES,
  DEVICES,
  ROLES,
  WORKPLACE_KEY_MAP,
  WORKPLACE_FEATURES,
  LIMITS,
  SHEET_TEMPLATE,
  BUTTONS,
  STORAGE_BROKEN_SUFFIX
};

```


---

## FILE: db.js

```javascript
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'database.sqlite');
const dbDir = __dirname;
const backupsDir = path.join(dbDir, 'backups');

function findLatestBackup() {
  if (!fs.existsSync(backupsDir)) return null;
  const files = fs.readdirSync(backupsDir)
    .filter(f => f.startsWith('database.sqlite-') && !f.endsWith('.shm') && !f.endsWith('.wal'))
    .sort()
    .reverse();
  if (files.length === 0) return null;
  return path.join(backupsDir, files[0]);
}

function tryRestoreFromBackup() {
  const backup = findLatestBackup();
  if (!backup) {
    console.error('No valid backup found, creating fresh database');
    return false;
  }
  console.log(`Attempting to restore from backup: ${path.basename(backup)}`);
  try {
    const tmpDb = new Database(backup);
    const result = tmpDb.pragma('integrity_check', { simple: true });
    tmpDb.close();
    if (result !== 'ok') {
      console.error(`Backup ${path.basename(backup)} is also corrupt, trying older backup`);
      const allFiles = fs.readdirSync(backupsDir)
        .filter(f => f.startsWith('database.sqlite-') && !f.endsWith('.shm') && !f.endsWith('.wal'))
        .sort()
        .reverse();
      for (const file of allFiles) {
        if (file === path.basename(backup)) continue;
        const filePath = path.join(backupsDir, file);
        try {
          const testDb = new Database(filePath);
          const r = testDb.pragma('integrity_check', { simple: true });
          testDb.close();
          if (r === 'ok') {
            console.log(`Found valid backup: ${file}`);
            fs.copyFileSync(filePath, dbPath);
            return true;
          }
        } catch (_) {}
      }
      return false;
    }
    fs.copyFileSync(backup, dbPath);
    console.log('Database restored from backup');
    return true;
  } catch (e) {
    console.error('Backup restore failed:', e.message);
    return false;
  }
}

function checkpointAndClose(db) {
  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
  } catch (_) {}
  try {
    db.close();
  } catch (_) {}
  const shmPath = dbPath + '-shm';
  const walPath = dbPath + '-wal';
  if (fs.existsSync(shmPath)) fs.unlinkSync(shmPath);
  if (fs.existsSync(walPath)) fs.unlinkSync(walPath);
}

let db;
try {
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  const integrity = db.pragma('integrity_check', { simple: true });
  if (integrity !== 'ok') {
    console.error(`Database integrity check failed: ${integrity}. Attempting recovery...`);
    checkpointAndClose(db);
    if (tryRestoreFromBackup()) {
      db = new Database(dbPath);
      db.pragma('journal_mode = WAL');
      db.pragma('wal_autocheckpoint = 1000');
      db.pragma('synchronous = FULL');
    } else {
      console.error('All backups corrupt, creating fresh database');
      db = new Database(dbPath);
      db.pragma('journal_mode = WAL');
      db.pragma('wal_autocheckpoint = 1000');
      db.pragma('synchronous = FULL');
    }
  }
} catch (e) {
  if (e.message.includes('corrupt') || e.message.includes('malformed')) {
    console.error(`Database corrupt on open: ${e.message}. Attempting recovery...`);
    const shmPath = dbPath + '-shm';
    const walPath = dbPath + '-wal';
    if (fs.existsSync(shmPath)) fs.unlinkSync(shmPath);
    if (fs.existsSync(walPath)) fs.unlinkSync(walPath);
    if (tryRestoreFromBackup()) {
      db = new Database(dbPath);
      db.pragma('journal_mode = WAL');
      db.pragma('wal_autocheckpoint = 1000');
      db.pragma('synchronous = FULL');
    } else {
      console.error('All backups corrupt, creating fresh database');
      db = new Database(dbPath);
      db.pragma('journal_mode = WAL');
      db.pragma('wal_autocheckpoint = 1000');
      db.pragma('synchronous = FULL');
    }
  } else {
    throw e;
  }
}

// Initialize tables
db.pragma('journal_mode = WAL');
db.pragma('wal_autocheckpoint = 1000');
db.pragma('synchronous = FULL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    telegramId TEXT PRIMARY KEY,
    data TEXT
  );
  
  CREATE TABLE IF NOT EXISTS states (
    telegramId TEXT PRIMARY KEY,
    data TEXT
  );
  
  CREATE TABLE IF NOT EXISTS leaderboard (
    telegramId TEXT PRIMARY KEY,
    data TEXT
  );

  CREATE TABLE IF NOT EXISTS cash_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    logistId TEXT,
    logistFio TEXT,
    courierId TEXT NOT NULL,
    courierFio TEXT NOT NULL,
    workplace TEXT NOT NULL,
    amount REAL NOT NULL,
    action TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS pending_cash (
    telegramId TEXT PRIMARY KEY,
    amount REAL NOT NULL DEFAULT 0,
    formatted TEXT,
    orders INTEGER,
    workplace TEXT,
    sourceLabel TEXT,
    confirmationStatus TEXT,
    updatedAt TEXT,
    fileId TEXT
  );

  CREATE INDEX IF NOT EXISTS idx_pending_cash_workplace ON pending_cash(workplace);

  CREATE TABLE IF NOT EXISTS xp_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegramId TEXT,
    amount INTEGER,
    reason TEXT,
    createdAt TEXT
  );

  CREATE TABLE IF NOT EXISTS user_achievements (
    telegramId TEXT,
    achievementId TEXT,
    unlockedAt TEXT,
    PRIMARY KEY (telegramId, achievementId)
  );

  CREATE TABLE IF NOT EXISTS challenges (
    weekId TEXT,
    telegramId TEXT,
    type TEXT,
    target INTEGER,
    current INTEGER DEFAULT 0,
    completed INTEGER DEFAULT 0,
    reward INTEGER,
    PRIMARY KEY (weekId, telegramId, type)
  );

  CREATE TABLE IF NOT EXISTS streaks (
    telegramId TEXT PRIMARY KEY,
    currentStreak INTEGER,
    maxStreak INTEGER,
    lastShiftDate TEXT
  );
`);

// Migration logic
function migrateJsonToSqlite() {
  const usersPath = path.join(__dirname, 'users.json');
  if (fs.existsSync(usersPath)) {
    try {
      const content = fs.readFileSync(usersPath, 'utf8');
      const users = JSON.parse(content);
      const stmt = db.prepare('INSERT OR IGNORE INTO users (telegramId, data) VALUES (?, ?)');
      const insertMany = db.transaction((usersObj) => {
        for (const [id, data] of Object.entries(usersObj)) {
          stmt.run(id, JSON.stringify(data));
        }
      });
      insertMany(users);
      fs.renameSync(usersPath, usersPath + '.migrated');
      console.log('Migrated users.json to SQLite');
    } catch (e) {
      console.error('Migration error for users:', e);
    }
  }

  const statesPath = path.join(__dirname, 'states.json');
  if (fs.existsSync(statesPath)) {
    try {
      const content = fs.readFileSync(statesPath, 'utf8');
      const states = JSON.parse(content);
      const stmt = db.prepare('INSERT OR IGNORE INTO states (telegramId, data) VALUES (?, ?)');
      const insertMany = db.transaction((statesObj) => {
        for (const [id, data] of Object.entries(statesObj)) {
          stmt.run(id, JSON.stringify(data));
        }
      });
      insertMany(states);
      fs.renameSync(statesPath, statesPath + '.migrated');
      console.log('Migrated states.json to SQLite');
    } catch (e) {
      console.error('Migration error for states:', e);
    }
  }

  const lbPath = path.join(__dirname, 'leaderboard-cache.json');
  if (fs.existsSync(lbPath)) {
    try {
      const content = fs.readFileSync(lbPath, 'utf8');
      const cache = JSON.parse(content);
      const records = cache.records || {};
      const stmt = db.prepare('INSERT OR IGNORE INTO leaderboard (telegramId, data) VALUES (?, ?)');
      const insertMany = db.transaction((recordsObj) => {
        for (const [id, data] of Object.entries(recordsObj)) {
          stmt.run(id, JSON.stringify(data));
        }
      });
      insertMany(records);
      fs.renameSync(lbPath, lbPath + '.migrated');
      console.log('Migrated leaderboard-cache.json to SQLite');
    } catch (e) {
      console.error('Migration error for leaderboard:', e);
    }
  }
}

migrateJsonToSqlite();

// Migrate pendingCashToSubmit from users JSON blob to dedicated pending_cash table
function migratePendingCashToTable() {
  const rows = db.prepare('SELECT telegramId, data FROM users').all();
  const stmt = db.prepare(
    'INSERT OR REPLACE INTO pending_cash (telegramId, amount, formatted, orders, workplace, sourceLabel, confirmationStatus, updatedAt, fileId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  const insertMany = db.transaction((items) => {
    for (const item of items) {
      stmt.run(
        item.telegramId,
        item.amount,
        item.formatted,
        item.orders,
        item.workplace,
        item.sourceLabel,
        item.confirmationStatus,
        item.updatedAt,
        item.fileId
      );
    }
  });

  const items = [];
  for (const row of rows) {
    try {
      const data = JSON.parse(row.data);
      const pcs = data.pendingCashToSubmit;
      if (pcs && Number(pcs.amount || 0) >= 1) {
        items.push({
          telegramId: row.telegramId,
          amount: Number(pcs.amount || 0),
          formatted: pcs.formatted || null,
          orders: pcs.orders || null,
          workplace: pcs.workplace || null,
          sourceLabel: pcs.sourceLabel || null,
          confirmationStatus: pcs.confirmationStatus || null,
          updatedAt: pcs.updatedAt || new Date().toISOString(),
          fileId: pcs.fileId || null
        });
      }
    } catch (e) { /* skip malformed */ }
  }

  if (items.length > 0) {
    insertMany(items);
    console.log(`Migrated ${items.length} pendingCash records to pending_cash table`);
  }
}

migratePendingCashToTable();

function checkpoint() {
  try {
    db.pragma('wal_checkpoint(TRUNCATE)');
  } catch (e) {
    console.error('WAL checkpoint failed:', e.message);
  }
}

// Proxy object that behaves like the original db instance
const dbProxy = new Proxy(db, {
  get(target, prop) {
    if (prop === 'checkpoint') return checkpoint;
    return target[prop];
  }
});

module.exports = dbProxy;
module.exports.checkpoint = checkpoint;
module.exports.db = db;

```


---

## FILE: utils.js

```javascript
function normalizeFio(fio) {
  return String(fio || '')
    .trim()
    .replace(/\s+/g, ' ')
    .replace(/С‘/g, 'Рµ')
    .replace(/РЃ/g, 'Р•')
    .toLowerCase();
}

function normalizeFioWords(fio) {
  return normalizeFio(fio)
    .split(' ')
    .filter(Boolean)
    .sort()
    .join(' ');
}

function getColumnLetter(columnNumber) {
  let number = Number(columnNumber);
  let letter = '';

  while (number > 0) {
    const remainder = (number - 1) % 26;
    letter = String.fromCharCode(65 + remainder) + letter;
    number = Math.floor((number - 1) / 26);
  }

  return letter;
}

function getCourierColumnsByDay(day) {
  return {
    startColumn: 6 + 3 * (day - 1),
    endColumn: 7 + 3 * (day - 1),
    hoursColumn: 8 + 3 * (day - 1)
  };
}

function getMileageColumnsByDay(day) {
  return {
    startColumn: 4 + 3 * (day - 1),
    endColumn: 5 + 3 * (day - 1),
    totalColumn: 6 + 3 * (day - 1)
  };
}

function roundMinutesToHalfHour(hours, minutes) {
  let h = Number(hours);
  let m = Number(minutes);

  if (!Number.isFinite(h) || !Number.isFinite(m)) return null;

  // РџРµСЂРµРїРѕР»РЅРµРЅРёРµ РјРёРЅСѓС‚ (РЅР°РїСЂРёРјРµСЂ, 7:75) РїРµСЂРµРЅРѕСЃРёРј РІ С‡Р°СЃС‹
  if (m >= 60) {
    h += Math.floor(m / 60);
    m = m % 60;
  }

  if (m < 0 || h < 0) return null;

  if (m < 15) {
    if (h > 24) return null;
    // Р”Р»СЏ 0 Рё 1 С‡Р°СЃРѕРІ РІС‹РІРѕРґРёРј РІ С„РѕСЂРјР°С‚Рµ "H,0", С‡С‚РѕР±С‹ РЅРµ РїРµСЂРµСЃРµРєР°С‚СЊСЃСЏ
    // СЃРѕ schedule-РјР°СЂРєРµСЂРѕРј "1" Рё РЅРµ РїРѕРїР°РґР°С‚СЊ РїРѕРґ isEmptyCell.
    // Р”Р»СЏ РѕСЃС‚Р°Р»СЊРЅС‹С… С‡Р°СЃРѕРІ вЂ” РїСЂРѕСЃС‚РѕР№ С„РѕСЂРјР°С‚ Р±РµР· РґСЂРѕР±РЅРѕР№ С‡Р°СЃС‚Рё.
    if (h <= 1) return `${h},0`;
    return String(h);
  }

  if (m < 45) {
    if (h > 23) return null; // 24,5 РЅРµ РёРјРµРµС‚ СЃРјС‹СЃР»Р°
    return `${h},5`;
  }

  h += 1;
  if (h > 24) return null;
  // РђРЅР°Р»РѕРіРёС‡РЅРѕ вЂ” РґР»СЏ 0 Рё 1 С‡Р°СЃРѕРІ РїРѕСЃР»Рµ РїРµСЂРµРЅРѕСЃР°
  if (h <= 1) return `${h},0`;
  return String(h);
}

function roundTimeToHalfHour(date = new Date()) {
  return roundMinutesToHalfHour(date.getHours(), date.getMinutes());
}

function getDateInTimezone(timezone = 'Europe/Moscow') {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).formatToParts(new Date());

  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  const year = Number(values.year);
  const month = Number(values.month);
  const day = Number(values.day);
  const hour = Number(values.hour === '24' ? '0' : values.hour);
  const minute = Number(values.minute);
  const second = Number(values.second);

  return new Date(year, month - 1, day, hour, minute, second);
}

function getCurrentDateInfo(timezone = 'Europe/Moscow') {
  const date = getDateInTimezone(timezone);
  const day = date.getDate();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const dateText = `${String(day).padStart(2, '0')}.${month}.${date.getFullYear()}`;

  return { dateText, day, date };
}

function isEmptyCell(value) {
  if (value === undefined || value === null) return true;
  const s = String(value).trim();
  return s === '';
  // Р’РђР–РќРћ: СЂР°РЅСЊС€Рµ "0" Рё "1" СЃС‡РёС‚Р°Р»РёСЃСЊ РїСѓСЃС‚С‹РјРё, РЅРѕ СЌС‚Рѕ РїРµСЂРµСЃРµРєР°Р»РѕСЃСЊ СЃ
  // СЂРµР°Р»СЊРЅС‹РјРё РІСЂРµРјРµРЅР°РјРё 00:00-00:14 ("0") Рё 00:45-01:14 ("1") вЂ” СЃР»РµРґСѓСЋС‰РёР№
  // РїСѓРЅС‡ РјРѕР»С‡Р° Р·Р°С‚РёСЂР°Р» РёС…. РўРµРїРµСЂСЊ РІСЂРµРјСЏ РґР»СЏ СЌС‚РёС… С‡Р°СЃРѕРІ РІС‹РІРѕРґРёС‚СЃСЏ РєР°Рє
  // "0,0" Рё "1,0" (СЃРј. roundMinutesToHalfHour), Р° РїСѓСЃС‚С‹РјРё СЃС‡РёС‚Р°СЋС‚СЃСЏ С‚РѕР»СЊРєРѕ
  // РґРµР№СЃС‚РІРёС‚РµР»СЊРЅРѕ РїСѓСЃС‚С‹Рµ СЃС‚СЂРѕРєРё. Schedule-РјР°СЂРєРµСЂ "1" РѕР±СЂР°Р±Р°С‚С‹РІР°РµС‚СЃСЏ РѕС‚РґРµР»СЊРЅРѕ
  // С‡РµСЂРµР· isScheduleMarker вЂ” СЃРј. punchTime/prepareMileage.
}

function isScheduleMarker(value) {
  if (value === undefined || value === null) return false;
  const s = String(value).trim();
  return s === '1';
}

module.exports = {
  normalizeFio,
  normalizeFioWords,
  getColumnLetter,
  getCourierColumnsByDay,
  getMileageColumnsByDay,
  roundTimeToHalfHour,
  roundMinutesToHalfHour,
  getCurrentDateInfo,
  isEmptyCell,
  isScheduleMarker
};

```


---

## FILE: services_auth.js

```javascript
let _adminIdsRaw = null;
let _adminIdsCache = null;

function getAdminIds() {
  const raw = String(process.env.ADMIN_IDS || '');
  if (raw === _adminIdsRaw && _adminIdsCache) return _adminIdsCache;
  _adminIdsRaw = raw;
  _adminIdsCache = raw.split(',').map((id) => Number(id.trim())).filter(Number.isFinite);
  return _adminIdsCache;
}

function isAdminUser(telegramId) {
  const adminIds = getAdminIds();
  return adminIds.length > 0 && adminIds.includes(Number(telegramId));
}

module.exports = {
  getAdminIds,
  isAdminUser
};

```


---

## FILE: services_storage.js

```javascript
const fs = require('fs');
const path = require('path');
const { WORKPLACE_KEY_MAP } = require('../config');
const db = require('../db');

function flushNow() {
  // SQLite with WAL mode is already persistent, no manual flush needed.
}

function _getRecord(key) {
  const row = db.prepare('SELECT data FROM users WHERE telegramId = ?').get(String(key));
  if (!row) return null;
  try {
    return JSON.parse(row.data);
  } catch (e) {
    return null;
  }
}

function _setRecord(key, data) {
  const stmt = db.prepare('INSERT OR REPLACE INTO users (telegramId, data) VALUES (?, ?)');
  stmt.run(String(key), JSON.stringify(data));
}

function getUserField(telegramId, field) {
  const record = _getRecord(telegramId) || {};
  return record[field] || null;
}

function setUserField(telegramId, field, value) {
  const record = _getRecord(telegramId) || {};
  record[field] = value;
  _setRecord(telegramId, record);
}

function getFullProfile(telegramId) {
  const profile = _getRecord(telegramId) || {};
  return {
    fio: profile.fio || null,
    carNumber: profile.carNumber || null,
    workplace: profile.workplace || null,
    device: profile.device || null,
    role: profile.role || null,
    courierType: profile.courierType || 'auto'
  };
}

function getUserRole(telegramId) {
  const record = _getRecord(telegramId);
  if (!record) return 'courier';
  return record.role || 'courier';
}

function deleteUser(telegramId) {
  db.prepare('DELETE FROM users WHERE telegramId = ?').run(String(telegramId));
}

function getPendingCash(telegramId) {
  const row = db.prepare('SELECT * FROM pending_cash WHERE telegramId = ?').get(String(telegramId));
  if (!row) return null;
  return {
    amount: Number(row.amount || 0),
    formatted: row.formatted || null,
    orders: row.orders || null,
    workplace: row.workplace || null,
    sourceLabel: row.sourceLabel || null,
    confirmationStatus: row.confirmationStatus || null,
    updatedAt: row.updatedAt || null,
    fileId: row.fileId || null
  };
}

function setPendingCash(telegramId, data) {
  const stmt = db.prepare(
    'INSERT OR REPLACE INTO pending_cash (telegramId, amount, formatted, orders, workplace, sourceLabel, confirmationStatus, updatedAt, fileId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run(
    String(telegramId),
    Number(data?.amount || 0),
    data?.formatted || null,
    data?.orders || null,
    data?.workplace || null,
    data?.sourceLabel || null,
    data?.confirmationStatus || null,
    data?.updatedAt || new Date().toISOString(),
    data?.fileId || null
  );
}

function deletePendingCash(telegramId) {
  db.prepare('DELETE FROM pending_cash WHERE telegramId = ?').run(String(telegramId));
}

function setCashConfirmationStatus(telegramId, status) {
  const row = db.prepare('SELECT * FROM pending_cash WHERE telegramId = ?').get(String(telegramId));
  if (!row) return;
  const stmt = db.prepare(
    'UPDATE pending_cash SET confirmationStatus = ? WHERE telegramId = ?'
  );
  stmt.run(status, String(telegramId));
}

function clearPendingCashAndReminders(telegramId) {
  deletePendingCash(telegramId);
  const allReminders = _getAllReminders();
  for (const reminder of allReminders) {
    if (reminder.courierId === String(telegramId)) {
      _deleteReminder(reminder._shortId);
    }
  }
}

function logCashAction({ logistId, logistFio, courierId, courierFio, workplace, amount, action }) {
  const stmt = db.prepare(
    'INSERT INTO cash_audit (timestamp, logistId, logistFio, courierId, courierFio, workplace, amount, action) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run(
    new Date().toISOString(),
    logistId || null,
    logistFio || null,
    String(courierId),
    courierFio || null,
    workplace || null,
    amount,
    action
  );
}

function getCashHistory(dateStr, workplace) {
  let sql = "SELECT * FROM cash_audit WHERE DATE(timestamp) = DATE(?)";
  const params = [dateStr];
  if (workplace) {
    sql += " AND workplace = ?";
    params.push(workplace);
  }
  sql += " ORDER BY timestamp ASC";
  return db.prepare(sql).all(...params);
}

function getDebtors(workplace) {
  const rows = db.prepare(
    "SELECT pc.telegramId, pc.amount, pc.formatted, u.data " +
    "FROM pending_cash pc " +
    "JOIN users u ON u.telegramId = pc.telegramId " +
    "WHERE pc.workplace = ? AND pc.amount >= 1"
  ).all(workplace);

  const debtors = [];
  for (const row of rows) {
    let record;
    try {
      record = JSON.parse(row.data);
    } catch (e) {
      continue;
    }
    if (record.role === 'logist') continue;
    debtors.push({
      telegramId: row.telegramId,
      fio: record.fio || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№',
      amount: Number(row.amount || 0),
      formatted: row.formatted || String(row.amount || 0),
      workplace: workplace
    });
  }
  return debtors;
}

function findLogistsForWorkplace(workplace) {
  const ids = getAllUserIds();
  const logists = [];
  for (const id of ids) {
    const record = _getRecord(id);
    if (!record || record.role !== 'logist') continue;
    if (record.workplace !== workplace) continue;
    logists.push({
      telegramId: id,
      fio: record.fio || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№',
      chatId: id
    });
  }
  return logists;
}

function _reminderKey(shortId) {
  return `reminder_${shortId}`;
}

function setReminder(shortId, data) {
  const key = _reminderKey(shortId);
  const stmt = db.prepare('INSERT OR REPLACE INTO states (telegramId, data) VALUES (?, ?)');
  stmt.run(key, JSON.stringify({ ...data, _shortId: shortId }));
}

function getReminder(shortId) {
  const key = _reminderKey(shortId);
  const row = db.prepare('SELECT data FROM states WHERE telegramId = ?').get(key);
  if (!row) return null;
  try {
    return JSON.parse(row.data);
  } catch (e) {
    return null;
  }
}

function updateReminder(shortId, updates) {
  const existing = getReminder(shortId);
  if (!existing) return null;
  const merged = { ...existing, ...updates };
  setReminder(shortId, merged);
  return merged;
}

function deleteReminder(shortId) {
  const key = _reminderKey(shortId);
  db.prepare('DELETE FROM states WHERE telegramId = ?').run(key);
}

function _deleteReminder(shortId) {
  deleteReminder(shortId);
}

function _getAllReminders() {
  const rows = db.prepare("SELECT data FROM states WHERE telegramId LIKE 'reminder_%'").all();
  const results = [];
  for (const row of rows) {
    try {
      const data = JSON.parse(row.data);
      results.push(data);
    } catch (e) { /* skip malformed */ }
  }
  return results;
}

function getActiveRemindersForCourier(courierId) {
  return _getAllReminders().filter(r => r.courierId === String(courierId) && r.status !== 'approved' && r.status !== 'declined');
}

function getSelfClearanceRequest(courierId) {
  const pcs = getPendingCash(courierId);
  if (!pcs || pcs.confirmationStatus !== 'awaiting') return null;
  const record = _getRecord(courierId) || {};
  return {
    courierId: String(courierId),
    courierFio: record.fio || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№',
    amount: Number(pcs.amount || 0),
    formatted: pcs.formatted || String(pcs.amount || 0),
    workplace: pcs.workplace || record.workplace || null
  };
}

function cleanupStaleReminders(maxAgeMs = 24 * 60 * 60 * 1000) {
  const now = Date.now();
  const all = _getAllReminders();
  for (const reminder of all) {
    const createdAt = new Date(reminder.createdAt || 0).getTime();
    if (now - createdAt > maxAgeMs) {
      deleteReminder(reminder._shortId);
    }
  }
}

function getAllUserIds() {
  const rows = db.prepare('SELECT telegramId FROM users').all();
  return rows.map(r => r.telegramId).filter(id => /^\d+$/.test(id));
}

const WORKPLACE_SHEETS_KEY = '__workplaceSheets__';
const WORKPLACE_SHEETS_MONTHLY_KEY = '__workplaceSheetsMonthly__';

function getWorkplaceKey(workplace) {
  return WORKPLACE_KEY_MAP[workplace] || null;
}

function getCurrentMonthKey(timezone = process.env.APP_TIMEZONE || 'Europe/Moscow') {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit'
  }).formatToParts(new Date());

  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}`;
}

function getNextMonthKey(timezone = process.env.APP_TIMEZONE || 'Europe/Moscow') {
  const currentKey = getCurrentMonthKey(timezone);
  const [yearText, monthText] = currentKey.split('-');
  let year = Number(yearText);
  let month = Number(monthText) + 1;

  if (month > 12) {
    month = 1;
    year += 1;
  }

  return `${String(year)}-${String(month).padStart(2, '0')}`;
}

function isValidMonthKey(monthKey) {
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(String(monthKey || '').trim());
}

function getWorkplaceMonthlyRoot() {
  return _getRecord(WORKPLACE_SHEETS_MONTHLY_KEY) || {};
}

function getWorkplaceSheetId(workplace) {
  const key = getWorkplaceKey(workplace);
  if (!key) return null;

  const map = _getRecord(WORKPLACE_SHEETS_KEY) || {};
  return map[key] || null;
}

function setWorkplaceSheetId(workplace, sheetId) {
  const key = getWorkplaceKey(workplace);
  if (!key) return;

  const map = _getRecord(WORKPLACE_SHEETS_KEY) || {};
  if (sheetId) {
    map[key] = sheetId;
  } else {
    delete map[key];
  }
  _setRecord(WORKPLACE_SHEETS_KEY, map);
}

function getWorkplaceMonthMap(workplace) {
  const key = getWorkplaceKey(workplace);
  if (!key) return {};

  const monthlyRoot = getWorkplaceMonthlyRoot();
  return { ...(monthlyRoot[key] || {}) };
}

function getWorkplaceSheetIdByMonth(workplace, monthKey) {
  if (!isValidMonthKey(monthKey)) return null;

  const key = getWorkplaceKey(workplace);
  if (!key) return null;

  const monthlyRoot = getWorkplaceMonthlyRoot();
  return monthlyRoot[key]?.[monthKey] || null;
}

function setWorkplaceSheetIdByMonth(workplace, monthKey, sheetId) {
  if (!isValidMonthKey(monthKey)) {
    throw new Error(`Invalid month key: ${monthKey}`);
  }

  const key = getWorkplaceKey(workplace);
  if (!key) {
    throw new Error(`Unknown workplace: ${workplace}`);
  }

  const monthlyRoot = getWorkplaceMonthlyRoot();
  if (!monthlyRoot[key]) monthlyRoot[key] = {};

  if (sheetId) {
    monthlyRoot[key][monthKey] = sheetId;
  } else {
    delete monthlyRoot[key][monthKey];
  }
  
  _setRecord(WORKPLACE_SHEETS_MONTHLY_KEY, monthlyRoot);
}

function resolveSheetInfo(workplace, options = {}) {
  const { monthKey = null } = options;
  const currentMonthKey = getCurrentMonthKey();
  
  const targetMonthKey = monthKey || currentMonthKey;
  let sheetId = getWorkplaceSheetIdByMonth(workplace, targetMonthKey);
  
  if (sheetId) {
    return { sheetId, isMonthly: true, monthKey: targetMonthKey };
  }

  const fallbackSheetId = getWorkplaceSheetId(workplace);
  if (fallbackSheetId) {
    return { sheetId: fallbackSheetId, isMonthly: false, monthKey: null };
  }

  return { sheetId: null, isMonthly: false, monthKey: null };
}

function cleanupOldMonths(retentionMonths = 3) {
  if (!Number.isFinite(retentionMonths) || retentionMonths < 1) return;

  const monthlyRoot = getWorkplaceMonthlyRoot();
  const currentMonthKey = getCurrentMonthKey();
  const [cyStr, cmStr] = currentMonthKey.split('-');
  const cy = Number(cyStr);
  const cm = Number(cmStr);

  let hasChanges = false;

  for (const wpKey of Object.keys(monthlyRoot)) {
    const monthKeys = Object.keys(monthlyRoot[wpKey]);
    for (const mk of monthKeys) {
      if (!isValidMonthKey(mk)) continue;
      const [yStr, mStr] = mk.split('-');
      const y = Number(yStr);
      const m = Number(mStr);
      const diff = (cy - y) * 12 + (cm - m);
      if (diff > retentionMonths) {
        delete monthlyRoot[wpKey][mk];
        hasChanges = true;
      }
    }
  }

  if (hasChanges) {
    _setRecord(WORKPLACE_SHEETS_MONTHLY_KEY, monthlyRoot);
  }
}

const SHEET_ACCESS_USERS = '__sheetAccessUsers__';

function getSheetAccessUsers() {
  const list = _getRecord(SHEET_ACCESS_USERS) || [];
  return Array.isArray(list) ? list : [];
}

function addSheetAccessUser(telegramId) {
  const users = getSheetAccessUsers();
  if (!users.includes(String(telegramId))) {
    users.push(String(telegramId));
    _setRecord(SHEET_ACCESS_USERS, users);
  }
}

function removeSheetAccessUser(telegramId) {
  let users = getSheetAccessUsers();
  users = users.filter((id) => id !== String(telegramId));
  _setRecord(SHEET_ACCESS_USERS, users);
}

function isSheetAccessUser(telegramId) {
  const list = getSheetAccessUsers();
  return list.includes(String(telegramId));
}

function markUserSeen(telegramId) {
  const record = _getRecord(telegramId) || {};
  record.lastSeen = new Date().toISOString();
  _setRecord(telegramId, record);
}

module.exports = {
  flushNow,
  getUserField,
  setUserField,
  getFullProfile,
  getUserRole,
  deleteUser,
  getPendingCash,
  setPendingCash,
  deletePendingCash,
  setCashConfirmationStatus,
  clearPendingCashAndReminders,
  getAllUserIds,

  resolveSheetInfo,
  getWorkplaceSheetId,
  setWorkplaceSheetId,
  getWorkplaceMonthMap,
  getWorkplaceSheetIdByMonth,
  setWorkplaceSheetIdByMonth,
  getCurrentMonthKey,
  getNextMonthKey,
  isValidMonthKey,

  getSheetAccessUsers,
  addSheetAccessUser,
  removeSheetAccessUser,
  isSheetAccessUser,

  markUserSeen,
  cleanupOldMonths,

  logCashAction,
  getCashHistory,
  getDebtors,
  findLogistsForWorkplace,
  setReminder,
  getReminder,
  updateReminder,
  deleteReminder,
  getActiveRemindersForCourier,
  getSelfClearanceRequest,
  cleanupStaleReminders
};
```


---

## FILE: services_googleSheets.js

```javascript
const { JWT } = require('google-auth-library');
const {
  normalizeFio,
  normalizeFioWords,
  getColumnLetter,
  getCourierColumnsByDay,
  getMileageColumnsByDay,
  roundTimeToHalfHour,
  getCurrentDateInfo,
  isEmptyCell,
  isScheduleMarker
} = require('../utils');
// WORKPLACES РІ СЌС‚РѕРј С„Р°Р№Р»Рµ РЅРµ РЅСѓР¶РЅС‹ РЅР°РїСЂСЏРјСѓСЋ вЂ” SHEET_CONFIGS РёСЃРїРѕР»СЊР·СѓРµС‚
// СЃС‚СЂРѕРєРѕРІС‹Рµ РєР»СЋС‡Рё Рё DEFAULT_CONFIG. Р•СЃР»Рё РїРѕР·Р¶Рµ РїРѕРЅР°РґРѕР±РёС‚СЃСЏ вЂ” РёРјРїРѕСЂС‚РёСЂСѓРµРј.

const SHEETS_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';

let sheetsAuth;

function initGoogleSheets() {
  const email = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const privateKey = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n');

  if (!email || !privateKey) {
    throw new Error('Google service account credentials are not set');
  }

  sheetsAuth = new JWT({
    email,
    key: privateKey,
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });

  return sheetsAuth;
}

function getSheetsAuth() {
  if (!sheetsAuth) {
    return initGoogleSheets();
  }
  return sheetsAuth;
}

async function sheetsRequest({ method, path, params, data }, retries = 3) {
  const auth = getSheetsAuth();
  const url = `${SHEETS_BASE}/${path}`;

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await auth.request({ method, url, params, data });
      return response;
    } catch (error) {
      const status = error?.response?.status || 0;
      const retryable = status === 429 || status >= 500 || status === 0;

      if (!retryable || attempt === retries) {
        throw error;
      }

      const delay = Math.min(1000 * Math.pow(2, attempt - 1), 8000);
      console.error(`Google Sheets retry ${attempt}/${retries} (status=${status}), waiting ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
}

const SHEET_CONFIGS = {
  'РРњ Р’РѕСЃС‚РѕРє': {
    courierSheet: 'РљСѓСЂСЊРµСЂС‹',
    mileageSheet: 'РџСЂРѕР±РµРі',
    mileageDayOffset: 0,
    courierFioColumn: 'D',
    mileageFioColumn: 'C',
    mileageAutoColumn: 'B',
    courierFioRange: 'C3:D',
    mileageFioRange: 'B3:C',
    efficiencySheet: 'Р­С„С„РµРєС‚РёРІРЅРѕСЃС‚СЊ',
    efficiencyFioColumn: 'B',
    efficiencyFioRange: 'B3:B',
    efficiencyFirstDayCol: 6,
    efficiencyDayBlockSize: 3
  },
  'РРњ Р¦РµРЅС‚СЂ': {
    courierSheet: 'РљСѓСЂСЊРµСЂС‹',
    mileageSheet: 'РџСЂРѕР±РµРі РљСѓСЂСЊРµСЂС‹',
    mileageDayOffset: 1,
    courierFioColumn: 'D',
    mileageFioColumn: 'D',
    mileageAutoColumn: 'C',
    courierFioRange: 'C3:D',
    mileageFioRange: 'B3:D',
    efficiencySheet: 'Р­С„С„РµРєС‚РёРІРЅРѕСЃС‚СЊ',
    efficiencyFioColumn: 'B',
    efficiencyFioRange: 'B3:B',
    efficiencyFirstDayCol: 6,
    efficiencyDayBlockSize: 3
  }
};

const DEFAULT_CONFIG = SHEET_CONFIGS['РРњ Р’РѕСЃС‚РѕРє'];

function getSheetConfig(workplace) {
  return SHEET_CONFIGS[workplace] || DEFAULT_CONFIG;
}

function resolveSheetContext(workplace, options = {}) {
  const { resolveSheetInfo } = require('./storage');
  return resolveSheetInfo(workplace, options);
}

function getConfiguredSheetCandidates() {
  const candidates = [];
  const seen = new Set();

  for (const workplace of Object.keys(SHEET_CONFIGS)) {
    const context = resolveSheetContext(workplace);
    if (!context.sheetId) continue;

    const uniqueKey = `${workplace}:${context.sheetId}`;
    if (seen.has(uniqueKey)) continue;
    seen.add(uniqueKey);

    candidates.push({ workplace, sheetId: context.sheetId, monthKey: context.monthKey, source: context.source });
  }

  return candidates;
}

async function verifySheetAccess(sheetId) {
  try {
    const response = await sheetsRequest({
      method: 'GET',
      path: sheetId
    });

    const title = response.data.properties?.title || 'Р‘РµР· РЅР°Р·РІР°РЅРёСЏ';
    const sheetsList = response.data.sheets?.map((s) => s.properties?.title) || [];

    const hasCouriers = sheetsList.includes('РљСѓСЂСЊРµСЂС‹');
    const hasMileage = sheetsList.includes('РџСЂРѕР±РµРі') || sheetsList.includes('РџСЂРѕР±РµРі РљСѓСЂСЊРµСЂС‹');

    return {
      ok: hasCouriers && hasMileage,
      title,
      sheets: sheetsList,
      hasCouriers,
      hasMileage,
      error: null
    };
  } catch (error) {
    const status = error.response?.status;
    let message = 'РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕРґРєР»СЋС‡РёС‚СЊСЃСЏ Рє С‚Р°Р±Р»РёС†Рµ.';

    if (status === 404) {
      message = 'РўР°Р±Р»РёС†Р° РЅРµ РЅР°Р№РґРµРЅР°. РџСЂРѕРІРµСЂСЊС‚Рµ СЃСЃС‹Р»РєСѓ.';
    } else if (status === 403) {
      const serviceEmail = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL || '';
      message = serviceEmail
        ? `РќРµС‚ РґРѕСЃС‚СѓРїР°. Р”Р°Р№С‚Рµ РґРѕСЃС‚СѓРї СЃРµСЂРІРёСЃРЅРѕРјСѓ Р°РєРєР°СѓРЅС‚Сѓ Р±РѕС‚Р°:\n${serviceEmail}`
        : 'РќРµС‚ РґРѕСЃС‚СѓРїР° Рє С‚Р°Р±Р»РёС†Рµ. РћР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.';
    }

    return {
      ok: false,
      title: null,
      sheets: [],
      hasCouriers: false,
      hasMileage: false,
      error: message
    };
  }
}

function quoteSheetName(sheetName) {
  return `'${sheetName.replace(/'/g, "''")}'`;
}

function getColumnNumber(columnLetter) {
  return String(columnLetter || '')
    .toUpperCase()
    .split('')
    .reduce((acc, char) => acc * 26 + (char.charCodeAt(0) - 64), 0);
}

function getRangeStartColumn(range) {
  const match = String(range || '').match(/^([A-Z]+)/i);
  return match ? getColumnNumber(match[1]) : null;
}

function getRowValueByColumn(row, range, columnLetter) {
  const startColumn = getRangeStartColumn(range);
  const targetColumn = getColumnNumber(columnLetter);

  if (!startColumn || !targetColumn) return '';
  const index = targetColumn - startColumn;
  if (index < 0) return '';

  return row[index] || '';
}

async function getValues(range, spreadsheetId) {
  if (!spreadsheetId) {
    throw new Error('GOOGLE_SHEET_ID РЅРµ Р·Р°РґР°РЅ. РСЃРїРѕР»СЊР·СѓР№С‚Рµ /sheet РґР»СЏ РїСЂРёРІСЏР·РєРё С‚Р°Р±Р»РёС†С‹.');
  }

  const response = await sheetsRequest({
    method: 'GET',
    path: `${spreadsheetId}/values/${encodeURIComponent(range)}`
  });

  return response.data.values || [];
}

async function readCell(sheetName, cell, spreadsheetId) {
  const values = await getValues(`${quoteSheetName(sheetName)}!${cell}`, spreadsheetId);
  return values[0]?.[0] ?? '';
}

async function updateCell(sheetName, cell, value, spreadsheetId) {
  if (!spreadsheetId) {
    throw new Error('GOOGLE_SHEET_ID РЅРµ Р·Р°РґР°РЅ. РСЃРїРѕР»СЊР·СѓР№С‚Рµ /sheet РґР»СЏ РїСЂРёРІСЏР·РєРё С‚Р°Р±Р»РёС†С‹.');
  }

  await sheetsRequest({
    method: 'PUT',
    path: `${spreadsheetId}/values/${encodeURIComponent(`${quoteSheetName(sheetName)}!${cell}`)}`,
    params: { valueInputOption: 'RAW' },
    data: { values: [[value]] }
  });
}

// РџСЂРѕСЃС‚РѕР№ in-memory mutex РїРѕ РєР»СЋС‡Сѓ (РЅР°РїСЂРёРјРµСЂ, "spreadsheetId:row").
// Р—Р°С‰РёС‰Р°РµС‚ read-modify-write РѕС‚ РіРѕРЅРєРё РїСЂРё РґРІРѕР№РЅРѕРј С‚Р°РїРµ РєРЅРѕРїРєРё.
const _writeLocks = new Map();

async function withRowLock(key, fn) {
  const previous = _writeLocks.get(key) || Promise.resolve();
  let release;
  const next = new Promise((resolve) => { release = resolve; });
  // Р¦РµРїР»СЏРµРј РІ РѕС‡РµСЂРµРґСЊ: СЃР»РµРґСѓСЋС‰РёР№ Р·Р°С…РІР°С‚ Р¶РґС‘С‚ Р’РЎР•Р“Рћ РїСЂРµРґС‹РґСѓС‰РµРіРѕ pipeline
  _writeLocks.set(key, previous.then(() => next));

  await previous;
  try {
    return await fn();
  } finally {
    release();
    // РћС‡РёС‰Р°РµРј, С‚РѕР»СЊРєРѕ РµСЃР»Рё СЌС‚Рѕ Р±С‹Р» РїРѕСЃР»РµРґРЅРёР№ РІ С†РµРїРѕС‡РєРµ (РЅРёРєС‚Рѕ РЅРµ РІСЃС‚Р°Р» РїРѕСЃР»Рµ РЅР°СЃ)
    if (_writeLocks.get(key) === next) {
      _writeLocks.delete(key);
    }
  }
}

async function findCourierByFio(fio, workplace, sheetContext = null) {
  const context = sheetContext || resolveSheetContext(workplace);
  const spreadsheetId = context.sheetId;
  if (!spreadsheetId) return null;

  const config = getSheetConfig(workplace);
  const rows = await getValues(`${quoteSheetName(config.courierSheet)}!${config.courierFioRange}`, spreadsheetId);
  const target = normalizeFioWords(fio);

  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index];
    const rowFio = getRowValueByColumn(row, config.courierFioRange, config.courierFioColumn) || row[row.length - 1] || '';

    if (normalizeFioWords(rowFio) === target) {
      return { row: index + 3, fio: rowFio, auto: row[0] || '', spreadsheetId };
    }
  }

  return null;
}

async function findMileageByFio(fio, workplace, sheetContext = null) {
  const context = sheetContext || resolveSheetContext(workplace);
  const spreadsheetId = context.sheetId;
  if (!spreadsheetId) return null;

  const config = getSheetConfig(workplace);
  const rows = await getValues(`${quoteSheetName(config.mileageSheet)}!${config.mileageFioRange}`, spreadsheetId);
  const target = normalizeFioWords(fio);

  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index];
    const rowFio = getRowValueByColumn(row, config.mileageFioRange, config.mileageFioColumn) || row[row.length - 1] || '';
    const auto = getRowValueByColumn(row, config.mileageFioRange, config.mileageAutoColumn) || row[0] || '';

    if (normalizeFioWords(rowFio) === target) {
      return { row: index + 3, fio: rowFio, auto, spreadsheetId };
    }
  }

  return null;
}

async function findCourierInAllSheets(fio) {
  const candidates = getConfiguredSheetCandidates();

  for (const candidate of candidates) {
    const spreadsheetId = candidate.sheetId;
    const workplace = candidate.workplace;
    const config = getSheetConfig(workplace);

    try {
      const response = await sheetsRequest({
        method: 'GET',
        path: spreadsheetId
      });
      const titles = response.data.sheets?.map((s) => s.properties?.title) || [];

      if (!titles.includes(config.courierSheet)) continue;

      const rows = await getValues(`${quoteSheetName(config.courierSheet)}!${config.courierFioRange}`, spreadsheetId);
      const target = normalizeFioWords(fio);

      for (let index = 0; index < rows.length; index += 1) {
        const row = rows[index];
        const rowFio = getRowValueByColumn(row, config.courierFioRange, config.courierFioColumn) || row[row.length - 1] || '';

        if (normalizeFioWords(rowFio) === target) {
          return { row: index + 3, fio: rowFio, auto: row[0] || '', spreadsheetId, workplace };
        }
      }
    } catch (_) {
      continue;
    }
  }

  return null;
}

async function getTodayStatus(fio, workplace) {
  const ctx = await resolveCourierContext(fio, workplace);
  if (ctx.notFound) {
    if (ctx.noSheet) {
      return { notFound: true, noSheet: true, noSheetForMonth: ctx.noSheetForMonth, monthKey: ctx.monthKey };
    }
    return null;
  }

  const { spreadsheetId, config, courier, mileage } = ctx;

  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const { dateText, day } = getCurrentDateInfo(timezone);
  const courierColumns = getCourierColumnsByDay(day);
  const mileageColumns = getMileageColumns(workplace, day);

  const fromCell = `${getColumnLetter(courierColumns.startColumn)}${courier.row}`;
  const toCell = `${getColumnLetter(courierColumns.endColumn)}${courier.row}`;

  const mileageStartCell = `${getColumnLetter(mileageColumns.startColumn)}${mileage.row}`;
  const mileageEndCell = `${getColumnLetter(mileageColumns.endColumn)}${mileage.row}`;

  const [from, to, mileageStart, mileageEnd] = await Promise.all([
    readCell(config.courierSheet, fromCell, spreadsheetId),
    readCell(config.courierSheet, toCell, spreadsheetId),
    readCell(config.mileageSheet, mileageStartCell, spreadsheetId),
    readCell(config.mileageSheet, mileageEndCell, spreadsheetId)
  ]);

  const cleanMarker = (v) => isScheduleMarker(v) ? '' : v;

  return {
    fio: courier.fio,
    auto: courier.auto || mileage.auto,
    date: dateText,
    from: cleanMarker(from),
    to: cleanMarker(to),
    mileageStart,
    mileageEnd
  };
}

function makePunchState({ courier, mileage, dateText, day, stage, timeValue }) {
  return {
    fio: courier.fio,
    auto: courier.auto || (mileage ? mileage.auto : ''),
    date: dateText,
    day,
    stage,
    courierRow: courier.row,
    mileageRow: mileage ? mileage.row : null,
    timeValue
  };
}

function makeMileageState({ courier, mileage, dateText, day, stage }) {
  return {
    fio: courier.fio,
    auto: courier.auto || mileage.auto,
    date: dateText,
    day,
    stage,
    courierRow: courier.row,
    mileageRow: mileage.row
  };
}

function getMileageColumns(workplace, day) {
  const columns = getMileageColumnsByDay(day);
  const offset = getSheetConfig(workplace).mileageDayOffset || 0;

  return {
    startColumn: columns.startColumn + offset,
    endColumn: columns.endColumn + offset,
    totalColumn: columns.totalColumn + offset
  };
}

async function resolveCourierContext(fio, workplace, options = {}) {
  const { requireMileage = true } = options;
  const sheetContext = resolveSheetContext(workplace);
  const spreadsheetId = sheetContext.sheetId;
  if (!spreadsheetId) {
    return {
      sheetContext,
      spreadsheetId,
      config: null,
      courier: null,
      mileage: null,
      notFound: true,
      noSheet: true,
      noSheetForMonth: sheetContext.noSheetForMonth,
      monthKey: sheetContext.monthKey
    };
  }

  const config = getSheetConfig(workplace);
  const courier = await findCourierByFio(fio, workplace, sheetContext);

  if (!courier) {
    return { sheetContext, spreadsheetId, config, courier: null, mileage: null, notFound: true };
  }

  if (!requireMileage) {
    return { sheetContext, spreadsheetId, config, courier, mileage: null, notFound: false };
  }

  const mileage = await findMileageByFio(fio, workplace, sheetContext);

  if (!mileage) {
    return { sheetContext, spreadsheetId, config, courier, mileage: null, notFound: true };
  }

  return { sheetContext, spreadsheetId, config, courier, mileage, notFound: false };
}

async function prepareMileage(fio, workplace, stage = null) {
  const ctx = await resolveCourierContext(fio, workplace);
  if (ctx.notFound) {
    if (ctx.noSheet) {
      return { notFound: true, noSheet: true, noSheetForMonth: ctx.noSheetForMonth, monthKey: ctx.monthKey };
    }
    return { notFound: true };
  }

  const { spreadsheetId, config, courier, mileage } = ctx;

  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const { dateText, day } = getCurrentDateInfo(timezone);

  if (stage) {
    return makeMileageState({ courier, mileage, dateText, day, stage });
  }

  const columns = getMileageColumns(workplace, day);
  const startCell = `${getColumnLetter(columns.startColumn)}${mileage.row}`;
  const endCell = `${getColumnLetter(columns.endColumn)}${mileage.row}`;
  const [startMileage, endMileage] = await Promise.all([
    readCell(config.mileageSheet, startCell, spreadsheetId),
    readCell(config.mileageSheet, endCell, spreadsheetId)
  ]);

  if (isEmptyCell(startMileage) || isScheduleMarker(startMileage)) {
    return makeMileageState({ courier, mileage, dateText, day, stage: 'start' });
  }

  if (isEmptyCell(endMileage) || isScheduleMarker(endMileage)) {
    return makeMileageState({ courier, mileage, dateText, day, stage: 'end' });
  }

  return {
    needsReplaceChoice: true,
    fio: courier.fio,
    auto: courier.auto || mileage.auto,
    date: dateText,
    day,
    courierRow: courier.row,
    mileageRow: mileage.row,
    startMileage,
    endMileage
  };
}

async function punchTime(fio, workplace, isPedestrian = false) {
  const ctx = await resolveCourierContext(fio, workplace, { requireMileage: !isPedestrian });
  if (ctx.notFound) {
    if (ctx.noSheet) {
      return { notFound: true, noSheet: true, noSheetForMonth: ctx.noSheetForMonth, monthKey: ctx.monthKey };
    }
    return { notFound: true };
  }

  const { spreadsheetId, config, courier, mileage } = ctx;

  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const { dateText, day, date } = getCurrentDateInfo(timezone);
  const timeValue = roundTimeToHalfHour(date);
  const columns = getCourierColumnsByDay(day);
  const startCell = `${getColumnLetter(columns.startColumn)}${courier.row}`;
  const endCell = `${getColumnLetter(columns.endColumn)}${courier.row}`;

  return withRowLock(`${spreadsheetId}:courier:${courier.row}`, async () => {
    const [from, to] = await Promise.all([
      readCell(config.courierSheet, startCell, spreadsheetId),
      readCell(config.courierSheet, endCell, spreadsheetId)
    ]);

    if (isEmptyCell(from) || isScheduleMarker(from)) {
      await updateCell(config.courierSheet, startCell, timeValue, spreadsheetId);
      return makePunchState({ courier, mileage, dateText, day, stage: 'start', timeValue });
    }

    if (isEmptyCell(to) || isScheduleMarker(to)) {
      await updateCell(config.courierSheet, endCell, timeValue, spreadsheetId);
      return makePunchState({ courier, mileage, dateText, day, stage: 'end', timeValue });
    }

    return {
      needsReplaceChoice: true,
      fio: courier.fio,
      auto: courier.auto || (mileage ? mileage.auto : ''),
      date: dateText,
      day,
      courierRow: courier.row,
      mileageRow: mileage ? mileage.row : null,
      timeValue,
      from,
      to
    };
  });
}

async function replaceTime(fio, workplace, stage, isPedestrian = false) {
  const ctx = await resolveCourierContext(fio, workplace, { requireMileage: !isPedestrian });
  if (ctx.notFound) {
    if (ctx.noSheet) {
      return { notFound: true, noSheet: true, noSheetForMonth: ctx.noSheetForMonth, monthKey: ctx.monthKey };
    }
    return { notFound: true };
  }

  const { courier, mileage } = ctx;

  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const { dateText, day, date } = getCurrentDateInfo(timezone);
  const timeValue = roundTimeToHalfHour(date);

  await updateCourierTime(courier.row, day, stage, timeValue, workplace);

  return makePunchState({ courier, mileage, dateText, day, stage, timeValue });
}

function requireSheetId(workplace) {
  const spreadsheetId = resolveSheetContext(workplace).sheetId;
  if (!spreadsheetId) {
    throw new Error('GOOGLE_SHEET_ID РЅРµ Р·Р°РґР°РЅ. РСЃРїРѕР»СЊР·СѓР№С‚Рµ /sheet РґР»СЏ РїСЂРёРІСЏР·РєРё С‚Р°Р±Р»РёС†С‹.');
  }
  return { spreadsheetId, config: getSheetConfig(workplace) };
}

async function updateCourierTime(row, day, stage, value, workplace) {
  const { spreadsheetId, config } = requireSheetId(workplace);
  const columns = getCourierColumnsByDay(day);
  const columnNumber = stage === 'start' ? columns.startColumn : columns.endColumn;
  const cell = `${getColumnLetter(columnNumber)}${row}`;
  return withRowLock(`${spreadsheetId}:courier:${row}`, () =>
    updateCell(config.courierSheet, cell, value, spreadsheetId)
  );
}

async function updateMileage(row, day, stage, mileage, workplace) {
  const { spreadsheetId, config } = requireSheetId(workplace);
  const columns = getMileageColumns(workplace, day);
  const columnNumber = stage === 'start' ? columns.startColumn : columns.endColumn;
  const cell = `${getColumnLetter(columnNumber)}${row}`;
  return withRowLock(`${spreadsheetId}:mileage:${row}`, () =>
    updateCell(config.mileageSheet, cell, String(mileage), spreadsheetId)
  );
}

async function updateEfficiencyOrders(fio, workplace, day, ordersCount) {
  const config = getSheetConfig(workplace);
  if (!config.efficiencySheet) {
    return { ok: false, error: 'efficiency_sheet_not_configured' };
  }

  const sheetContext = resolveSheetContext(workplace);
  const spreadsheetId = sheetContext.sheetId;
  if (!spreadsheetId) {
    return { ok: false, error: 'no_sheet_id' };
  }

  const rows = await getValues(`${quoteSheetName(config.efficiencySheet)}!${config.efficiencyFioRange}`, spreadsheetId);
  const target = normalizeFio(fio);

  let foundRow = null;
  for (let index = 0; index < rows.length; index += 1) {
    const row = rows[index];
    const rowFio = getRowValueByColumn(row, config.efficiencyFioRange, config.efficiencyFioColumn) || row[row.length - 1] || '';
    if (normalizeFio(rowFio) === target) {
      foundRow = index + 3;
      break;
    }
  }

  if (!foundRow) {
    return { ok: false, error: 'fio_not_found' };
  }

  const ordersColumn = config.efficiencyFirstDayCol + (day - 1) * config.efficiencyDayBlockSize + 1;
  const cell = `${getColumnLetter(ordersColumn)}${foundRow}`;

  await updateCell(config.efficiencySheet, cell, ordersCount, spreadsheetId);
  return { ok: true, cell, row: foundRow, day, ordersCount };
}

module.exports = {
  initGoogleSheets,
  findCourierInAllSheets,
  getTodayStatus,
  punchTime,
  prepareMileage,
  replaceTime,
  updateCourierTime,
  updateMileage,
  readCell,
  verifySheetAccess,
  getSheetConfig,
  updateEfficiencyOrders
};

```


---

## FILE: services_mileageOcr.js

```javascript
const axios = require('axios');

const OCR_CONCURRENCY = 2;
let activeOcrRequests = 0;
const ocrQueue = [];

function enqueueOcrRequest(fn) {
  return new Promise((resolve, reject) => {
    ocrQueue.push({ fn, resolve, reject });
    processNextOcrRequest();
  });
}

function processNextOcrRequest() {
  if (activeOcrRequests >= OCR_CONCURRENCY || ocrQueue.length === 0) return;
  activeOcrRequests++;
  const { fn, resolve, reject } = ocrQueue.shift();
  Promise.resolve().then(() => fn()).then(
    (result) => {
      resolve(result);
      activeOcrRequests--;
      processNextOcrRequest();
    },
    (error) => {
      reject(error);
      activeOcrRequests--;
      processNextOcrRequest();
    }
  );
}

function isRapidOcrEnabled() {
  return process.env.RAPIDOCR_ENABLED !== 'false';
}

function getMinMileageThreshold() {
  const value = Number(process.env.OCR_MIN_MILEAGE || 1000);
  if (!Number.isFinite(value) || value < 0) return 1000;
  return value;
}

function normalizeText(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function compactText(value) {
  return normalizeText(value).toLowerCase().replace(/\s+/g, '');
}

function isOdometerNoiseText(text) {
  const raw = normalizeText(text);
  const compact = compactText(text);
  if (!compact) return true;

  if (/\b\d{1,2}:\d{2}\b/.test(raw)) return true;
  if (/-?\d{1,2}\s*[В°Вє]/.test(raw)) return true;

  const noiseTokens = [
    'km/h',
    'mph',
    'rpm',
    'x1000',
    '/100',
    'l/100',
    '1/100',
    'temp'
  ];

  if (noiseTokens.some((token) => compact.includes(token))) return true;

  if (compact.includes('trip') && compact.includes('avg')) return true;
  if (compact.includes('avg')) {
    if (/\d{3,6}/.test(compact)) return false;
    return true;
  }

  const speedScalePattern = /\b(2[0-9]{2}|1[4-9]{2}|1[0-3]{2}|60|80|100|120)\b/;
  if (speedScalePattern.test(raw) && !compact.includes('km') && !compact.includes('/km') && !compact.includes('ikm')) return true;

  return false;
}

function extractMileage(text, options = {}) {
  const minDigits = Number.isFinite(options.minDigits) ? options.minDigits : 2;
  const maxDigits = Number.isFinite(options.maxDigits) ? options.maxDigits : 6;
  if (options.skipNoise !== false && isOdometerNoiseText(text)) {
    return null;
  }

  const normalized = String(text || '').replace(/[Oo]/g, '0');
  const candidates = new Set();
  const strictRegex = new RegExp(`\\d{${minDigits},${maxDigits}}`, 'g');
  const flexibleRegex = new RegExp(`(?:\\d[\\s.,:;\\-]*){${minDigits},${maxDigits}}`, 'g');

  for (const match of normalized.matchAll(strictRegex)) {
    candidates.add(match[0]);
  }

  for (const match of normalized.matchAll(flexibleRegex)) {
    const value = match[0].replace(/\D/g, '');

    if (value.length >= minDigits && value.length <= maxDigits) {
      candidates.add(value);
    }
  }

  const values = Array.from(candidates);

  if (values.length === 0) {
    return null;
  }

  values.sort((a, b) => b.length - a.length || Number(b) - Number(a));
  return Number(values[0]);
}

function isMileageInBounds(mileage, options = {}) {
  if (!Number.isFinite(mileage)) return false;

  const minMileage = Number.isFinite(options.minMileage)
    ? options.minMileage
    : getMinMileageThreshold();
  const maxMileage = Number.isFinite(options.maxMileage)
    ? options.maxMileage
    : null;

  if (Number.isFinite(minMileage) && mileage < minMileage) return false;
  if (Number.isFinite(maxMileage) && mileage > maxMileage) return false;
  return true;
}

function smartPickFromGroups(groups, options = {}) {
  if (!groups || groups.length === 0) return { mileage: null, candidates: [] };

  const valid = groups.filter((g) => Number.isFinite(g.mileage) && g.mileage > 0);
  if (valid.length === 0) return { mileage: null, candidates: [] };

  // km groups ALWAYS win вЂ” if a number has "km" next to it, it's the odometer
  const kmGroups = valid.filter((g) => g.has_km && !g.is_noise && g.mileage >= 100);
  if (kmGroups.length > 0) {
    const bestKm = kmGroups.sort((a, b) => {
      const aLen = String(a.mileage).length;
      const bLen = String(b.mileage).length;
      if (aLen >= 5 && bLen < 5) return -1;
      if (bLen >= 5 && aLen < 5) return 1;
      return b.avgConfidence - a.avgConfidence;
    })[0];
    if (bestKm) {
      const candidates = kmGroups.slice(0, 5).map((g) => ({ mileage: g.mileage, source: 'ocr', confidence: g.avgConfidence }));
      return { mileage: bestKm.mileage, candidates };
    }
  }

  // No km groups вЂ” pick best non-noise long number
  const ranked = [...valid].sort((a, b) => {
    const aLen = String(a.mileage).length;
    const bLen = String(b.mileage).length;
    const aOdo = aLen >= 5 && aLen <= 6 ? 1 : 0;
    const bOdo = bLen >= 5 && bLen <= 6 ? 1 : 0;
    if (aOdo !== bOdo) return bOdo - aOdo;

    const aNoise = a.is_noise ? 0 : 1;
    const bNoise = b.is_noise ? 0 : 1;
    if (aNoise !== bNoise) return bNoise - aNoise;

    const aInBounds = isMileageInBounds(a.mileage, options) ? 1 : 0;
    const bInBounds = isMileageInBounds(b.mileage, options) ? 1 : 0;
    if (aInBounds !== bInBounds) return bInBounds - aInBounds;

    if (a.count !== b.count) return b.count - a.count;
    return b.avgConfidence - a.avgConfidence;
  });

  const best = ranked[0];
  if (best && best.avgConfidence >= 0.30) {
    return { mileage: best.mileage, candidates: ranked.slice(0, 5).map((g) => ({ mileage: g.mileage, source: 'ocr', confidence: g.avgConfidence })) };
  }

  if (best && isMileageInBounds(best.mileage, options)) {
    return { mileage: best.mileage, candidates: ranked.slice(0, 5).map((g) => ({ mileage: g.mileage, source: 'ocr', confidence: g.avgConfidence })) };
  }

  return { mileage: null, candidates: ranked.slice(0, 5).map((g) => ({ mileage: g.mileage, source: 'ocr', confidence: g.avgConfidence })) };
}

// AI vision logic completely removed

async function recognizeMileageWithRapidOcr(imageBuffer, options = {}) {
  const rapidOcrUrl = process.env.RAPIDOCR_URL || '';

  if (!rapidOcrUrl) {
    console.error('RapidOCR: RAPIDOCR_URL not configured');
    return { engine: 'rapidocr', mileage: null, groups: [], best: null, raw: null, reason: 'no_url' };
  }

  try {
    const response = await enqueueOcrRequest(() => axios.post(rapidOcrUrl, imageBuffer, {
      timeout: 30000,
      headers: { 'Content-Type': 'application/octet-stream' }
    }));
    const parsed = response.data;
    console.log('RapidOCR HTTP result', JSON.stringify(parsed).substring(0, 500));
    return mapRapidOcrResult(parsed, options);
  } catch (error) {
    console.error('RapidOCR HTTP error:', error.message);
    return { engine: 'rapidocr', mileage: null, groups: [], best: null, raw: null, reason: 'error' };
  }
}

function mapRapidOcrResult(parsed, options) {
  const groups = Array.isArray(parsed.groups)
    ? parsed.groups
        .map((group) => ({
          mileage: Number(group.mileage),
          count: Number(group.count || 0),
          avgConfidence: Number(group.avg_confidence || 0),
          maxConfidence: Number(group.max_confidence || 0),
          has_km: !!group.has_km,
          is_noise: !!group.is_noise
        }))
        .filter((group) => Number.isFinite(group.mileage) && group.mileage > 0)
    : [];

  const best = groups[0] || null;
  const pick = smartPickFromGroups(groups, options);

  return {
    engine: 'rapidocr',
    mileage: pick.mileage,
    groups,
    best,
    candidates: pick.candidates,
    raw: parsed,
    reason: pick.mileage ? 'accepted' : (best ? 'weak_confidence' : 'no_candidate')
  };
}

async function downloadTelegramFile(ctx, fileId, retries = 3) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const link = await ctx.telegram.getFileLink(fileId);
      const response = await axios.get(link.href, { responseType: 'arraybuffer', timeout: 30000 });
      return Buffer.from(response.data);
    } catch (error) {
      console.error(`Download attempt ${attempt}/${retries} failed`, error.message);
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 1000 * attempt));
      } else {
        throw error;
      }
    }
  }
}

function isValidImageBuffer(buffer) {
  if (!buffer || buffer.length < 100) return false;
  const b = buffer[0];
  const b1 = buffer[1];
  if (b === 0xFF && b1 === 0xD8) return true;
  if (b === 0x89 && b1 === 0x50) return true;
  if (b === 0x47 && b1 === 0x49) return true;
  if (b === 0x52 && b1 === 0x49) return true;
  if (b === 0x42 && b1 === 0x4D) return true;
  return false;
}

async function recognizeMileage(ctx, fileId, options = {}) {
  const startTime = Date.now();
  const onStatus = options.onStatus || null;

  let sourceBuffer = options.sourceBuffer || null;
  if (!sourceBuffer) {
    try {
      sourceBuffer = await downloadTelegramFile(ctx, fileId);
      console.log('OCR timing: download', Date.now() - startTime, 'ms');
    } catch (error) {
      console.error('OCR download error', error.message);
      return null;
    }
  }

  if (!isValidImageBuffer(sourceBuffer)) {
    console.error('OCR: downloaded file is not a valid image', { size: sourceBuffer?.length, firstBytes: sourceBuffer?.slice(0, 4).toString('hex') });
    return null;
  }

  try {
    const ocrStartTime = Date.now();
    const rapidResult = await recognizeMileageWithRapidOcr(sourceBuffer, options);
    console.log('OCR timing: RapidOCR', Date.now() - ocrStartTime, 'ms');

    const ocrMileage = rapidResult.mileage;
    const groups = rapidResult.groups || [];
    const ocrCandidates = rapidResult.candidates || [];

    if (ocrMileage) {
      console.log('OCR accepted', {
        mileage: ocrMileage,
        source: rapidResult.reason,
        groups: groups.map((g) => `${g.mileage}(Г—${g.count} avg=${g.avgConfidence.toFixed(2)} max=${g.maxConfidence.toFixed(2)})`).join(', '),
        minMileage: options.minMileage,
        maxMileage: options.maxMileage
      });
      console.log('OCR timing: total', Date.now() - startTime, 'ms');
      return { mileage: ocrMileage, candidates: ocrCandidates };
    }

    console.log('OCR rejected', {
      reason: rapidResult.reason,
      groups: groups.map((g) => `${g.mileage}(Г—${g.count} avg=${g.avgConfidence.toFixed(2)})`).join(', '),
      best: rapidResult.best ? `${rapidResult.best.mileage}(Г—${rapidResult.best.count})` : null
    });
    console.log('OCR timing: total', Date.now() - startTime, 'ms');
    return { mileage: null, candidates: ocrCandidates };
  } catch (error) {
    console.error('OCR error', error.message || error);
    return null;
  }
}

async function recognizeTextWithRapidOcr(imageBuffer) {
  const rapidOcrUrl = process.env.RAPIDOCR_URL || '';

  if (!rapidOcrUrl) {
    return null;
  }

  try {
    const url = rapidOcrUrl.replace(/\/+$/, '') + '/text';
    const response = await enqueueOcrRequest(() => axios.post(url, imageBuffer, {
      timeout: 120000,
      headers: { 'Content-Type': 'application/octet-stream' }
    }));
    const items = response.data?.text_items;
    if (!Array.isArray(items) || items.length === 0) {
      return null;
    }

    const combined = items.map((item) => item.text || '').join('\n');
    console.log('RapidOCR text recognition', items.length, 'items, text:', combined.substring(0, 500));
    return combined;
  } catch (error) {
    console.error('RapidOCR text recognition error:', error.message);
    return null;
  }
}

async function checkRapidOcrHealth() {
  const rapidOcrUrl = process.env.RAPIDOCR_URL || '';
  if (!rapidOcrUrl) return false;

  try {
    const response = await axios.get(`${rapidOcrUrl.replace(/\/+$/, '')}/health`, { timeout: 5000 });
    return response.status === 200 && response.data?.status === 'ok';
  } catch (error) {
    console.error('RapidOCR health check failed:', error.message);
    return false;
  }
}

module.exports = {
  recognizeMileage,
  downloadTelegramFile,
  recognizeTextWithRapidOcr,
  isRapidOcrEnabled,
  getMinMileageThreshold,
  checkRapidOcrHealth
};
```


---

## FILE: services_ocrDebug.js

```javascript
const fs = require('fs');
const path = require('path');

const OCR_DEBUG_DIR = path.join(__dirname, '..', 'ocr_debug');
const INDEX_FILE = path.join(OCR_DEBUG_DIR, 'index.json');
const MAX_DISK_MB = 2000;
const MAX_FILES = 300;
const MAX_AGE_DAYS = 30;

function ensureDir() {
  if (!fs.existsSync(OCR_DEBUG_DIR)) {
    fs.mkdirSync(OCR_DEBUG_DIR, { recursive: true });
  }
}

function readIndex() {
  try {
    if (fs.existsSync(INDEX_FILE)) {
      return JSON.parse(fs.readFileSync(INDEX_FILE, 'utf8'));
    }
  } catch (e) {
    console.error('ocrDebug: readIndex error', e.message);
  }
  return {};
}

function writeIndex(index) {
  try {
    ensureDir();
    fs.writeFileSync(INDEX_FILE, JSON.stringify(index, null, 2), 'utf8');
  } catch (e) {
    console.error('ocrDebug: writeIndex error', e.message);
  }
}

function getFileSizeMb(filePath) {
  try {
    const stat = fs.statSync(filePath);
    return stat.size / (1024 * 1024);
  } catch {
    return 0;
  }
}

/**
 * РЎРѕС…СЂР°РЅСЏРµС‚ С„РѕС‚Рѕ РґР»СЏ РѕС‚Р»Р°РґРєРё OCR.
 * @param {Buffer} imageBuffer - СЃС‹СЂС‹Рµ Р±Р°Р№С‚С‹ РёР·РѕР±СЂР°Р¶РµРЅРёСЏ
 * @param {Object} meta - РјРµС‚Р°РґР°РЅРЅС‹Рµ
 * @param {string} meta.status - 'ocr_fail' | 'ocr_mismatch' | 'confirmed_ok'
 * @param {number|null} meta.ocrResult - С‡С‚Рѕ СЂР°СЃРїРѕР·РЅР°Р» OCR (null РµСЃР»Рё РЅРµ СЂР°СЃРїРѕР·РЅР°Р»)
 * @param {number|null} meta.userCorrectedValue - С‡С‚Рѕ РІРІС‘Р» РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ
 * @param {number} meta.telegramId - ID РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ
 * @param {string} meta.stage - 'start' | 'end'
 * @param {string} meta.workplace - РјР°РіР°Р·РёРЅ
 * @param {string} meta.fio - Р¤РРћ
 * @param {string} meta.fileId - Telegram file_id
 */
function saveOcrDebugImage(imageBuffer, meta) {
  if (!imageBuffer || imageBuffer.length < 100) return null;

  const dateStr = new Date().toISOString().slice(0, 10);
  const shortFileId = (meta.fileId || 'unknown').slice(-12);
  const fileName = `${dateStr}_${meta.telegramId}_${meta.stage}_${meta.status}_${shortFileId}.jpg`;
  const filePath = path.join(OCR_DEBUG_DIR, fileName);

  try {
    ensureDir();
    fs.writeFileSync(filePath, imageBuffer);
    const sizeMb = getFileSizeMb(filePath);

    const index = readIndex();
    index[fileName] = {
      fileName,
      filePath,
      timestamp: new Date().toISOString(),
      telegramId: meta.telegramId,
      stage: meta.stage || null,
      workplace: meta.workplace || null,
      fio: meta.fio || null,
      fileId: meta.fileId || null,
      ocrResult: meta.ocrResult !== undefined ? meta.ocrResult : null,
      userCorrectedValue: meta.userCorrectedValue !== undefined ? meta.userCorrectedValue : null,
      status: meta.status || 'ocr_fail',
      sizeMb: Math.round(sizeMb * 100) / 100
    };
    writeIndex(index);

    cleanupOldFiles();
    return fileName;
  } catch (error) {
    console.error('ocrDebug: save error', error.message);
    return null;
  }
}

/**
 * РћР±РЅРѕРІР»СЏРµС‚ СЃС‚Р°С‚СѓСЃ СЃСѓС‰РµСЃС‚РІСѓСЋС‰РµР№ Р·Р°РїРёСЃРё РїРѕ fileId.
 */
function updateOcrDebugStatus(fileId, status, userCorrectedValue) {
  if (!fileId) return;
  const index = readIndex();
  let changed = false;
  for (const key of Object.keys(index)) {
    if (index[key].fileId === fileId) {
      index[key].status = status;
      if (userCorrectedValue !== undefined) {
        index[key].userCorrectedValue = userCorrectedValue;
      }
      changed = true;
      break;
    }
  }
  if (changed) {
    writeIndex(index);
  }
}

function getTotalSizeMb() {
  const index = readIndex();
  let total = 0;
  for (const key of Object.keys(index)) {
    total += index[key].sizeMb || 0;
  }
  return total;
}

function cleanupOldFiles() {
  try {
    ensureDir();
    const index = readIndex();
    const now = Date.now();
    const maxAgeMs = MAX_AGE_DAYS * 24 * 60 * 60 * 1000;
    let changed = false;

    // 1. РЈРґР°Р»РёС‚СЊ РїРѕ РІРѕР·СЂР°СЃС‚Сѓ (>30 РґРЅРµР№)
    for (const key of Object.keys(index)) {
      const ts = new Date(index[key].timestamp).getTime();
      if (now - ts > maxAgeMs) {
        const fp = path.join(OCR_DEBUG_DIR, key);
        try { if (fs.existsSync(fp)) fs.unlinkSync(fp); } catch (_) {}
        delete index[key];
        changed = true;
      }
    }

    // 2. РЈРґР°Р»РёС‚СЊ РїРѕ РєРѕР»РёС‡РµСЃС‚РІСѓ (>300), СЃРЅР°С‡Р°Р»Р° confirmed_ok, РїРѕС‚РѕРј ocr_fail, РїРѕС‚РѕРј ocr_mismatch
    const ordered = Object.entries(index).sort((a, b) => {
      const statusOrder = { confirmed_ok: 0, ocr_fail: 1, ocr_mismatch: 2 };
      const sa = statusOrder[a[1].status] || 1;
      const sb = statusOrder[b[1].status] || 1;
      if (sa !== sb) return sa - sb;
      return new Date(a[1].timestamp) - new Date(b[1].timestamp);
    });

    while (ordered.length > MAX_FILES) {
      const entry = ordered.shift();
      if (!entry) break;
      const [key] = entry;
      const fp = path.join(OCR_DEBUG_DIR, key);
      try { if (fs.existsSync(fp)) fs.unlinkSync(fp); } catch (_) {}
      delete index[key];
      changed = true;
    }

    // 3. РЈРґР°Р»РёС‚СЊ РїРѕ СЂР°Р·РјРµСЂСѓ (>2000 MB)
    while (getTotalSizeMb() > MAX_DISK_MB && ordered.length > 0) {
      const entry = ordered.shift();
      if (!entry) break;
      const [key] = entry;
      if (index[key]) {
        const fp = path.join(OCR_DEBUG_DIR, key);
        try { if (fs.existsSync(fp)) fs.unlinkSync(fp); } catch (_) {}
        delete index[key];
        changed = true;
      }
    }

    if (changed) {
      writeIndex(index);
    }
  } catch (error) {
    console.error('ocrDebug: cleanup error', error.message);
  }
}

module.exports = {
  saveOcrDebugImage,
  updateOcrDebugStatus,
  cleanupOldFiles,
  getTotalSizeMb
};

```


---

## FILE: services_leaderboard.js

```javascript
const db = require('../db');

function flushNow() {
  // SQLite WAL is persistent.
}

function _getRecord(telegramId) {
  const row = db.prepare('SELECT data FROM leaderboard WHERE telegramId = ?').get(String(telegramId));
  if (!row) return null;
  try {
    return JSON.parse(row.data);
  } catch {
    return null;
  }
}

function _setRecord(telegramId, data) {
  const stmt = db.prepare('INSERT OR REPLACE INTO leaderboard (telegramId, data) VALUES (?, ?)');
  stmt.run(String(telegramId), JSON.stringify(data));
}

function _getAllRecords() {
  const rows = db.prepare('SELECT telegramId, data FROM leaderboard').all();
  const records = {};
  for (const row of rows) {
    try {
      records[row.telegramId] = JSON.parse(row.data);
    } catch {
      // ignore bad JSON
    }
  }
  return records;
}

function _formatLocalDate(date, timezone) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(date);
  const v = Object.fromEntries(parts.map(p => [p.type, p.value]));
  return `${v.year}-${v.month}-${v.day}`;
}

function getTodayKey() {
  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  return _formatLocalDate(new Date(), timezone);
}

function recordOrders(telegramId, fio, workplace, ordersCount, courierType) {
  let record = _getRecord(telegramId);
  if (!record) {
    record = {
      fio,
      workplace,
      courierType,
      dailyOrders: {}
    };
  }

  record.fio = fio || record.fio;
  record.workplace = workplace || record.workplace;
  if (courierType) {
    record.courierType = courierType;
  }

  const dayKey = getTodayKey();
  record.dailyOrders[dayKey] = ordersCount;

  _setRecord(telegramId, record);
  return record;
}

function getDaysAgo(days) {
  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const msPerDay = 24 * 60 * 60 * 1000;
  const pastDate = new Date(Date.now() - days * msPerDay);
  return _formatLocalDate(pastDate, timezone);
}

const WORKPLACE_SHORT = {
  'РРњ Р’РѕСЃС‚РѕРє': 'Р’РѕСЃС‚РѕРє',
  'РРњ Р¦РµРЅС‚СЂ': 'Р¦РµРЅС‚СЂ'
};

function calculateLeaderboard(type, periodDays, workplace, courierTypeFilter) {
  const records = _getAllRecords();
  const cutoff = periodDays ? getDaysAgo(periodDays) : null;
  
  const wpMapping = { east: 'РРњ Р’РѕСЃС‚РѕРє', center: 'РРњ Р¦РµРЅС‚СЂ' };
  const filterWorkplace = workplace && workplace !== 'all' ? (wpMapping[workplace] || workplace) : null;

  const entries = [];
  for (const [telegramId, record] of Object.entries(records)) {
    if (!record.dailyOrders) continue;
    if (filterWorkplace && record.workplace !== filterWorkplace) continue;
    if (courierTypeFilter && courierTypeFilter !== 'all' && record.courierType !== courierTypeFilter) continue;

    let value = 0;
    for (const [dayKey, orders] of Object.entries(record.dailyOrders)) {
      if (cutoff && dayKey < cutoff) continue;   // string comparison on "YYYY-MM-DD"
      if (type === 'max') {
        if (orders > value) value = orders;
      } else {
        value += orders;
      }
    }

    if (value > 0) {
      entries.push({
        telegramId,
        fio: record.fio || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№',
        workplace: record.workplace || '',
        courierType: record.courierType || 'auto',
        value
      });
    }
  }

  entries.sort((a, b) => b.value - a.value || a.fio.localeCompare(b.fio, 'ru'));

  let rank = 1;
  for (let i = 0; i < entries.length; i++) {
    if (i > 0 && entries[i].value < entries[i - 1].value) {
      rank = i + 1;
    }
    entries[i].rank = rank;
  }

  return entries;
}

function formatLeaderboard(entries, myTelegramId, showWorkplace = false) {
  if (entries.length === 0) {
    return 'РџРѕРєР° РїСѓСЃС‚Рѕ.';
  }

  const lines = entries.slice(0, 50).map(entry => {
    let medal = '';
    if (entry.rank === 1) medal = 'рџҐ‡';
    else if (entry.rank === 2) medal = 'рџҐ€';
    else if (entry.rank === 3) medal = 'рџҐ‰';
    else medal = '  ';

    let fioStr = entry.fio.split(' ').slice(0, 2).join(' ');
    if (entry.telegramId === String(myTelegramId)) {
      fioStr = `<b>${fioStr} (Р’С‹)</b>`;
    }

    let wpSuffix = '';
    if (showWorkplace && entry.workplace) {
      const short = WORKPLACE_SHORT[entry.workplace] || entry.workplace.replace('РРњ ', '');
      wpSuffix = ` [${short}]`;
    }

    return `${medal} ${entry.rank}. ${fioStr}${wpSuffix} вЂ” <b>${entry.value}</b>`;
  });

  const myIndex = entries.findIndex(e => e.telegramId === String(myTelegramId));
  if (myIndex >= 50) {
    lines.push('...');
    const myEntry = entries[myIndex];
    let wpSuffix = '';
    if (showWorkplace && myEntry.workplace) {
      const short = WORKPLACE_SHORT[myEntry.workplace] || myEntry.workplace.replace('РРњ ', '');
      wpSuffix = ` [${short}]`;
    }
    lines.push(`   ${myEntry.rank}. <b>${myEntry.fio.split(' ').slice(0, 2).join(' ')} (Р’С‹)</b>${wpSuffix} вЂ” <b>${myEntry.value}</b>`);
  }

  return lines.join('\n');
}

function checkNotifications(telegramId, fio, workplace, currentDayOrders) {
  const record = _getRecord(telegramId);
  const previousRecord = record ? record.personalRecord : 0;
  
  if (currentDayOrders > (previousRecord || 0)) {
    if (record) {
      record.personalRecord = currentDayOrders;
      _setRecord(telegramId, record);
    }
    return [{ type: 'personal_record', value: currentDayOrders, previous: previousRecord || 0 }];
  }
  return [];
}

function getDayOrders(telegramId, dayKey) {
  const record = _getRecord(telegramId);
  if (!record || !record.dailyOrders) return 0;
  return record.dailyOrders[dayKey] || 0;
}

function getWorkplaceRecord(workplace, dayKey) {
  const root = _getRecord('__workplaceRecords__') || {};
  return root[workplace]?.[dayKey] || null;
}

function setWorkplaceRecord(workplace, dayKey, orders, fio) {
  const root = _getRecord('__workplaceRecords__') || {};
  if (!root[workplace]) root[workplace] = {};
  root[workplace][dayKey] = { orders, fio, at: new Date().toISOString() };
  _setRecord('__workplaceRecords__', root);
  return root[workplace][dayKey];
}

function getDailyTop3(workplace, dayKey) {
  const records = _getAllRecords();
  const entries = [];
  for (const [tid, record] of Object.entries(records)) {
    if (record.workplace !== workplace) continue;
    if (!record.dailyOrders || !record.dailyOrders[dayKey]) continue;
    entries.push({
      telegramId: tid,
      fio: record.fio || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№',
      orders: record.dailyOrders[dayKey]
    });
  }
  entries.sort((a, b) => b.orders - a.orders);
  return entries.slice(0, 3);
}

function findOvertakenCouriers(telegramId, workplace, oldOrders, newOrders, dayKey) {
  if (newOrders <= oldOrders) return [];
  const records = _getAllRecords();
  const overtaken = [];
  for (const [tid, record] of Object.entries(records)) {
    if (tid === String(telegramId)) continue;
    if (record.workplace !== workplace) continue;
    if (!record.dailyOrders) continue;
    const theirOrders = record.dailyOrders[dayKey] || 0;
    if (theirOrders > oldOrders && theirOrders < newOrders) {
      overtaken.push({
        telegramId: tid,
        fio: record.fio || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№',
        orders: theirOrders
      });
    }
  }
  overtaken.sort((a, b) => b.orders - a.orders);
  return overtaken;
}

module.exports = {
  recordOrders,
  calculateLeaderboard,
  formatLeaderboard,
  checkNotifications,
  flushNow,
  getDayOrders,
  getWorkplaceRecord,
  setWorkplaceRecord,
  getDailyTop3,
  findOvertakenCouriers,
  getTodayKey
};
```


---

## FILE: services_xp.js

```javascript
const db = require('../db');

const AUTO_RANKS = [
  { level: 1, name: 'рџ†• РќРѕРІРёС‡РѕРє', threshold: 0 },
  { level: 2, name: 'рџ›ћ РЎС‚Р°Р¶С‘СЂ', threshold: 1000 },
  { level: 3, name: 'рџљђ Р Р°Р·РІРѕР·С‡РёРє', threshold: 3000 },
  { level: 4, name: 'рџљ— РљСѓСЂСЊРµСЂ', threshold: 7000 },
  { level: 5, name: 'рџЏЋпёЏ Р‘С‹РІР°Р»С‹Р№', threshold: 15000 },
  { level: 6, name: 'рџ›ЈпёЏ Р—РЅР°С‚РѕРє С‚СЂР°СЃСЃ', threshold: 30000 },
  { level: 7, name: 'вљЎ РњРѕР»РЅРёСЏ', threshold: 50000 },
  { level: 8, name: 'рџҐ€ РњР°СЃС‚РµСЂ РґРѕСЃС‚Р°РІРєРё', threshold: 70000 },
  { level: 9, name: 'рџҐ‡ Р›РµРіРµРЅРґР° РґРѕСЂРѕРі', threshold: 85000 },
  { level: 10, name: 'рџ‘‘ РљРѕСЂРѕР»СЊ СЂРµР№С‚РёРЅРіР°', threshold: 100000 }
];

const PEDESTRIAN_RANKS = [
  { level: 1, name: 'рџ†• РќРѕРІРёС‡РѕРє', threshold: 0 },
  { level: 2, name: 'рџљ¶вЂЌв™‚пёЏ РЎС‚Р°Р¶С‘СЂ', threshold: 500 },
  { level: 3, name: 'рџЏѓ Р‘РµРіСѓРЅ', threshold: 1500 },
  { level: 4, name: 'рџЏѓвЂЌв™‚пёЏ РљСѓСЂСЊРµСЂ', threshold: 3500 },
  { level: 5, name: 'рџЏѓвЂЌв™ЂпёЏ Р‘С‹РІР°Р»С‹Р№', threshold: 7500 },
  { level: 6, name: 'рџ¦Њ Р—РЅР°С‚РѕРє РјР°СЂС€СЂСѓС‚РѕРІ', threshold: 15000 },
  { level: 7, name: 'вљЎ Р’РµС‚РµСЂ', threshold: 25000 },
  { level: 8, name: 'рџҐ€ РњР°СЃС‚РµСЂ РґРѕСЃС‚Р°РІРєРё', threshold: 35000 },
  { level: 9, name: 'рџҐ‡ Р›РµРіРµРЅРґР° С€Р°РіРѕРјРµСЂР°', threshold: 42500 },
  { level: 10, name: 'рџ‘‘ РљРѕСЂРѕР»СЊ СЂРµР№С‚РёРЅРіР°', threshold: 50000 }
];

const XP_ACTIONS = {
  punchStart: 15,
  punchEnd: 15,
  routeSheet: 30,
  reconciliation: 50,
  cashSubmit: 80,
  mileage: 30,
  top10: 150,
  top3: 300,
  top1: 800
};

function getRanks(courierType) {
  return courierType === 'pedestrian' ? PEDESTRIAN_RANKS : AUTO_RANKS;
}

function addXp(telegramId, amount, reason) {
  if (!Number.isFinite(amount) || amount <= 0) return;
  const stmt = db.prepare(
    'INSERT INTO xp_log (telegramId, amount, reason, createdAt) VALUES (?, ?, ?, ?)'
  );
  stmt.run(String(telegramId), amount, reason || '', new Date().toISOString());
}

function getTotalXp(telegramId) {
  const row = db.prepare(
    'SELECT COALESCE(SUM(amount), 0) as total FROM xp_log WHERE telegramId = ?'
  ).get(String(telegramId));
  return Number(row?.total || 0);
}

function getRank(xp, courierType) {
  const ranks = getRanks(courierType);
  let current = ranks[0];
  for (const rank of ranks) {
    if (xp >= rank.threshold) {
      current = rank;
    } else {
      break;
    }
  }
  return current;
}

function getNextRank(xp, courierType) {
  const ranks = getRanks(courierType);
  for (const rank of ranks) {
    if (xp < rank.threshold) {
      return rank;
    }
  }
  return null;
}

function getRankProgress(xp, courierType) {
  const current = getRank(xp, courierType);
  const next = getNextRank(xp, courierType);
  if (!next) {
    return { percent: 100, current, next: null, remaining: 0 };
  }
  const prevThreshold = current.threshold;
  const range = next.threshold - prevThreshold;
  const progress = xp - prevThreshold;
  const percent = Math.min(100, Math.floor((progress / range) * 100));
  return {
    percent,
    current,
    next,
    remaining: next.threshold - xp
  };
}

function formatRankInfo(telegramId, courierType) {
  const xp = getTotalXp(telegramId);
  const prog = getRankProgress(xp, courierType);
  if (!prog.next) {
    return `${prog.current.name} вЂ” ${xp.toLocaleString('ru-RU')} XP (РјР°РєСЃРёРјР°Р»СЊРЅС‹Р№ СЂР°РЅРі!)`;
  }
  return `${prog.current.name} вЂ” ${xp.toLocaleString('ru-RU')} / ${prog.next.threshold.toLocaleString('ru-RU')} XP (${prog.percent}%)`;
}

function getXpForAction(actionKey) {
  return XP_ACTIONS[actionKey] || 0;
}

module.exports = {
  addXp,
  getTotalXp,
  getRank,
  getNextRank,
  getRankProgress,
  formatRankInfo,
  getXpForAction,
  AUTO_RANKS,
  PEDESTRIAN_RANKS
};

```


---

## FILE: services_achievements.js

```javascript
const db = require('../db');

const ACHIEVEMENTS = [
  // Milestone: Р·Р°РєР°Р·С‹
  { id: 'orders_50', name: 'рџ›’ РќРѕРІРёС‡РѕРє', desc: '50 Р·Р°РєР°Р·РѕРІ', condition: { type: 'orders', value: 50 }, reward: 100 },
  { id: 'orders_300', name: 'рџ›’ РћРїС‹С‚РЅС‹Р№', desc: '300 Р·Р°РєР°Р·РѕРІ', condition: { type: 'orders', value: 300 }, reward: 300 },
  { id: 'orders_1000', name: 'рџ›’ РњР°СЃС‚РµСЂ', desc: '1 000 Р·Р°РєР°Р·РѕРІ', condition: { type: 'orders', value: 1000 }, reward: 800 },
  { id: 'orders_5000', name: 'рџ›’ Р“СѓСЂСѓ', desc: '5 000 Р·Р°РєР°Р·РѕРІ', condition: { type: 'orders', value: 5000 }, reward: 2000 },

  // Milestone: РІС‹СЂСѓС‡РєР°
  { id: 'cash_10k', name: 'рџ’° РџРµСЂРІС‹Рµ РґРµРЅСЊРіРё', desc: '10 000 в‚Ѕ РІС‹СЂСѓС‡РєРё', condition: { type: 'cash', value: 10000 }, reward: 100 },
  { id: 'cash_500k', name: 'рџ’° Р¤РёРЅР°РЅСЃРёСЃС‚', desc: '500 000 в‚Ѕ РІС‹СЂСѓС‡РєРё', condition: { type: 'cash', value: 500000 }, reward: 500 },
  { id: 'cash_1m', name: 'рџ’° РњРёР»Р»РёРѕРЅРµСЂ', desc: '1 000 000 в‚Ѕ РІС‹СЂСѓС‡РєРё', condition: { type: 'cash', value: 1000000 }, reward: 2000 },

  // Milestone: СЃРјРµРЅС‹
  { id: 'shifts_30', name: 'вЏ± РўСЂСѓРґРѕРіРѕР»РёРє', desc: '30 СЃРјРµРЅ', condition: { type: 'shifts', value: 30 }, reward: 200 },
  { id: 'shifts_200', name: 'вЏ± Р’Р°С…С‚Р°', desc: '200 СЃРјРµРЅ', condition: { type: 'shifts', value: 200 }, reward: 1000 },
  { id: 'shifts_500', name: 'вЏ± Р’РµС‚РµСЂР°РЅ', desc: '500 СЃРјРµРЅ', condition: { type: 'shifts', value: 500 }, reward: 3000 },

  // Streak
  { id: 'streak_3', name: 'рџ”Ґ Р’РѕРёРЅ', desc: '3 СЃРјРµРЅС‹ РїРѕРґСЂСЏРґ', condition: { type: 'streak', value: 3 }, reward: 150 },
  { id: 'streak_7', name: 'рџ”Ґ Р–РµР»РµР·РЅС‹Р№', desc: '7 СЃРјРµРЅ РїРѕРґСЂСЏРґ', condition: { type: 'streak', value: 7 }, reward: 500 },
  { id: 'streak_14', name: 'рџ”Ґ РќРµСЃРіРёР±Р°РµРјС‹Р№', desc: '14 СЃРјРµРЅ РїРѕРґСЂСЏРґ', condition: { type: 'streak', value: 14 }, reward: 1500 },
  { id: 'streak_30', name: 'рџ”Ґ Р‘РѕРі СЃС‚СЂРёРєР°', desc: '30 СЃРјРµРЅ РїРѕРґСЂСЏРґ', condition: { type: 'streak', value: 30 }, reward: 5000 },

  // Performance
  { id: 'top1_day', name: 'рџҐ‡ Р”РµРЅСЊ РІ С€Р»СЏРїРµ', desc: 'РўРѕРї-1 РґРЅСЏ', condition: { type: 'top1_day' }, reward: 500 },
  { id: 'rank_jump', name: 'рџ“€ Р С‹РІРѕРє', desc: 'РџРѕРґРЅСЏС‚СЊСЃСЏ РЅР° 3+ СЂР°РЅРіР° Р·Р° РЅРµРґРµР»СЋ', condition: { type: 'rank_jump' }, reward: 1000 },
  { id: 'orders_25', name: 'вљЎ Р РµРєРѕСЂРґСЃРјРµРЅ', desc: '25+ Р·Р°РєР°Р·РѕРІ Р·Р° СЃРјРµРЅСѓ', condition: { type: 'orders_single', value: 25 }, reward: 500 },

  // Special
  { id: 'early_bird', name: 'рџђ¦ Р Р°РЅРЅСЏСЏ РїС‚Р°С€РєР°', desc: 'РќР°С‡Р°Р»Рѕ СЃРјРµРЅС‹ РґРѕ 07:00', condition: { type: 'early_bird' }, reward: 200 },
  { id: 'night_owl', name: 'рџ¦‰ РќРѕС‡РЅР°СЏ СЃРѕРІР°', desc: 'РљРѕРЅРµС† СЃРјРµРЅС‹ РїРѕСЃР»Рµ 00:00', condition: { type: 'night_owl' }, reward: 200 },
  { id: 'photographer', name: 'рџ“ё Р¤РѕС‚РѕРіСЂР°С„', desc: '50 С„РѕС‚Рѕ РїСЂРѕР±РµРіР° Р±РµР· РѕС€РёР±РєРё', condition: { type: 'photos', value: 50, courierType: 'auto' }, reward: 300 },
  { id: 'marathon', name: 'рџљ¶ РњР°СЂР°С„РѕРЅРµС†', desc: '10 000 С€Р°РіРѕРІ Р·Р° РґРµРЅСЊ', condition: { type: 'steps', value: 10000, courierType: 'pedestrian' }, reward: 300 },
  { id: 'perfect_shift', name: 'рџ’Ћ РРґРµР°Р»СЊРЅР°СЏ СЃРјРµРЅР°', desc: 'РњР°СЂС€СЂСѓС‚РЅРёРє + СЃРІРµСЂРєР° + РЅР°Р»РёС‡РЅС‹Рµ Р·Р° РґРµРЅСЊ', condition: { type: 'perfect_shift' }, reward: 400 },
  { id: 'perfectionist', name: 'рџЏ† РџРµСЂС„РµРєС†РёРѕРЅРёСЃС‚', desc: '10 РёРґРµР°Р»СЊРЅС‹С… СЃРјРµРЅ РїРѕРґСЂСЏРґ', condition: { type: 'perfect_streak', value: 10 }, reward: 600 },
  { id: 'month_no_skip', name: 'рџ“… РњРµСЃСЏС† Р±РµР· РїСЂРѕРїСѓСЃРєРѕРІ', desc: '30 СЂР°Р±РѕС‡РёС… РґРЅРµР№', condition: { type: 'month_no_skip' }, reward: 1500 },
  { id: 'early_start_50', name: 'рџ”„ Р Р°РЅРЅРёР№ СЃС‚Р°СЂС‚', desc: '50 СЃРјРµРЅ РЅР°С‡Р°С‚С‹ РґРѕ 09:00', condition: { type: 'early_start', value: 50 }, reward: 500 },
  { id: 'late_finish_50', name: 'рџЊ™ РџРѕР·РґРЅРёР№ С„РёРЅРёС€', desc: '50 СЃРјРµРЅ Р·Р°РєРѕРЅС‡РµРЅС‹ РїРѕСЃР»Рµ 22:00', condition: { type: 'late_finish', value: 50 }, reward: 500 },
  { id: 'reliable', name: 'рџ¤ќ РќР°РґС‘Р¶РЅС‹Р№', desc: '100 СЃРјРµРЅ Р±РµР· Р¶Р°Р»РѕР±', condition: { type: 'no_issues', value: 100 }, reward: 700 }
];

function getAllAchievements() {
  return ACHIEVEMENTS;
}

function getUnlockedAchievements(telegramId) {
  const rows = db.prepare('SELECT achievementId, unlockedAt FROM user_achievements WHERE telegramId = ?').all(String(telegramId));
  return rows.map(r => ({
    ...ACHIEVEMENTS.find(a => a.id === r.achievementId),
    unlockedAt: r.unlockedAt
  })).filter(Boolean);
}

function isAchievementUnlocked(telegramId, achievementId) {
  const row = db.prepare('SELECT 1 FROM user_achievements WHERE telegramId = ? AND achievementId = ?').get(String(telegramId), achievementId);
  return !!row;
}

function unlockAchievement(telegramId, achievementId) {
  if (isAchievementUnlocked(telegramId, achievementId)) return null;
  const ach = ACHIEVEMENTS.find(a => a.id === achievementId);
  if (!ach) return null;
  const stmt = db.prepare('INSERT INTO user_achievements (telegramId, achievementId, unlockedAt) VALUES (?, ?, ?)');
  stmt.run(String(telegramId), achievementId, new Date().toISOString());
  return ach;
}

function checkMilestoneAchievements(telegramId, stats) {
  const unlocked = [];
  for (const ach of ACHIEVEMENTS) {
    if (isAchievementUnlocked(telegramId, ach.id)) continue;
    if (ach.condition.type === 'orders' && (stats.totalOrders || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'cash' && (stats.totalCash || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'shifts' && (stats.totalShifts || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'photos' && (stats.totalPhotos || 0) >= ach.condition.value) {
      if (!ach.condition.courierType || stats.courierType === ach.condition.courierType) {
        unlockAchievement(telegramId, ach.id);
        unlocked.push(ach);
      }
    }
    if (ach.condition.type === 'steps' && (stats.totalSteps || 0) >= ach.condition.value) {
      if (!ach.condition.courierType || stats.courierType === ach.condition.courierType) {
        unlockAchievement(telegramId, ach.id);
        unlocked.push(ach);
      }
    }
    if (ach.condition.type === 'streak' && (stats.currentStreak || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'early_start' && (stats.earlyStarts || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'late_finish' && (stats.lateFinishes || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'no_issues' && (stats.shiftsWithoutIssues || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
    if (ach.condition.type === 'perfect_streak' && (stats.perfectStreak || 0) >= ach.condition.value) {
      unlockAchievement(telegramId, ach.id);
      unlocked.push(ach);
    }
  }
  return unlocked;
}

module.exports = {
  getAllAchievements,
  getUnlockedAchievements,
  isAchievementUnlocked,
  unlockAchievement,
  checkMilestoneAchievements
};

```


---

## FILE: services_challenges.js

```javascript
const db = require('../db');

const CHALLENGE_POOL = {
  common: [
    { id: 'doc_5', name: 'рџ“ё Р”РѕРєСѓРјРµРЅС‚Р°Р»РёСЃС‚', desc: 'РћС‚РїСЂР°РІРёС‚СЊ 5 РјР°СЂС€СЂСѓС‚РЅРёРєРѕРІ Р·Р° РЅРµРґРµР»СЋ', target: 5, reward: 100, metric: 'routeSheets' },
    { id: 'rec_3', name: 'рџ“Љ РЎРІРµСЂС‰РёРє', desc: 'РћС‚РїСЂР°РІРёС‚СЊ 3 СЃРІРµСЂРєРё Р·Р° РЅРµРґРµР»СЋ', target: 3, reward: 150, metric: 'reconciliations' },
    { id: 'cash_3', name: 'рџ’µ РљРѕРїРёР»РєР°', desc: 'РЎРґР°С‚СЊ РЅР°Р»РёС‡РЅС‹Рµ 3 СЂР°Р·Р° Р·Р° РЅРµРґРµР»СЋ', target: 3, reward: 150, metric: 'cashSubmits' },
    { id: 'shifts_5', name: 'вЏ± РўСЂСѓРґСЏРіР°', desc: '5 СЃРјРµРЅ Р·Р° РЅРµРґРµР»СЋ', target: 5, reward: 300, metric: 'shifts' }
  ],
  auto: [
    { id: 'mile_5', name: 'рџљ— РћРґРѕРјРµС‚СЂ', desc: 'Р—Р°РїРёСЃР°С‚СЊ РїСЂРѕР±РµРі 5 СЂР°Р· Р·Р° РЅРµРґРµР»СЋ', target: 5, reward: 100, metric: 'mileages' },
    { id: 'eco', name: 'рџљ— Р­РєРѕРЅРѕРј', desc: 'РЎСЂРµРґРЅРёР№ РїСЂРѕР±РµРі в‰¤ 15 РєРј/Р·Р°РєР°Р· (РјРёРЅ. 30 Р·Р°РєР°Р·РѕРІ)', target: 30, reward: 500, metric: 'ecoMileage' }
  ],
  pedestrian: [
    { id: 'sprint', name: 'рџљ¶ РЎРїРёСЂРёРЅС‚', desc: '30+ Р·Р°РєР°Р·РѕРІ Р·Р° 1 СЃРјРµРЅСѓ', target: 1, reward: 500, metric: 'sprintDay' },
    { id: 'light_feet', name: 'рџљ¶ Р›С‘РіРєРёРµ РЅРѕРіРё', desc: '20+ Р·Р°РєР°Р·РѕРІ Р·Р° СЃРјРµРЅСѓ 3 СЂР°Р·Р° Р·Р° РЅРµРґРµР»СЋ', target: 3, reward: 300, metric: 'highOrderDays' }
  ]
};

function getWeekId(date = new Date()) {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - d.getDay() + 1); // РїРѕРЅРµРґРµР»СЊРЅРёРє
  return d.toISOString().split('T')[0];
}

function generateWeeklyChallenges(telegramId, courierType) {
  const weekId = getWeekId();
  const existing = db.prepare('SELECT 1 FROM challenges WHERE weekId = ? AND telegramId = ?').get(weekId, String(telegramId));
  if (existing) return getChallenges(telegramId);

  const pool = [...CHALLENGE_POOL.common];
  if (courierType === 'auto') {
    pool.push(...CHALLENGE_POOL.auto);
  } else {
    pool.push(...CHALLENGE_POOL.pedestrian);
  }

  const shuffled = pool.sort(() => Math.random() - 0.5);
  const selected = shuffled.slice(0, 3);

  const stmt = db.prepare(
    'INSERT INTO challenges (weekId, telegramId, type, target, current, completed, reward) VALUES (?, ?, ?, ?, 0, 0, ?)'
  );
  const insertMany = db.transaction((items) => {
    for (const item of items) {
      stmt.run(weekId, String(telegramId), item.id, item.target, item.reward);
    }
  });
  insertMany(selected);

  return selected.map(s => ({ ...s, current: 0, completed: 0 }));
}

function getChallenges(telegramId) {
  const weekId = getWeekId();
  const rows = db.prepare('SELECT * FROM challenges WHERE weekId = ? AND telegramId = ?').all(weekId, String(telegramId));
  return rows.map(r => {
    const template = findChallengeTemplate(r.type);
    return {
      ...template,
      target: r.target,
      current: r.current,
      completed: r.completed,
      reward: r.reward
    };
  });
}

function findChallengeTemplate(type) {
  const all = [...CHALLENGE_POOL.common, ...CHALLENGE_POOL.auto, ...CHALLENGE_POOL.pedestrian];
  return all.find(c => c.id === type) || { id: type, name: type, desc: '', metric: type };
}

function updateChallengeProgress(telegramId, metric, value = 1) {
  const weekId = getWeekId();
  const rows = db.prepare('SELECT * FROM challenges WHERE weekId = ? AND telegramId = ? AND completed = 0').all(weekId, String(telegramId));
  const completed = [];
  for (const row of rows) {
    const template = findChallengeTemplate(row.type);
    if (template.metric !== metric) continue;
    const newCurrent = (row.current || 0) + value;
    if (newCurrent >= row.target) {
      db.prepare('UPDATE challenges SET current = ?, completed = 1 WHERE weekId = ? AND telegramId = ? AND type = ?')
        .run(newCurrent, weekId, String(telegramId), row.type);
      completed.push({ ...template, reward: row.reward });
    } else {
      db.prepare('UPDATE challenges SET current = ? WHERE weekId = ? AND telegramId = ? AND type = ?')
        .run(newCurrent, weekId, String(telegramId), row.type);
    }
  }
  return completed;
}

module.exports = {
  generateWeeklyChallenges,
  getChallenges,
  updateChallengeProgress,
  getWeekId
};

```


---

## FILE: services_streak.js

```javascript
const db = require('../db');

function getStreak(telegramId) {
  const row = db.prepare('SELECT currentStreak, maxStreak, lastShiftDate FROM streaks WHERE telegramId = ?').get(String(telegramId));
  if (!row) {
    return { currentStreak: 0, maxStreak: 0, lastShiftDate: null };
  }
  return {
    currentStreak: Number(row.currentStreak || 0),
    maxStreak: Number(row.maxStreak || 0),
    lastShiftDate: row.lastShiftDate || null
  };
}

function updateStreak(telegramId, shiftDateStr) {
  const record = getStreak(telegramId);
  let current = record.currentStreak;
  let max = record.maxStreak;

  if (record.lastShiftDate) {
    const last = new Date(record.lastShiftDate);
    const today = new Date(shiftDateStr);
    const diffMs = today - last;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      // С‚Р° Р¶Рµ РґР°С‚Р° вЂ” РЅРµ СѓРІРµР»РёС‡РёРІР°РµРј СЃС‚СЂРёРє
    } else if (diffDays <= 2) {
      current += 1;
    } else {
      current = 1;
    }
  } else {
    current = 1;
  }

  if (current > max) {
    max = current;
  }

  const stmt = db.prepare(
    'INSERT OR REPLACE INTO streaks (telegramId, currentStreak, maxStreak, lastShiftDate) VALUES (?, ?, ?, ?)'
  );
  stmt.run(String(telegramId), current, max, shiftDateStr);

  return { currentStreak: current, maxStreak: max, lastShiftDate: shiftDateStr };
}

function getStreakBonus(currentStreak) {
  if (currentStreak > 0 && currentStreak % 5 === 0) {
    return 50;
  }
  return 0;
}

module.exports = {
  getStreak,
  updateStreak,
  getStreakBonus
};

```


---

## FILE: menus_keyboards.js

```javascript
const { Markup } = require('telegraf');
const { WORKPLACES, DEVICES, BUTTONS, WORKPLACE_FEATURES } = require('../config');
const {
  getUserField,
  getUserRole,
  getActiveRemindersForCourier,
  getSelfClearanceRequest,
  isSheetAccessUser
} = require('../services/storage');
const { isAdminUser } = require('../services/auth');

function mainMenu() {
  return Markup.keyboard([
    [BUTTONS.punchTime, BUTTONS.mileage],
    [BUTTONS.routeSheet, BUTTONS.reconciliation],
    [BUTTONS.cashCheck, BUTTONS.issues],
    [BUTTONS.leaderBoard, BUTTONS.settings]
  ]).resize();
}

function courierMainMenu(telegramId) {
  const courierType = getUserField(telegramId, 'courierType') || 'auto';
  const rows = [
    [BUTTONS.punchTime]
  ];
  if (courierType !== 'pedestrian') {
    rows.push([BUTTONS.mileage]);
  }
  rows.push([BUTTONS.routeSheet, BUTTONS.reconciliation]);
  rows.push([BUTTONS.cashCheck, BUTTONS.issues]);
  rows.push([BUTTONS.leaderBoard, BUTTONS.settings]);
  return Markup.keyboard(rows).resize();
}

function profileMenu(telegramId) {
  const courierType = getUserField(telegramId, 'courierType') || 'auto';
  const rows = [];
  if (courierType !== 'pedestrian') {
    rows.push([BUTTONS.changeCar, BUTTONS.changeWorkplace]);
  } else {
    rows.push([BUTTONS.changeWorkplace]);
  }
  rows.push([BUTTONS.changeDevice, BUTTONS.switchUser]);
  rows.push([BUTTONS.backToSettings]);
  return Markup.keyboard(rows).resize();
}

function workplaceMenu() {
  return Markup.keyboard([
    WORKPLACES,
    [BUTTONS.back]
  ]).resize();
}

function deviceMenu() {
  return Markup.keyboard([
    DEVICES,
    [BUTTONS.back]
  ]).resize();
}

function logistMainMenu(telegramId) {
  const workplace = getUserField(telegramId, 'workplace');
  const features = WORKPLACE_FEATURES[workplace] || {};
  const rows = [
    [BUTTONS.punchTime, BUTTONS.openShop]
  ];
  if (features.cashCollection) {
    rows.push([BUTTONS.cashCollect, BUTTONS.cashHistory]);
  }
  rows.push([BUTTONS.sheetInfo, BUTTONS.settings]);
  return Markup.keyboard(rows).resize();
}

function logistSettingsMenu() {
  return Markup.keyboard([
    [BUTTONS.profile],
    [BUTTONS.myId],
    [BUTTONS.help],
    [BUTTONS.back]
  ]).resize();
}

function logistProfileMenu() {
  return Markup.keyboard([
    [BUTTONS.changeWorkplace, BUTTONS.switchUser],
    [BUTTONS.backToSettings]
  ]).resize();
}

function getMenuForRole(telegramId) {
  const role = getUserRole(telegramId);
  if (role === 'logist') {
    return logistMainMenu(telegramId);
  }
  return courierMainMenu(telegramId);
}

function getSettingsMenuForRole(telegramId) {
  const role = getUserRole(telegramId);
  if (role === 'logist') {
    return logistSettingsMenu();
  }
  const showSheets = isAdminUser(telegramId) || isSheetAccessUser(telegramId);
  const buttons = [
    [BUTTONS.profile]
  ];
  if (showSheets) {
    buttons.push([BUTTONS.sheetInfo, BUTTONS.myId]);
  } else {
    buttons.push([BUTTONS.myId]);
  }
  buttons.push([BUTTONS.help]);
  buttons.push([BUTTONS.back]);
  return Markup.keyboard(buttons).resize();
}

function getProfileMenuForRole(telegramId) {
  const role = getUserRole(telegramId);
  if (role === 'logist') {
    return logistProfileMenu();
  }
  return profileMenu(telegramId);
}

function roleChoiceKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('рџ‘¤ РљСѓСЂСЊРµСЂ', 'role_courier')],
    [Markup.button.callback('рџ“¦ Р›РѕРіРёСЃС‚', 'role_logist')]
  ]);
}

function skipMileageKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('вњЏпёЏ Р’РІРµСЃС‚Рё РІСЂСѓС‡РЅСѓСЋ', 'edit_mileage')],
    [
      Markup.button.callback('вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊ', 'skip_mileage'),
      Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')
    ]
  ]);
}

function mileageConfirmKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('рџ“· Р—Р°РіСЂСѓР·РёС‚СЊ С„РѕС‚Рѕ РїРѕРІС‚РѕСЂРЅРѕ', 'retry_mileage_photo')],
    [Markup.button.callback('вњЏпёЏ Р’РІРµСЃС‚Рё РІСЂСѓС‡РЅСѓСЋ', 'edit_mileage')],
    [
      Markup.button.callback('вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊ', 'skip_mileage'),
      Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')
    ]
  ]);
}

function mileageSavedKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('вњЏпёЏ РР·РјРµРЅРёС‚СЊ РїСЂРѕР±РµРі', 'edit_mileage')]
  ]);
}

function routeSheetKeyboard() {
  return Markup.inlineKeyboard([
    [
      Markup.button.callback('вњ… Р—Р°РІРµСЂС€РёС‚СЊ', 'route_sheet_done'),
      Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')
    ]
  ]);
}

function manualMileageKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('рџ“· Р—Р°РіСЂСѓР·РёС‚СЊ С„РѕС‚Рѕ РїРѕРІС‚РѕСЂРЅРѕ', 'retry_mileage_photo')],
    [
      Markup.button.callback('вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊ', 'skip_mileage'),
      Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')
    ]
  ]);
}

function replaceKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('рџџў РР·РјРµРЅРёС‚СЊ РЅР°С‡Р°Р»Рѕ', 'replace_start')],
    [Markup.button.callback('рџ”ґ РР·РјРµРЅРёС‚СЊ РєРѕРЅРµС†', 'replace_end')],
    [Markup.button.callback('вќЊ РћС‚РјРµРЅР°', 'back_to_menu')]
  ]);
}

function timeChangeKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('вњЏпёЏ РР·РјРµРЅРёС‚СЊ РІСЂРµРјСЏ', 'edit_time')]
  ]);
}

function mileageReplaceKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('рџџў РР·РјРµРЅРёС‚СЊ РїСЂРѕР±РµРі РЅР°С‡Р°Р»Р°', 'replace_mileage_start')],
    [Markup.button.callback('рџ”ґ РР·РјРµРЅРёС‚СЊ РїСЂРѕР±РµРі РєРѕРЅС†Р°', 'replace_mileage_end')],
    [Markup.button.callback('вќЊ РћС‚РјРµРЅР°', 'back_to_menu')]
  ]);
}

function switchUserKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('вњ… Р”Р°, СЃРјРµРЅРёС‚СЊ', 'confirm_switch_user')],
    [Markup.button.callback('вќЊ РћС‚РјРµРЅР°', 'back_to_menu')]
  ]);
}

function cashSubmitConfirmKeyboard() {
  return Markup.inlineKeyboard([
    [Markup.button.callback('вњ… Р”Р°, СЃРґР°Р»', 'cash_submit_yes')],
    [Markup.button.callback('вќЊ РќРµС‚, РЅРµ СЃРґР°Р»', 'cash_submit_no')],
    [Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')]
  ]);
}

function debtorListKeyboard(debtors, logistWorkplace) {
  const buttons = [];
  for (const debtor of debtors) {
    const activeReminders = getActiveRemindersForCourier(debtor.telegramId);
    let label = `рџ‘¤ ${debtor.fio} вЂ” ${debtor.formatted || debtor.amount} в‚Ѕ`;
    if (activeReminders.length > 0) {
      const remindedBy = activeReminders.map(r => r.logistFio).join(', ');
      label += ` рџ””(${remindedBy})`;
    }
    const selfClearance = getSelfClearanceRequest(debtor.telegramId);
    if (selfClearance) {
      label = `рџ‘¤ ${debtor.fio} вЂ” ${selfClearance.formatted || selfClearance.amount} в‚Ѕ вЏі`;
    }
    buttons.push([Markup.button.callback(label, `d_${debtor.telegramId}`)]);
  }
  if (buttons.length === 0) {
    return null;
  }
  buttons.push([Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')]);
  return Markup.inlineKeyboard(buttons);
}

module.exports = {
  mainMenu,
  courierMainMenu,
  profileMenu,
  workplaceMenu,
  deviceMenu,
  logistMainMenu,
  logistSettingsMenu,
  logistProfileMenu,
  getMenuForRole,
  getSettingsMenuForRole,
  getProfileMenuForRole,
  roleChoiceKeyboard,
  skipMileageKeyboard,
  mileageConfirmKeyboard,
  mileageSavedKeyboard,
  routeSheetKeyboard,
  manualMileageKeyboard,
  replaceKeyboard,
  timeChangeKeyboard,
  mileageReplaceKeyboard,
  switchUserKeyboard,
  cashSubmitConfirmKeyboard,
  debtorListKeyboard
};

```


---

## FILE: sheetCommand.js

```javascript
const { verifySheetAccess } = require('./services/googleSheets');
const {
  resolveSheetInfo,
  setWorkplaceSheetId,
  setWorkplaceSheetIdByMonth,
  getWorkplaceSheetIdByMonth,
  getWorkplaceMonthMap,
  getCurrentMonthKey,
  getNextMonthKey,
  isValidMonthKey
} = require('./services/storage');

function extractSheetId(text) {
  const value = String(text || '').trim();

  const match = value.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (match) return match[1];

  const urlMatch = value.match(/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
  if (urlMatch) return urlMatch[1];

  if (/^[a-zA-Z0-9_-]{20,}$/.test(value)) return value;
  return null;
}

function getWorkplaceFromToken(token) {
  const value = String(token || '').trim().toLowerCase();
  if (value === 'east' || value === 'РІРѕСЃС‚РѕРє') return 'РРњ Р’РѕСЃС‚РѕРє';
  if (value === 'center' || value === 'С†РµРЅС‚СЂ') return 'РРњ Р¦РµРЅС‚СЂ';
  return null;
}

function parseSheetSlotToken(token) {
  const value = String(token || '').trim().toLowerCase();
  if (!value) return null;

  if (value === 'active' || value === 'Р°РєС‚РёРІ' || value === 'current' || value === 'С‚РµРєСѓС‰РёР№' || value === 'СЌС‚РѕС‚') {
    const monthKey = getCurrentMonthKey();
    return { monthKey, slot: 'active', label: 'Р°РєС‚РёРІРЅС‹Р№ РјРµСЃСЏС†' };
  }

  if (value === 'next' || value === 'СЃР»РµРґСѓСЋС‰РёР№' || value === 'СЃР»РµРґ') {
    const monthKey = getNextMonthKey();
    return { monthKey, slot: 'next', label: 'СЃР»РµРґСѓСЋС‰РёР№ РјРµСЃСЏС†' };
  }

  if (isValidMonthKey(value)) {
    return { monthKey: value, slot: 'custom', label: `РјРµСЃСЏС† ${value}` };
  }

  return null;
}

function extractMonthKeyFromTitle(title) {
  const text = String(title || '').toLowerCase().replace(/С‘/g, 'Рµ');

  let match = text.match(/\b(20\d{2})[._\-/\s](0?[1-9]|1[0-2])\b/);
  if (match) {
    return `${match[1]}-${String(Number(match[2])).padStart(2, '0')}`;
  }

  match = text.match(/\b(0?[1-9]|1[0-2])[._\-/\s](20\d{2})\b/);
  if (match) {
    return `${match[2]}-${String(Number(match[1])).padStart(2, '0')}`;
  }

  const yearMatch = text.match(/\b(20\d{2})\b/);
  if (!yearMatch) return null;
  const year = yearMatch[1];

  const monthPatterns = [
    { month: '01', patterns: [/СЏРЅРІР°СЂ/] },
    { month: '02', patterns: [/С„РµРІСЂР°Р»/] },
    { month: '03', patterns: [/\bРјР°СЂС‚\b|\bРјР°СЂ\b/] },
    { month: '04', patterns: [/Р°РїСЂРµР»/] },
    { month: '05', patterns: [/\bРјР°Р№\b|\bРјР°СЏ\b/] },
    { month: '06', patterns: [/РёСЋРЅ/] },
    { month: '07', patterns: [/РёСЋР»/] },
    { month: '08', patterns: [/Р°РІРіСѓСЃС‚/] },
    { month: '09', patterns: [/СЃРµРЅС‚СЏР±СЂ/] },
    { month: '10', patterns: [/РѕРєС‚СЏР±СЂ/] },
    { month: '11', patterns: [/РЅРѕСЏР±СЂ/] },
    { month: '12', patterns: [/РґРµРєР°Р±СЂ/] }
  ];

  for (const item of monthPatterns) {
    if (item.patterns.some((pattern) => pattern.test(text))) {
      return `${year}-${item.month}`;
    }
  }

  return null;
}

function registerSheetCommand(bot, options = {}) {
  const esc = options.esc || ((value) => String(value || ''));
  // РџРѕ СѓРјРѕР»С‡Р°РЅРёСЋ Р±РµСЂС‘Рј WORKPLACES РёР· config.js. options.workplaces РѕСЃС‚Р°РІР»РµРЅРѕ
  // РґР»СЏ РѕР±СЂР°С‚РЅРѕР№ СЃРѕРІРјРµСЃС‚РёРјРѕСЃС‚Рё (РјРѕР¶РЅРѕ РїРµСЂРµРѕРїСЂРµРґРµР»РёС‚СЊ РёР· bot.js).
  const { WORKPLACES: defaultWorkplaces } = require('./config');
  const workplaces = options.workplaces || defaultWorkplaces;
  const isAdminUser = options.isAdminUser || ((id) => false);

  bot.command('sheet', async (ctx) => {
    // Р—Р°С‰РёС‚Р° РѕС‚ РІС‹Р·РѕРІР° РёР· РєР°РЅР°Р»Р° / РЅРµРїРѕРґРґРµСЂР¶РёРІР°РµРјС‹С… Р°РїРґРµР№С‚РѕРІ:
    // РІ РєР°РЅР°Р»-РїРѕСЃС‚Р°С… ctx.from РјРѕР¶РµС‚ Р±С‹С‚СЊ undefined, Р° ctx.message вЂ” null.
    if (!ctx.from || !ctx.from.id) return;
    if (!ctx.message) return;

    const adminIds = (process.env.ADMIN_IDS || '').split(',').map((id) => Number(id.trim())).filter(Number.isFinite);

    if (adminIds.length === 0) {
      await ctx.replyWithHTML('в›” РљРѕРјР°РЅРґР° РѕС‚РєР»СЋС‡РµРЅР°: РЅРµ РЅР°СЃС‚СЂРѕРµРЅ <code>ADMIN_IDS</code> РІ .env.');
      return;
    }

    if (!isAdminUser(ctx.from.id)) {
      await ctx.replyWithHTML('в›” Р­С‚Р° РєРѕРјР°РЅРґР° РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
      return;
    }

    const text = (ctx.message.text || '').trim();
    const parts = text.split(/\s+/);
    const subcommand = (parts[1] || '').toLowerCase();
    const currentMonth = getCurrentMonthKey();
    const nextMonth = getNextMonthKey();

    if (!subcommand || subcommand === 'list' || subcommand === 'СЃРїРёСЃРѕРє') {
      let message = 'рџ“‹ <b>РџСЂРёРІСЏР·РєР° С‚Р°Р±Р»РёС†</b>\n\n';
      message += `рџ—“ РђРєС‚РёРІРЅС‹Р№ РјРµСЃСЏС†: <code>${esc(currentMonth)}</code>\n`;
      message += `рџ—“ РЎР»РµРґСѓСЋС‰РёР№ РјРµСЃСЏС†: <code>${esc(nextMonth)}</code>\n\n`;

      for (const workplace of workplaces) {
        const active = resolveSheetInfo(workplace);
        const currentId = getWorkplaceSheetIdByMonth(workplace, currentMonth);
        const nextId = getWorkplaceSheetIdByMonth(workplace, nextMonth);
        const sourceText = active.source === 'monthly'
          ? 'РїРѕРјРµСЃСЏС‡РЅР°СЏ РїСЂРёРІСЏР·РєР°'
          : active.source === 'legacy'
            ? 'legacy (СЃС‚Р°СЂС‹Р№ С„РѕСЂРјР°С‚)'
            : active.source === 'fallback'
              ? 'fallback РёР· .env'
              : 'РЅРµ Р·Р°РґР°РЅРѕ';

        message += `рџЏ¬ <b>${esc(workplace)}</b>\n`;
        message += `   РђРєС‚РёРІРЅР°СЏ (${esc(currentMonth)}): <code>${esc(active.sheetId || 'РЅРµ Р·Р°РґР°РЅР°')}</code>\n`;
        message += `   РЎР»РµРґСѓСЋС‰Р°СЏ (${esc(nextMonth)}): <code>${esc(nextId || 'РЅРµ Р·Р°РґР°РЅР°')}</code>\n`;
        message += `   РСЃС‚РѕС‡РЅРёРє: ${esc(sourceText)}\n`;

        if (!currentId && active.noSheetForMonth) {
          message += '   вљ пёЏ РќР° Р°РєС‚РёРІРЅС‹Р№ РјРµСЃСЏС† С‚Р°Р±Р»РёС†Р° РЅРµ РїСЂРёРІСЏР·Р°РЅР° вЂ” Р·Р°РїРёСЃСЊ Р±Р»РѕРєРёСЂСѓРµС‚СЃСЏ\n';
        }

        if (active.source !== 'monthly') {
          message += '   вљ пёЏ Р РµРєРѕРјРµРЅРґСѓРµС‚СЃСЏ Р·Р°РґР°С‚СЊ <code>active</code> Рё <code>next</code> РІСЂСѓС‡РЅСѓСЋ\n';
        }

        const knownMonths = Object.keys(getWorkplaceMonthMap(workplace)).sort();
        if (knownMonths.length > 0) {
          message += `   РњРµСЃСЏС†С‹ РІ Р±Р°Р·Рµ: ${esc(knownMonths.join(', '))}\n`;
        }

        message += '\n';
      }

      message += 'РљРѕРјР°РЅРґС‹:\n';
      message += '<code>/sheet east active URL</code> вЂ” РґРѕР±Р°РІРёС‚СЊ Рё СЃРґРµР»Р°С‚СЊ Р°РєС‚РёРІРЅРѕР№\n';
      message += '<code>/sheet east next URL</code> вЂ” РґРѕР±Р°РІРёС‚СЊ РЅР° СЃР»РµРґСѓСЋС‰РёР№ РјРµСЃСЏС†\n';
      message += '<code>/sheet center active URL</code>\n';
      message += '<code>/sheet center next URL</code>\n';
      message += '<code>/sheet east URL</code> вЂ” Р°РІС‚Рѕ РїРѕ РЅР°Р·РІР°РЅРёСЋ РјРµСЃСЏС†Р°\n';
      message += '<code>/sheet reset east active</code>\n';
      message += '<code>/sheet reset center next</code>';

      await ctx.replyWithHTML(message);
      return;
    }

    if (subcommand === 'reset') {
      const targetToken = (parts[2] || '').toLowerCase();
      const workplace = getWorkplaceFromToken(parts[2]);
      const resetTarget = (parts[3] || 'active').toLowerCase();

      if (targetToken === 'all' || targetToken === 'РІСЃРµ') {
        for (const item of workplaces) {
          const monthMap = getWorkplaceMonthMap(item);
          for (const monthKey of Object.keys(monthMap)) {
            setWorkplaceSheetIdByMonth(item, monthKey, '');
          }
          setWorkplaceSheetId(item, '');
        }
        await ctx.replyWithHTML('вњ… Р’СЃРµ РїСЂРёРІСЏР·РєРё РґР»СЏ РІСЃРµС… РјР°РіР°Р·РёРЅРѕРІ СЃР±СЂРѕС€РµРЅС‹.');
        return;
      }

      if (!workplace) {
        await ctx.replyWithHTML('вќЊ РЈРєР°Р¶РёС‚Рµ РјР°РіР°Р·РёРЅ: <code>/sheet reset east active</code> РёР»Рё <code>/sheet reset center next</code> (РёР»Рё <code>/sheet reset all</code>).');
        return;
      }

      if (resetTarget === 'all' || resetTarget === 'РІСЃРµ') {
        const monthMap = getWorkplaceMonthMap(workplace);
        for (const monthKey of Object.keys(monthMap)) {
          setWorkplaceSheetIdByMonth(workplace, monthKey, '');
        }
        setWorkplaceSheetId(workplace, '');
        await ctx.replyWithHTML(`вњ… Р’СЃРµ РїСЂРёРІСЏР·РєРё РґР»СЏ <b>${esc(workplace)}</b> СЃР±СЂРѕС€РµРЅС‹.`);
        return;
      }

      const slot = parseSheetSlotToken(resetTarget);
      if (!slot) {
        await ctx.replyWithHTML('вќЊ РЈРєР°Р¶РёС‚Рµ СЂРµР¶РёРј: <code>active</code>, <code>next</code> РёР»Рё <code>YYYY-MM</code>.');
        return;
      }

      setWorkplaceSheetIdByMonth(workplace, slot.monthKey, '');
      await ctx.replyWithHTML(`вњ… РџСЂРёРІСЏР·РєР° РґР»СЏ <b>${esc(workplace)}</b> (${esc(slot.label)}: <code>${esc(slot.monthKey)}</code>) СѓРґР°Р»РµРЅР°.`);
      return;
    }

    const workplace = getWorkplaceFromToken(subcommand);
    if (!workplace) {
      await ctx.replyWithHTML(
        'вќЊ РЈРєР°Р¶РёС‚Рµ РјР°РіР°Р·РёРЅ:\n\n' +
        '<code>/sheet east active URL</code>\n' +
        '<code>/sheet center next URL</code>\n\n' +
        'РР»Рё <code>/sheet</code> РґР»СЏ РїСЂРѕСЃРјРѕС‚СЂР° С‚РµРєСѓС‰РёС… С‚Р°Р±Р»РёС†.'
      );
      return;
    }

    const args = parts.slice(2);
    if (args.length === 0) {
      const active = resolveSheetInfo(workplace);
      const currentId = getWorkplaceSheetIdByMonth(workplace, currentMonth);
      const nextId = getWorkplaceSheetIdByMonth(workplace, nextMonth);
      await ctx.replyWithHTML(
        `рџ“‹ <b>${esc(workplace)}</b>\n\n` +
        `РђРєС‚РёРІРЅР°СЏ (${esc(currentMonth)}): <code>${esc(active.sheetId || 'РЅРµ Р·Р°РґР°РЅР°')}</code>\n` +
        `РЎР»РµРґСѓСЋС‰Р°СЏ (${esc(nextMonth)}): <code>${esc(nextId || 'РЅРµ Р·Р°РґР°РЅР°')}</code>\n\n` +
        'РџСЂРёРјРµСЂ:\n' +
        `<code>/sheet ${subcommand} active URL_РўРђР‘Р›РР¦Р«</code>\n` +
        `<code>/sheet ${subcommand} next URL_РўРђР‘Р›РР¦Р«</code>`
      );
      return;
    }

    let targetSlot = null;
    let monthKey = null;
    let sheetArg = '';

    const parsedSlot = parseSheetSlotToken(args[0]);
    if (parsedSlot) {
      targetSlot = parsedSlot.slot;
      monthKey = parsedSlot.monthKey;
      sheetArg = args.slice(1).join(' ');
    } else {
      sheetArg = args.join(' ');
    }

    const sheetId = extractSheetId(sheetArg);
    if (!sheetId) {
      await ctx.replyWithHTML('вќЊ РќРµ СѓРґР°Р»РѕСЃСЊ РёР·РІР»РµС‡СЊ ID С‚Р°Р±Р»РёС†С‹ РёР· СЃСЃС‹Р»РєРё.\n\nРћС‚РїСЂР°РІСЊС‚Рµ СЃСЃС‹Р»РєСѓ РІРёРґР°:\n<code>https://docs.google.com/spreadsheets/d/...</code>');
      return;
    }

    const modeText = targetSlot === 'active'
      ? 'Р°РєС‚РёРІРЅР°СЏ'
      : targetSlot === 'next'
        ? 'СЃР»РµРґСѓСЋС‰РёР№ РјРµСЃСЏС†'
        : 'Р°РІС‚Рѕ';

    await ctx.replyWithHTML(`вЏі РџСЂРѕРІРµСЂСЏСЋ С‚Р°Р±Р»РёС†Сѓ РґР»СЏ <b>${esc(workplace)}</b> (СЂРµР¶РёРј: ${esc(modeText)})...`);

    try {
      const result = await verifySheetAccess(sheetId);

      if (!result.ok) {
        await ctx.replyWithHTML(
          `вќЊ <b>РћС€РёР±РєР° РґРѕСЃС‚СѓРїР°</b>\n\n${esc(result.error)}\n\n` +
          'РЈР±РµРґРёС‚РµСЃСЊ, С‡С‚Рѕ:\n' +
          '1. РўР°Р±Р»РёС†Р° СЃСѓС‰РµСЃС‚РІСѓРµС‚\n' +
          '2. Р”Р°РЅ РґРѕСЃС‚СѓРї: <code>courier-shift-bot@courier-shift-bot.iam.gserviceaccount.com</code>\n' +
          '3. Р’ С‚Р°Р±Р»РёС†Рµ РµСЃС‚СЊ Р»РёСЃС‚С‹ В«РљСѓСЂСЊРµСЂС‹В» Рё В«РџСЂРѕР±РµРіВ» / В«РџСЂРѕР±РµРі РљСѓСЂСЊРµСЂС‹В»'
        );
        return;
      }

      const titleMonth = extractMonthKeyFromTitle(result.title);
      if (!monthKey) {
        if (!titleMonth) {
          await ctx.replyWithHTML(
            'вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РѕРїСЂРµРґРµР»РёС‚СЊ РјРµСЃСЏС† РїРѕ РЅР°Р·РІР°РЅРёСЋ С‚Р°Р±Р»РёС†С‹.\n' +
            'РСЃРїРѕР»СЊР·СѓР№С‚Рµ СЏРІРЅС‹Р№ СЂРµР¶РёРј:\n' +
            `<code>/sheet ${subcommand} active URL</code> РёР»Рё <code>/sheet ${subcommand} next URL</code>.`
          );
          return;
        }
        monthKey = titleMonth;
      }

      setWorkplaceSheetIdByMonth(workplace, monthKey, sheetId);

      const boundAs = monthKey === currentMonth
        ? 'Р°РєС‚РёРІРЅР°СЏ С‚Р°Р±Р»РёС†Р°'
        : monthKey === nextMonth
          ? 'С‚Р°Р±Р»РёС†Р° РЅР° СЃР»РµРґСѓСЋС‰РёР№ РјРµСЃСЏС†'
          : `С‚Р°Р±Р»РёС†Р° РЅР° ${monthKey}`;

      let message = `вњ… <b>РўР°Р±Р»РёС†Р° РїСЂРёРІСЏР·Р°РЅР°!</b>\n\n` +
        `рџЏ¬ РњР°РіР°Р·РёРЅ: <b>${esc(workplace)}</b>\n` +
        `рџ—‚ Р РµР¶РёРј: <b>${esc(boundAs)}</b>\n` +
        `рџ—“ РњРµСЃСЏС†: <code>${esc(monthKey)}</code>\n` +
        `рџ“Љ РќР°Р·РІР°РЅРёРµ: <b>${esc(result.title)}</b>\n` +
        `рџ†” ID: <code>${esc(sheetId)}</code>`;

      if (titleMonth) {
        message += `\n\nв„№пёЏ РњРµСЃСЏС† РёР· РЅР°Р·РІР°РЅРёСЏ С‚Р°Р±Р»РёС†С‹: <code>${esc(titleMonth)}</code>.`;
        if (titleMonth !== monthKey) {
          message += ' РџСЂРѕРІРµСЂСЊС‚Рµ, С‡С‚Рѕ РІС‹Р±СЂР°Р»Рё РїСЂР°РІРёР»СЊРЅС‹Р№ СЂРµР¶РёРј (active/next).';
        }
      }

      const active = resolveSheetInfo(workplace);
      if (active.sheetId) {
        message += `\n\nвњ… РђРєС‚РёРІРЅР°СЏ СЃРµР№С‡Р°СЃ (${esc(currentMonth)}): <code>${esc(active.sheetId)}</code>`;
      } else if (active.missingForMonth) {
        message += `\n\nвљ пёЏ Р”Р»СЏ С‚РµРєСѓС‰РµРіРѕ РјРµСЃСЏС†Р° <code>${esc(active.monthKey)}</code> С‚Р°Р±Р»РёС†Р° РЅРµ Р·Р°РґР°РЅР°.`;
      }

      await ctx.replyWithHTML(message);
      console.log('sheet changed', workplace, monthKey, sheetId, result.title);
    } catch (error) {
      console.error('sheet command error', error);
      await ctx.replyWithHTML('вљ пёЏ РџСЂРѕРёР·РѕС€Р»Р° РѕС€РёР±РєР° РїСЂРё РїСЂРѕРІРµСЂРєРµ С‚Р°Р±Р»РёС†С‹.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.');
    }
  });
}

module.exports = {
  registerSheetCommand
};

```


---

## FILE: logger.js

```javascript
const fs = require('fs');
const path = require('path');

const logPath = path.join(__dirname, 'bot.log');
const MAX_LOG_SIZE = 50 * 1024 * 1024;

const _origLog = console.log.bind(console);
const _origError = console.error.bind(console);

function _format(level, ...args) {
  const ts = new Date().toISOString();
  const msg = args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
  return `${ts} [${level}] ${msg}\n`;
}

function _write(line) {
  try {
    fs.appendFileSync(logPath, line, 'utf8');
    const stat = fs.statSync(logPath);
    if (stat.size > MAX_LOG_SIZE) {
      const content = fs.readFileSync(logPath, 'utf8');
      const lines = content.split('\n');
      const keep = lines.slice(Math.floor(lines.length / 2)).join('\n');
      fs.writeFileSync(logPath, keep, 'utf8');
    }
  } catch (_) {}
}

function initLogger() {
  console.log = function (...args) {
    _origLog(...args);
    _write(_format('INFO', ...args));
  };
  console.error = function (...args) {
    _origError(...args);
    _write(_format('ERROR', ...args));
  };
}

module.exports = { initLogger };

```


---

## FILE: ecosystem.config.js

```javascript
module.exports = {
  apps: [
    {
      name: 'courier-shift-bot',
      script: 'bot.js',
      cwd: __dirname,
      autorestart: true,
      max_restarts: 30,
      restart_delay: 5000,
      min_uptime: '10s',
      wait_ready: false,
      listen_timeout: 30000,
      env: {
        NODE_ENV: 'production',
        RAPIDOCR_URL: 'http://127.0.0.1:9527',
      },
    },
    {
      name: 'rapidocr-server',
      script: 'rapidocr_server.py',
      args: '--server',
      interpreter: './venv/bin/python',
      interpreter_args: '',
      cwd: __dirname,
      autorestart: true,
      max_restarts: 10,
      restart_delay: 3000,
      min_uptime: '5s',
      env: {
        RAPIDOCR_PORT: '9527',
        OCR_MIN_MILEAGE: '1000',
        RAPIDOCR_MIN_COUNT: '1',
        RAPIDOCR_MIN_AVG_CONF: '0.55',
        RAPIDOCR_MIN_MAX_CONF: '0.68',
      },
    },
  ],
};
```


---

## FILE: bot.js

```javascript
require('dotenv').config();
require('./logger').initLogger();

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { execSync } = require('child_process');

const crypto = require('crypto');

const { Telegraf, Markup } = require('telegraf');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { SocksProxyAgent } = require('socks-proxy-agent');
const {
  initGoogleSheets,
  findCourierInAllSheets,
  punchTime,
  prepareMileage,
  replaceTime,
  updateCourierTime,
  updateMileage,
  readCell,
  getSheetConfig,
  updateEfficiencyOrders
} = require('./services/googleSheets');
const {
  getUserField,
  getFullProfile,
  setUserField,
  getUserRole,
  deleteUser,
  getPendingCash,
  setPendingCash,
  deletePendingCash,
  setCashConfirmationStatus,
  clearPendingCashAndReminders,
  getAllUserIds,
  resolveSheetInfo,
  flushNow: flushStorageNow,
  getSheetAccessUsers,
  addSheetAccessUser,
  removeSheetAccessUser,
  isSheetAccessUser,
  markUserSeen,
  cleanupOldMonths,
  getCurrentMonthKey,
  getNextMonthKey,
  getWorkplaceSheetIdByMonth,
  logCashAction,
  getCashHistory,
  getDebtors,
  findLogistsForWorkplace,
  setReminder,
  getReminder,
  updateReminder,
  deleteReminder,
  getActiveRemindersForCourier,
  getSelfClearanceRequest,
  cleanupStaleReminders
} = require('./services/storage');
const { recognizeMileage, downloadTelegramFile, isRapidOcrEnabled, recognizeTextWithRapidOcr, getMinMileageThreshold, checkRapidOcrHealth } = require('./services/mileageOcr');
const { saveOcrDebugImage, updateOcrDebugStatus } = require('./services/ocrDebug');
const { recordOrders: recordLeaderboardOrders, calculateLeaderboard, formatLeaderboard, checkNotifications: checkLeaderboardNotifications, flushNow: flushLeaderboardNow, getDayOrders: getLbDayOrders, getWorkplaceRecord, setWorkplaceRecord, getDailyTop3, findOvertakenCouriers, getTodayKey: getLbTodayKey } = require('./services/leaderboard');
const { addXp, getTotalXp, getRank, getRankProgress, formatRankInfo, getXpForAction } = require('./services/xp');
const { checkMilestoneAchievements, unlockAchievement, getUnlockedAchievements, getAllAchievements } = require('./services/achievements');
const { updateStreak, getStreak, getStreakBonus } = require('./services/streak');
const { updateChallengeProgress, generateWeeklyChallenges, getChallenges } = require('./services/challenges');
const { getCurrentDateInfo, getColumnLetter, getMileageColumnsByDay, roundMinutesToHalfHour } = require('./utils');
const { registerSheetCommand } = require('./sheetCommand');
const { WORKPLACES, DEVICES, ROLES, LIMITS, WORKPLACE_FEATURES, WORKPLACE_KEY_MAP, BUTTONS } = require('./config');
const { isAdminUser, getAdminIds } = require('./services/auth');
const {
  mainMenu,
  profileMenu,
  workplaceMenu,
  deviceMenu,
  logistMainMenu,
  logistSettingsMenu,
  logistProfileMenu,
  getMenuForRole,
  getSettingsMenuForRole,
  getProfileMenuForRole,
  roleChoiceKeyboard,
  skipMileageKeyboard,
  mileageConfirmKeyboard,
  mileageSavedKeyboard,
  routeSheetKeyboard,
  manualMileageKeyboard,
  replaceKeyboard,
  timeChangeKeyboard,
  mileageReplaceKeyboard,
  switchUserKeyboard,
  cashSubmitConfirmKeyboard,
  debtorListKeyboard
} = require('./menus/keyboards');

const db = require('./db');
const { checkpoint } = require('./db');

function getState(telegramId) {
  const row = db.prepare('SELECT data FROM states WHERE telegramId = ?').get(String(telegramId));
  if (!row) return null;
  try {
    return JSON.parse(row.data);
  } catch {
    return null;
  }
}

function setState(telegramId, state) {
  const stmt = db.prepare('INSERT OR REPLACE INTO states (telegramId, data) VALUES (?, ?)');
  stmt.run(String(telegramId), JSON.stringify(state));
}

function clearState(telegramId) {
  db.prepare('DELETE FROM states WHERE telegramId = ?').run(String(telegramId));
}

function flushStateNow() {
  // SQLite WAL is persistent.
}

const versionPath = path.join(__dirname, 'version.json');
const changelogPath = path.join(__dirname, 'changelog.json');
const _sourceDir = __dirname;

function _getCurrentVersion() {
  try {
    if (!fs.existsSync(versionPath)) {
      return null;
    }
    return JSON.parse(fs.readFileSync(versionPath, 'utf8'));
  } catch {
    return null;
  }
}

function _getSourceFiles() {
  return fs.readdirSync(_sourceDir)
    .filter((f) => f.endsWith('.js') && f !== 'version.js')
    .sort();
}

function _computeSourceSnapshot() {
  const jsFiles = _getSourceFiles();
  const fileHashes = {};
  const combinedHash = crypto.createHash('sha256');
  for (const file of jsFiles) {
    const filePath = path.join(_sourceDir, file);
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const fileHash = crypto.createHash('sha256').update(content).digest('hex');
      fileHashes[file] = fileHash;
      combinedHash.update(file);
      combinedHash.update(fileHash);
    } catch {
    }
  }
  return {
    hash: combinedHash.digest('hex'),
    files: fileHashes
  };
}

function _getChangedFiles(previousFiles, currentFiles) {
  const prev = previousFiles || {};
  const next = currentFiles || {};
  const allFiles = new Set([...Object.keys(prev), ...Object.keys(next)]);
  return [...allFiles]
    .filter((file) => prev[file] !== next[file])
    .sort();
}

function _getCurrentGitHash() {
  try {
    return execSync('git rev-parse HEAD', { encoding: 'utf8', cwd: __dirname }).trim();
  } catch {
    return null;
  }
}

const COMMIT_PREFIX_RU = {
  feat: 'вњЁ Р”РѕР±Р°РІР»РµРЅРѕ',
  fix: 'рџ”§ РСЃРїСЂР°РІР»РµРЅРѕ',
  refactor: 'в™»пёЏ РџРµСЂРµСЂР°Р±РѕС‚Р°РЅРѕ',
  chore: 'рџ”§ РўРµС…РЅРёС‡РµСЃРєРѕРµ',
  docs: 'рџ“ќ Р”РѕРєСѓРјРµРЅС‚Р°С†РёСЏ',
  style: 'рџЋЁ РћС„РѕСЂРјР»РµРЅРёРµ',
  perf: 'вљЎ РћРїС‚РёРјРёР·Р°С†РёСЏ',
  test: 'рџ§Є РўРµСЃС‚С‹',
  build: 'рџ“¦ РЎР±РѕСЂРєР°',
  ci: 'вљ™пёЏ CI/CD',
  revert: 'в†©пёЏ РћС‚РєР°С‚'
};

function _getGitLogSince(fromHash) {
  if (!fromHash) return null;
  try {
    const log = execSync(`git log --oneline --no-merges ${fromHash}..HEAD`, { encoding: 'utf8', cwd: __dirname });
    return log.split('\n')
      .map(line => line.trim())
      .filter(Boolean)
      .map(line => {
        let msg = line.replace(/^[0-9a-f]+\s+/, '');
        const prefixMatch = msg.match(/^(feat|fix|refactor|chore|docs|style|perf|test|build|ci|revert):\s*/i);
        if (prefixMatch) {
          const prefix = prefixMatch[1].toLowerCase();
          const ruPrefix = COMMIT_PREFIX_RU[prefix] || prefix;
          msg = msg.slice(prefixMatch[0].length);
          msg = msg.charAt(0).toUpperCase() + msg.slice(1);
          return `${ruPrefix}: ${msg}`;
        }
        if (msg.match(/^(\p{Emoji_Presentation}|\p{Extended_Pictographic})\s*/u)) {
          return msg.charAt(0).toUpperCase() + msg.slice(1);
        }
        msg = msg.charAt(0).toUpperCase() + msg.slice(1);
        return msg;
      })
      .filter(msg => msg.length > 0);
  } catch {
    return null;
  }
}

function _bumpVersion(version, bumpType) {
  const parts = version.split('.').map(Number);
  if (bumpType === 'major') {
    parts[0] += 1;
    parts[1] = 0;
    parts[2] = 0;
  } else if (bumpType === 'minor') {
    parts[1] += 1;
    parts[2] = 0;
  } else {
    parts[2] = (parts[2] || 0) + 1;
  }
  return parts.join('.');
}

function checkVersion() {
  const snapshot = _computeSourceSnapshot();
  const currentHash = snapshot.hash;
  const currentFiles = snapshot.files;
  const stored = _getCurrentVersion();
  if (!stored) {
    const initialVersion = '2.0.0';
    const gitHash = _getCurrentGitHash();
    const data = {
      version: initialVersion,
      lastHash: currentHash,
      files: currentFiles,
      updatedAt: new Date().toISOString(),
      gitHash: gitHash || undefined,
      updates: []
    };
    fs.writeFileSync(versionPath, JSON.stringify(data, null, 2), 'utf8');
    return {
      version: initialVersion,
      changed: true,
      prevVersion: null,
      changedFiles: Object.keys(currentFiles).sort(),
      updates: []
    };
  }
  if (stored.lastHash === currentHash) {
    return { version: stored.version, changed: false, prevVersion: null, changedFiles: [], updates: stored.updates || [] };
  }
  const changedFiles = _getChangedFiles(stored.files, currentFiles);
  const bumpType = getChangelogBump();
  const newVersion = _bumpVersion(stored.version, bumpType);
  let updates = _getGitLogSince(stored.gitHash);
  if (!updates || updates.length === 0) {
    updates = null;
  }
  const gitHash = _getCurrentGitHash();
  const data = {
    version: newVersion,
    lastHash: currentHash,
    files: currentFiles,
    updatedAt: new Date().toISOString(),
    gitHash: gitHash || undefined,
    updates: updates || []
  };
  fs.writeFileSync(versionPath, JSON.stringify(data, null, 2), 'utf8');
  console.log(`version bumped: ${stored.version} в†’ ${newVersion} (${bumpType})`);
  return { version: newVersion, changed: true, prevVersion: stored.version, changedFiles, updates: updates || [] };
}

function getVersion() {
  const stored = _getCurrentVersion();
  return stored ? stored.version : '2.0.0';
}



// WORKPLACES, DEVICES вЂ” С‚РµРїРµСЂСЊ РёР· config.js (СЃРј. РёРјРїРѕСЂС‚ РІС‹С€Рµ)

function isLogist(telegramId) {
  return getUserRole(telegramId) === 'logist';
}

function requireRole(ctx, requiredRole) {
  const role = getUserRole(ctx.from.id);
  if (requiredRole === 'courier' && role === 'logist') {
    ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return false;
  }
  if (requiredRole === 'logist' && role !== 'logist') {
    ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ Р»РѕРіРёСЃС‚Р°Рј.', getMenuForRole(ctx.from.id));
    return false;
  }
  return true;
}

async function showDebtorsList(ctx) {
  const telegramId = ctx.from.id;
  const role = getUserRole(telegramId);
  if (role !== 'logist') {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ Р»РѕРіРёСЃС‚Р°Рј.', getMenuForRole(telegramId));
    return;
  }

  const workplace = getUserField(telegramId, 'workplace');
  if (!workplace) {
    await ctx.replyWithHTML('вљ пёЏ РЎРЅР°С‡Р°Р»Р° РІС‹Р±РµСЂРёС‚Рµ РјР°РіР°Р·РёРЅ РІ РЅР°СЃС‚СЂРѕР№РєР°С….', getSettingsMenuForRole(telegramId));
    return;
  }

  const features = WORKPLACE_FEATURES[workplace];
  if (!features || !features.cashCollection) {
    await ctx.replyWithHTML('вќЊ Р’ СЌС‚РѕРј РјР°РіР°Р·РёРЅРµ РїСЂРёС‘Рј РЅР°Р»РёС‡РЅС‹С… РЅРµ РїСЂРµРґСѓСЃРјРѕС‚СЂРµРЅ.', getMenuForRole(telegramId));
    return;
  }

  cleanupStaleReminders();

  const debtors = getDebtors(workplace);

  if (debtors.length === 0) {
    await ctx.replyWithHTML('вњ… Р’СЃРµ РґРµРЅСЊРіРё СЃРґР°РЅС‹, РґРѕР»РіРѕРІ РЅРµС‚.', getMenuForRole(telegramId));
    return;
  }

  const totalAmount = debtors.reduce((sum, d) => sum + d.amount, 0);
  const formattedTotal = formatMoneyRu(totalAmount);

  await ctx.replyWithHTML(
    `рџ’і <b>РљСѓСЂСЊРµСЂС‹ СЃ РґРѕР»РіР°РјРё</b> (${esc(workplace)})\n` +
    `Р’СЃРµРіРѕ Рє СЃРґР°С‡Рµ: <code>${formattedTotal}</code> в‚Ѕ\n\n` +
    `РќР°Р¶РјРёС‚Рµ РЅР° РєСѓСЂСЊРµСЂР°, С‡С‚РѕР±С‹ РѕС‚РїСЂР°РІРёС‚СЊ РЅР°РїРѕРјРёРЅР°РЅРёРµ:`,
    debtorListKeyboard(debtors, workplace)
  );
}

async function pokeCourier(ctx, courierId) {
  const logistId = ctx.from.id;
  const logistFio = getUserField(logistId, 'fio') || 'Р›РѕРіРёСЃС‚';
  const logistWorkplace = getUserField(logistId, 'workplace');
  const courierRecord = getUserField(courierId, 'fio') ? {
    fio: getUserField(courierId, 'fio'),
    workplace: getUserField(courierId, 'workplace')
  } : null;

  if (!courierRecord || !courierRecord.fio) {
    await ctx.answerCbQuery('вљ пёЏ РљСѓСЂСЊРµСЂ РЅРµ РЅР°Р№РґРµРЅ.');
    return;
  }

  const selfClearance = getSelfClearanceRequest(courierId);
  if (selfClearance) {
    await ctx.answerCbQuery();
    await ctx.replyWithHTML(
      `вЏі ${esc(courierRecord.fio)} СѓР¶Рµ РѕС‚РјРµС‚РёР» СЃРґР°С‡Сѓ.\n` +
      `РћР¶РёРґР°РµС‚ РїРѕРґС‚РІРµСЂР¶РґРµРЅРёСЏ: <code>${esc(selfClearance.formatted || String(selfClearance.amount))}</code> в‚Ѕ`,
      Markup.inlineKeyboard([
        [Markup.button.callback('вњ… РџРѕРґС‚РІРµСЂРґРёС‚СЊ', `sc_appr_${courierId}`)],
        [Markup.button.callback('вќЊ РћС‚РєР»РѕРЅРёС‚СЊ', `sc_decl_${courierId}`)]
      ])
    );
    return;
  }

  const pendingCash = getPendingCash(courierId);
  const amount = Number(pendingCash?.amount || 0);
  if (!Number.isFinite(amount) || amount < 1) {
    await ctx.answerCbQuery('вњ… РљСѓСЂСЊРµСЂ СѓР¶Рµ СЃРґР°Р» РґРµРЅСЊРіРё.');
    if (ctx.callbackQuery) {
      try { await ctx.editMessageText('вњ… РљСѓСЂСЊРµСЂ СѓР¶Рµ СЃРґР°Р» РґРµРЅСЊРіРё.'); } catch (e) { /* ignore */ }
    }
    return;
  }

  const formatted = pendingCash?.formatted || formatMoneyRu(amount);
  const shortId = crypto.randomBytes(4).toString('hex');

  const reminderData = {
    logistId: String(logistId),
    logistChatId: String(logistId),
    logistFio: logistFio,
    courierId: String(courierId),
    courierFio: courierRecord.fio,
    amount: amount,
    formatted: formatted,
    workplace: courierRecord.workplace || logistWorkplace,
    status: 'reminded',
    createdAt: new Date().toISOString(),
    logistMsgId: null,
    courierMsgId: null
  };

  setReminder(shortId, reminderData);

  logCashAction({
    logistId: String(logistId),
    logistFio: logistFio,
    courierId: String(courierId),
    courierFio: courierRecord.fio,
    workplace: courierRecord.workplace || logistWorkplace,
    amount: amount,
    action: 'reminded'
  });

  const workpalceLabel = courierRecord.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ';
  const courierMsg = `рџ”” <b>Р›РѕРіРёСЃС‚ ${esc(logistFio)} РЅР°РїРѕРјРёРЅР°РµС‚:</b>\n\n` +
    `рџ’µ РЈ РІР°СЃ <code>${esc(formatted)}</code> в‚Ѕ Рє СЃРґР°С‡Рµ.\n` +
    `рџЏ¬ <b>${esc(workpalceLabel)}</b>\n\n` +
    `РЎРґР°Р»Рё РґРµРЅСЊРіРё?`;

  try {
    const sent = await bot.telegram.sendMessage(courierId, courierMsg, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [Markup.button.callback('рџЏѓ РЈР¶Рµ Р±РµРіСѓ', `ack_${shortId}`)],
          [Markup.button.callback('вњ… РЎРґР°Р»', `c_${shortId}`)]
        ]
      }
    });

    const msgId = sent.message_id;
    updateReminder(shortId, { courierMsgId: msgId });

    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('вњ… РќР°РїРѕРјРёРЅР°РЅРёРµ РѕС‚РїСЂР°РІР»РµРЅРѕ');
      try {
        await ctx.editMessageText(`вњ… РќР°РїРѕРјРёРЅР°РЅРёРµ РѕС‚РїСЂР°РІР»РµРЅРѕ: <b>${esc(courierRecord.fio)}</b> вЂ” <code>${esc(formatted)}</code> в‚Ѕ`, { parse_mode: 'HTML' });
      } catch (e) { /* ignore */ }
    } else {
      await ctx.replyWithHTML(`вњ… РќР°РїРѕРјРёРЅР°РЅРёРµ РѕС‚РїСЂР°РІР»РµРЅРѕ: <b>${esc(courierRecord.fio)}</b> вЂ” <code>${esc(formatted)}</code> в‚Ѕ`);
    }
  } catch (e) {
    console.error('failed to send reminder to courier', e);
    deleteReminder(shortId);
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ СѓРІРµРґРѕРјР»РµРЅРёРµ РєСѓСЂСЊРµСЂСѓ.');
    } else {
      await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ СѓРІРµРґРѕРјР»РµРЅРёРµ РєСѓСЂСЊРµСЂСѓ. Р’РѕР·РјРѕР¶РЅРѕ, РѕРЅ Р·Р°Р±Р»РѕРєРёСЂРѕРІР°Р» Р±РѕС‚Р°.');
    }
  }
}

async function showCashHistory(ctx) {
  const telegramId = ctx.from.id;
  const role = getUserRole(telegramId);
  if (role !== 'logist') {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ Р»РѕРіРёСЃС‚Р°Рј.', getMenuForRole(telegramId));
    return;
  }

  const workplace = getUserField(telegramId, 'workplace');
  const features = WORKPLACE_FEATURES[workplace];
  if (!features || !features.cashCollection) {
    await ctx.replyWithHTML('вќЊ Р’ СЌС‚РѕРј РјР°РіР°Р·РёРЅРµ РїСЂРёС‘Рј РЅР°Р»РёС‡РЅС‹С… РЅРµ РїСЂРµРґСѓСЃРјРѕС‚СЂРµРЅ.', getMenuForRole(telegramId));
    return;
  }

  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const buttons = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', timeZone: timezone });
    const prefix = i === 0 ? 'рџ“… ' : '';
    buttons.push([Markup.button.callback(`${prefix}${dayLabel}`, `ch_${dateStr}`)]);
  }
  buttons.push([Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')]);

  await ctx.replyWithHTML('рџ“‹ <b>РСЃС‚РѕСЂРёСЏ СЃР±РѕСЂРѕРІ</b>\n\nР’С‹Р±РµСЂРёС‚Рµ РґР°С‚Сѓ:', Markup.inlineKeyboard(buttons));
}

async function showCashHistoryForDate(ctx, dateStr) {
  const telegramId = ctx.from.id;
  const workplace = getUserField(telegramId, 'workplace');
  const rows = getCashHistory(dateStr, workplace);

  const approvedRows = rows.filter(r => r.action === 'approved' || r.action === 'self_cleared' || r.action === 'logist_approved');

  if (approvedRows.length === 0) {
    await ctx.answerCbQuery();
    await ctx.replyWithHTML(`рџ“‹ <b>РСЃС‚РѕСЂРёСЏ СЃР±РѕСЂРѕРІ Р·Р° ${dateStr}</b>\n\nРќРµС‚ РїРѕРґС‚РІРµСЂР¶РґС‘РЅРЅС‹С… СЃРґР°С‡ Р·Р° СЌС‚Сѓ РґР°С‚Сѓ.`);
    return;
  }

  const total = approvedRows.reduce((sum, r) => sum + r.amount, 0);
  let msg = `рџ“‹ <b>РСЃС‚РѕСЂРёСЏ СЃР±РѕСЂРѕРІ Р·Р° ${dateStr}</b>\n` +
    `Р’СЃРµРіРѕ СЃРѕР±СЂР°РЅРѕ: <code>${formatMoneyRu(total)}</code> в‚Ѕ\n\n`;

  for (const row of approvedRows) {
    let icon = 'вњ…';
    if (row.action === 'self_cleared') icon = 'рџ’µ';
    else if (row.action === 'logist_approved') icon = 'рџ‘Ќ';
    let logistLabel;
    if (row.action === 'self_cleared') {
      logistLabel = ' (СЃР°РјРѕСЃС‚РѕСЏС‚РµР»СЊРЅРѕ)';
    } else if (row.action === 'logist_approved') {
      logistLabel = row.logistFio ? ` (Р»РѕРіРёСЃС‚: ${esc(row.logistFio)})` : ' (Р»РѕРіРёСЃС‚)';
    } else {
      logistLabel = row.logistFio ? ` (Р»РѕРіРёСЃС‚: ${esc(row.logistFio)})` : '';
    }
    msg += `${icon} ${esc(row.courierFio)} вЂ” <code>${formatMoneyRu(row.amount)}</code> в‚Ѕ${logistLabel}\n`;
  }

  await ctx.replyWithHTML(msg);
}

async function openShopNotify(ctx) {
  const telegramId = ctx.from.id;
  const role = getUserRole(telegramId);
  if (role !== 'logist') {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ Р»РѕРіРёСЃС‚Р°Рј.', getMenuForRole(telegramId));
    return;
  }

  const workplace = getUserField(telegramId, 'workplace');
  if (!workplace) {
    await ctx.replyWithHTML('вљ пёЏ РЎРЅР°С‡Р°Р»Р° РІС‹Р±РµСЂРёС‚Рµ РјР°РіР°Р·РёРЅ РІ РЅР°СЃС‚СЂРѕР№РєР°С….', getMenuForRole(telegramId));
    return;
  }

  const fio = getUserField(telegramId, 'fio') || 'Р›РѕРіРёСЃС‚';
  const chatId = process.env.SHOP_STATUS_CHAT_ID;
  if (chatId) {
    try {
      await bot.telegram.sendMessage(chatId,
        `рџЏЄ <b>${esc(workplace)} вЂ” РћРўРљР Р«Рў</b> вњ…\n\nР›РѕРіРёСЃС‚: ${esc(fio)}`,
        { parse_mode: 'HTML' }
      );
    } catch (e) {
      console.error('shop open notify error', e.message || e);
    }
  }

  await ctx.replyWithHTML(`вњ… РЈРІРµРґРѕРјР»РµРЅРёРµ РѕС‚РїСЂР°РІР»РµРЅРѕ: <b>${esc(workplace)} вЂ” РћРўРљР Р«Рў</b> вњ…`, getMenuForRole(telegramId));
}

async function notifyLogistsAboutSelfClearance(courierId, courierFio, amount, formatted, workplace) {
  const logists = findLogistsForWorkplace(workplace);

  const allRecipientIds = new Set();
  for (const logist of logists) {
    allRecipientIds.add(String(logist.telegramId));
  }

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('вњ… РџРѕРґС‚РІРµСЂРґРёС‚СЊ', `sc_appr_${courierId}`)],
    [Markup.button.callback('вќЊ РћС‚РєР»РѕРЅРёС‚СЊ', `sc_decl_${courierId}`)]
  ]);

  for (const recipientId of allRecipientIds) {
    try {
      await bot.telegram.sendMessage(recipientId,
        `рџ’° <b>РљСѓСЂСЊРµСЂ РѕС‚РјРµС‚РёР» СЃРґР°С‡Сѓ</b>\n\n` +
        `рџ‘¤ ${esc(courierFio)}\n` +
        `рџ’µ <code>${esc(formatted)}</code> в‚Ѕ\n` +
        `рџЏ¬ ${esc(workplace)}\n\n` +
        `РџРѕРґС‚РІРµСЂРґРёС‚Рµ СЃРґР°С‡Сѓ:`,
        { parse_mode: 'HTML', ...keyboard }
      );
    } catch (e) {
      console.error('failed to notify logist about self-clearance', recipientId, e.message);
    }
  }
}

if (!process.env.BOT_TOKEN) {
  throw new Error('BOT_TOKEN is not set');
}

function normalizeProxyUrl(value) {
  const text = String(value || '').trim();
  return text || null;
}

function createTelegramAgent() {
  const proxyUrl = normalizeProxyUrl(process.env.TELEGRAM_PROXY_URL)
    || normalizeProxyUrl(process.env.HTTPS_PROXY)
    || normalizeProxyUrl(process.env.HTTP_PROXY);

  if (!proxyUrl) return null;

  let parsed;
  try {
    parsed = new URL(proxyUrl);
  } catch (_) {
    console.error('Invalid TELEGRAM_PROXY_URL, proxy disabled');
    return null;
  }

  const protocol = String(parsed.protocol || '').toLowerCase();

  if (protocol.startsWith('socks')) {
    console.log('Telegram proxy enabled (SOCKS)');
    return new SocksProxyAgent(proxyUrl);
  }

  if (protocol === 'http:' || protocol === 'https:') {
    console.log('Telegram proxy enabled (HTTP/HTTPS)');
    return new HttpsProxyAgent(proxyUrl);
  }

  console.error(`Unsupported TELEGRAM_PROXY_URL protocol: ${protocol}`);
  return null;
}

const telegramAgent = createTelegramAgent();
const bot = new Telegraf(process.env.BOT_TOKEN, telegramAgent ? {
  telegram: { agent: telegramAgent }
} : undefined);
const photoLogPath = path.join(__dirname, 'photo-log.jsonl');
const routeSheetLogPath = path.join(__dirname, 'route-sheet-log.jsonl');
const reconciliationLogPath = path.join(__dirname, 'reconciliation-log.jsonl');
const funReactionsPath = path.join(__dirname, 'fun-reactions.json');
const lastFunReactionAt = new Map();
const FUN_REACTION_CLEANUP_INTERVAL = LIMITS.FUN_REACTION_CLEANUP_INTERVAL_MS;
let funReactionCleanupTimer = null;

function cleanupFunReactionCooldowns() {
  const now = Date.now();
  for (const [key, ts] of lastFunReactionAt) {
    if (now - ts > FUN_REACTION_CLEANUP_INTERVAL) {
      lastFunReactionAt.delete(key);
    }
  }
}

function startFunReactionCleanup() {
  if (!funReactionCleanupTimer) {
    funReactionCleanupTimer = setInterval(cleanupFunReactionCooldowns, FUN_REACTION_CLEANUP_INTERVAL);
    funReactionCleanupTimer.unref();
  }
}

startFunReactionCleanup();

let funReactionsCache = null;
let funReactionsWriteScheduled = false;

const SUCCESS_STICKER_EMOJIS = new Set(['рџЂ', 'рџЃ', 'рџ„', 'рџЋ', 'рџҐі', 'рџЋ‰', 'вњЁ', 'рџ”Ґ', 'рџ’Є', 'рџ‘Ќ', 'рџ‘Џ', 'вњ…']);
const ERROR_STICKER_EMOJIS = new Set(['рџў', 'рџ­', 'рџї', 'рџћ', 'рџЈ', 'рџ«', 'рџ¤¦', 'рџ™€', 'рџЎ', 'рџ¤', 'рџљ«', 'вќЊ', 'вљ пёЏ']);

function esc(text) {
  return String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function isButton(text, button, legacyText) {
  return text === button || text === legacyText;
}

function formatStage(stage) {
  return stage === 'start' ? 'РЅР°С‡Р°Р»Рѕ СЃРјРµРЅС‹' : 'РєРѕРЅРµС† СЃРјРµРЅС‹';
}

function getTimeGreeting(timezone = process.env.APP_TIMEZONE || 'Europe/Moscow') {
  const hour = parseInt(new Date().toLocaleString('en-GB', { timeZone: timezone, hour: 'numeric', hour12: false }));
  if (hour >= 5 && hour < 12) return 'Р”РѕР±СЂРѕРµ СѓС‚СЂРѕ';
  if (hour >= 12 && hour < 18) return 'Р”РѕР±СЂС‹Р№ РґРµРЅСЊ';
  if (hour >= 18 && hour < 23) return 'Р”РѕР±СЂС‹Р№ РІРµС‡РµСЂ';
  return 'Р”РѕР±СЂРѕР№ РЅРѕС‡Рё';
}

function formatPhotoStatus(stage) {
  return stage === 'start' ? 'рџџў РЎС‚Р°СЂС‚' : 'рџ”ґ РљРѕРЅРµС†';
}

function getEmployeeDisplayName(fio) {
  const parts = String(fio || '').trim().split(/\s+/);
  if (parts.length >= 2) {
    return parts[1] + ' ' + parts[0];
  }
  return fio || '';
}

// Telegram РѕРіСЂР°РЅРёС‡РёРІР°РµС‚ caption РґРѕ 1024 СЃРёРјРІРѕР»РѕРІ (РќР• 4096 РєР°Рє РґР»СЏ С‚РµРєСЃС‚Р°).
// Р”Р»РёРЅРЅРѕРµ Р¤РРћ + РјР°РіР°Р·РёРЅ РјРѕРіСѓС‚ РїСЂРµРІС‹СЃРёС‚СЊ Р»РёРјРёС‚, С‚РѕРіРґР° API РІРµСЂРЅС‘С‚ РѕС€РёР±РєСѓ.
const TELEGRAM_CAPTION_LIMIT = LIMITS.TELEGRAM_CAPTION_LIMIT;

function truncateCaption(text, limit = TELEGRAM_CAPTION_LIMIT) {
  if (text.length <= limit) return text;
  return text.slice(0, limit - 1) + 'вЂ¦';
}

function buildPhotoCaption(state) {
  // Caption СѓС…РѕРґРёС‚ Р±РµР· HTML-РїР°СЂСЃРёРЅРіР° РІ sendPhotoToWorkChat вЂ” escape РЅРµ РЅСѓР¶РµРЅ,
  // РЅРѕ РµСЃР»Рё РІ Р¤РРћ РѕРєР°Р¶СѓС‚СЃСЏ <, > вЂ” РїСѓСЃС‚СЊ Р±СѓРґСѓС‚ РєР°Рє РµСЃС‚СЊ, Р±РµР· РїРѕР»РѕРјРєРё СЂРµРЅРґРµСЂР°.
  return truncateCaption([
    formatPhotoStatus(state.stage),
    `рџ‘¤ ${getEmployeeDisplayName(state.fio)}`,
    `рџљ™ ${state.auto || 'РЅРµ СѓРєР°Р·Р°РЅРѕ'}`,
    `рџЏ¬ ${state.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ'}`
  ].join('\n'));
}

function buildRouteSheetCaption(state, routeSheetNumber) {
  return truncateCaption([
    `рџ“„ РњР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚ в„–${routeSheetNumber}`,
    `рџ‘¤ ${getEmployeeDisplayName(state.fio)}`,
    `рџЏ¬ ${state.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ'}`
  ].join('\n'));
}

function getTodayText() {
  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  return getCurrentDateInfo(timezone).dateText;
}

const MAX_LOG_SIZE = LIMITS.MAX_LOG_SIZE_BYTES;

async function trimLogIfNeeded(filePath) {
  try {
    const stat = await fs.promises.stat(filePath).catch(() => null);
    if (!stat || stat.size < MAX_LOG_SIZE) return;
    const content = await fs.promises.readFile(filePath, 'utf8');
    const lines = content.split('\n');
    const half = Math.ceil(lines.length / 2);
    const trimmed = lines.slice(-half).join('\n');
    const tmp = filePath + '.tmp';
    await fs.promises.writeFile(tmp, trimmed, 'utf8');
    await fs.promises.rename(tmp, filePath);
  } catch (_) {}
}

async function appendLog(filePath, entry) {
  const line = `${JSON.stringify(entry)}\n`;
  try {
    await fs.promises.appendFile(filePath, line, 'utf8');
  } catch (error) {
    console.error('log write error', filePath, error.message);
  }
  await trimLogIfNeeded(filePath);
}

const BACKUP_DIR = path.join(__dirname, 'backups');
const BACKUP_FILES = ['database.sqlite', 'fun-reactions.json'];
const BACKUP_INTERVAL_MS = LIMITS.BACKUP_INTERVAL_MS;
const BACKUP_RETENTION_MS = LIMITS.BACKUP_RETENTION_MS;

async function ensureBackupDir() {
  try {
    await fs.promises.mkdir(BACKUP_DIR, { recursive: true });
  } catch (_) {}
}

async function makeBackup(reason = 'auto') {
  await ensureBackupDir();
  const now = new Date();
  const ts = now.toISOString().replace(/[.:]/g, '-');
  try {
    checkpoint();
  } catch (_) {}
  for (const filename of BACKUP_FILES) {
    const src = path.join(__dirname, filename);
    try {
      await fs.promises.access(src);
      const dst = path.join(BACKUP_DIR, `${filename.replace('.json', '')}-${reason}-${ts}.json`);
      await fs.promises.copyFile(src, dst);
    } catch (_) {}
  }
}

async function cleanOldBackups() {
  const cutoff = Date.now() - BACKUP_RETENTION_MS;
  let entries;
  try {
    entries = await fs.promises.readdir(BACKUP_DIR);
  } catch (_) {
    return;
  }
  for (const entry of entries) {
    const fullPath = path.join(BACKUP_DIR, entry);
    try {
      const stat = await fs.promises.stat(fullPath);
      if (stat.mtimeMs < cutoff) {
        await fs.promises.unlink(fullPath);
      }
    } catch (_) {}
  }
}

async function runBackupCycle() {
  try {
    checkpoint();
  } catch (_) {}
  await makeBackup('auto');
  await cleanOldBackups();
}

function withTimeout(promise, timeoutMs, label) {
  let timer;

  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label} timeout after ${timeoutMs}ms`)), timeoutMs);
    })
  ]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}

function parseEnvList(value) {
  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

function pickRandom(items) {
  if (!items || items.length === 0) return null;
  return items[Math.floor(Math.random() * items.length)];
}

function mergeUniqueItems(...lists) {
  const result = [];
  const seen = new Set();

  for (const list of lists) {
    for (const item of list || []) {
      const value = String(item || '').trim();
      if (!value || seen.has(value)) continue;
      seen.add(value);
      result.push(value);
    }
  }

  return result;
}

function normalizeFunList(value, limit = 800) {
  return mergeUniqueItems(value).slice(0, limit);
}

function normalizeImportedStickerSets(value) {
  const source = value && typeof value === 'object' ? value : {};
  const result = {};

  for (const [name, meta] of Object.entries(source)) {
    const setName = String(name || '').trim();
    if (!setName) continue;
    result[setName] = {
      importedAt: String(meta?.importedAt || ''),
      total: Number(meta?.total || 0)
    };
  }

  return result;
}

function getEmptyFunReactions() {
  return {
    successStickers: [],
    errorStickers: [],
    neutralStickers: [],
    successGifs: [],
    errorGifs: [],
    neutralGifs: [],
    importedStickerSets: {}
  };
}

function normalizeFunReactionsData(value) {
  const source = value && typeof value === 'object' ? value : {};
  return {
    successStickers: normalizeFunList(source.successStickers),
    errorStickers: normalizeFunList(source.errorStickers),
    neutralStickers: normalizeFunList(source.neutralStickers),
    successGifs: normalizeFunList(source.successGifs, 300),
    errorGifs: normalizeFunList(source.errorGifs, 300),
    neutralGifs: normalizeFunList(source.neutralGifs, 300),
    importedStickerSets: normalizeImportedStickerSets(source.importedStickerSets)
  };
}

function loadFunReactions() {
  if (funReactionsCache) return funReactionsCache;

  try {
    if (!fs.existsSync(funReactionsPath)) {
      funReactionsCache = getEmptyFunReactions();
      return funReactionsCache;
    }

    const data = JSON.parse(fs.readFileSync(funReactionsPath, 'utf8'));
    funReactionsCache = normalizeFunReactionsData(data);
    return funReactionsCache;
  } catch (error) {
    console.error('fun reactions load error', error.message);
    funReactionsCache = getEmptyFunReactions();
    return funReactionsCache;
  }
}

function scheduleFunReactionsWrite() {
  if (funReactionsWriteScheduled) return;
  funReactionsWriteScheduled = true;

  setImmediate(() => {
    funReactionsWriteScheduled = false;
    fs.promises.writeFile(funReactionsPath, JSON.stringify(funReactionsCache || getEmptyFunReactions(), null, 2), 'utf8').catch((error) => {
      console.error('fun reactions write error', error.message);
    });
  });
}

function flushFunReactionsNow() {
  funReactionsWriteScheduled = false;

  try {
    fs.writeFileSync(funReactionsPath, JSON.stringify(funReactionsCache || getEmptyFunReactions(), null, 2), 'utf8');
  } catch (error) {
    console.error('fun reactions flush error', error.message);
  }
}

function addUniqueLimited(list, value, limit = 800) {
  const text = String(value || '').trim();
  if (!text) return false;
  if (list.includes(text)) return false;

  list.push(text);
  if (list.length > limit) {
    list.splice(0, list.length - limit);
  }

  return true;
}

function getStickerReactionTypeByEmoji(emoji) {
  const value = String(emoji || '').trim();
  if (!value) return 'neutral';
  if (ERROR_STICKER_EMOJIS.has(value)) return 'error';
  if (SUCCESS_STICKER_EMOJIS.has(value)) return 'success';
  return 'neutral';
}

function getStickerBucketByType(reactionType) {
  if (reactionType === 'error') return 'errorStickers';
  if (reactionType === 'success') return 'successStickers';
  return 'neutralStickers';
}

function getGifBucketByType(reactionType) {
  if (reactionType === 'error') return 'errorGifs';
  if (reactionType === 'success') return 'successGifs';
  return 'neutralGifs';
}

function saveFunSticker(fileId, reactionType = 'neutral') {
  const data = loadFunReactions();
  const bucket = getStickerBucketByType(reactionType);
  const changed = addUniqueLimited(data[bucket], fileId, 1000);

  if (changed) {
    scheduleFunReactionsWrite();
  }

  return changed;
}

function saveFunGif(fileId, reactionType = 'neutral') {
  const data = loadFunReactions();
  const bucket = getGifBucketByType(reactionType);
  const changed = addUniqueLimited(data[bucket], fileId, 400);

  if (changed) {
    scheduleFunReactionsWrite();
  }

  return changed;
}

function extractStickerSetName(input) {
  const value = String(input || '').trim();
  if (!value) return null;

  const match = value.match(/(?:https?:\/\/)?t\.me\/addstickers\/([a-zA-Z0-9_]+)/i);
  if (match) return match[1];

  if (/^[a-zA-Z0-9_]+$/.test(value)) return value;
  return null;
}

function isFunStickerSetImportEnabled() {
  return String(process.env.FUN_IMPORT_STICKER_SETS || 'true').toLowerCase() !== 'false';
}

function getConfiguredFunStickerSetNames() {
  const envItems = parseEnvList(process.env.FUN_STICKER_SETS);
  const defaults = [
    'https://t.me/addstickers/TikTok_cats_animals',
    'https://t.me/addstickers/babylka_mem'
  ];
  const sources = envItems.length > 0 ? envItems : defaults;

  return mergeUniqueItems(sources.map((item) => extractStickerSetName(item)).filter(Boolean));
}

async function importStickerSetForFunReactions(ctx, stickerSetName) {
  const setName = extractStickerSetName(stickerSetName);
  if (!setName || !isFunStickerSetImportEnabled()) {
    return { setName, imported: false, added: 0, total: 0 };
  }

  const data = loadFunReactions();
  if (data.importedStickerSets[setName]) {
    return { setName, imported: false, added: 0, total: data.importedStickerSets[setName].total || 0 };
  }

  try {
    const stickerSet = await ctx.telegram.getStickerSet(setName);
    const stickers = Array.isArray(stickerSet?.stickers) ? stickerSet.stickers : [];
    let added = 0;

    for (const sticker of stickers) {
      if (!sticker?.file_id) continue;
      const reactionType = getStickerReactionTypeByEmoji(sticker.emoji);
      if (saveFunSticker(sticker.file_id, reactionType)) {
        added++;
      }
    }

    data.importedStickerSets[setName] = {
      importedAt: new Date().toISOString(),
      total: stickers.length
    };
    scheduleFunReactionsWrite();
    console.log(`fun stickers imported: ${setName}, total=${stickers.length}, added=${added}`);

    return { setName, imported: true, added, total: stickers.length };
  } catch (error) {
    console.error('fun sticker set import error', setName, error.message);
    return { setName, imported: false, added: 0, total: 0, error: error.message };
  }
}

async function importConfiguredFunStickerSets(ctx) {
  if (!isFunStickerSetImportEnabled()) return;

  const setNames = getConfiguredFunStickerSetNames();
  for (const setName of setNames) {
    await importStickerSetForFunReactions(ctx, setName);
  }
}

function hasAnyFunReactionContent() {
  const envContent = [
    ...parseEnvList(process.env.FUN_ERROR_STICKERS),
    ...parseEnvList(process.env.FUN_SUCCESS_STICKERS),
    ...parseEnvList(process.env.FUN_ERROR_GIFS),
    ...parseEnvList(process.env.FUN_SUCCESS_GIFS)
  ];

  if (envContent.length > 0) return true;

  const stored = loadFunReactions();
  return (
    stored.successStickers.length > 0 ||
    stored.errorStickers.length > 0 ||
    stored.neutralStickers.length > 0 ||
    stored.successGifs.length > 0 ||
    stored.errorGifs.length > 0 ||
    stored.neutralGifs.length > 0
  );
}

function isFunReactionsEnabled() {
  const flag = String(process.env.FUN_REACTIONS_ENABLED || '').trim().toLowerCase();
  if (flag === 'true' || flag === '1' || flag === 'yes') return true;
  if (flag === 'false' || flag === '0' || flag === 'no') return false;
  return hasAnyFunReactionContent();
}

function getFunReactionTypeFromMessage(htmlText) {
  const plainText = String(htmlText || '')
    .replace(/<[^>]*>/g, '')
    .trim();

  if (plainText.startsWith('вќЊ') || plainText.startsWith('вљ пёЏ')) return 'error';
  if (plainText.startsWith('вњ…')) return 'success';
  return null;
}

function getFunReactionCooldownMs() {
  const value = Number(process.env.FUN_REACTION_COOLDOWN_MS || 30000);
  return Number.isFinite(value) && value >= 0 ? value : 30000;
}

function canSendFunReaction(chatId) {
  const cooldown = getFunReactionCooldownMs();
  if (cooldown === 0) return true;

  const now = Date.now();
  const last = lastFunReactionAt.get(chatId) || 0;
  if (now - last < cooldown) return false;

  lastFunReactionAt.set(chatId, now);
  return true;
}

async function sendFunReaction(ctx, reactionType) {
  if (!isFunReactionsEnabled()) return;
  const chatId = ctx?.chat?.id;
  if (!chatId) return;
  if (!canSendFunReaction(chatId)) return;

  const envStickerList = reactionType === 'error'
    ? parseEnvList(process.env.FUN_ERROR_STICKERS)
    : parseEnvList(process.env.FUN_SUCCESS_STICKERS);
  const envGifList = reactionType === 'error'
    ? parseEnvList(process.env.FUN_ERROR_GIFS)
    : parseEnvList(process.env.FUN_SUCCESS_GIFS);

  const stored = loadFunReactions();
  const storedStickerList = reactionType === 'error'
    ? mergeUniqueItems(stored.errorStickers, stored.neutralStickers)
    : mergeUniqueItems(stored.successStickers, stored.neutralStickers);
  const storedGifList = reactionType === 'error'
    ? mergeUniqueItems(stored.errorGifs, stored.neutralGifs)
    : mergeUniqueItems(stored.successGifs, stored.neutralGifs);

  const stickerList = mergeUniqueItems(envStickerList, storedStickerList);
  const gifList = mergeUniqueItems(envGifList, storedGifList);

  const sticker = pickRandom(stickerList);
  const gif = pickRandom(gifList);

  try {
    if (sticker) {
      await ctx.replyWithSticker(sticker);
      return;
    }

    if (gif) {
      await ctx.replyWithAnimation(gif);
    }
  } catch (error) {
    console.error('fun reaction error', error.message);
  }
}

async function maybeSendFunReaction(ctx, htmlText) {
  const reactionType = getFunReactionTypeFromMessage(htmlText);
  if (!reactionType) return;
  await sendFunReaction(ctx, reactionType);
}

bot.use(async (ctx, next) => {
  if (ctx.chat?.type !== 'private') {
    if (ctx.message?.text?.startsWith('/chatid')) {
      return next();
    }
    return;
  }

  const originalReplyWithHTML = ctx.replyWithHTML.bind(ctx);
  ctx.replyWithHTML = async (htmlText, extra) => {
    const response = await originalReplyWithHTML(htmlText, extra);
    await maybeSendFunReaction(ctx, htmlText);
    return response;
  };

  await next();
});

bot.on('sticker', async (ctx) => {
  const sticker = ctx.message?.sticker;
  if (!sticker?.file_id) return;

  const reactionType = getStickerReactionTypeByEmoji(sticker.emoji);
  const saved = saveFunSticker(sticker.file_id, reactionType);

  if (saved) {
    console.log('fun sticker saved', reactionType, sticker.file_id);
  }

  if (sticker.set_name) {
    await importStickerSetForFunReactions(ctx, sticker.set_name);
  }
});

bot.on('animation', async (ctx) => {
  const animation = ctx.message?.animation;
  if (!animation?.file_id) return;

  const saved = saveFunGif(animation.file_id, 'neutral');
  if (saved) {
    console.log('fun gif saved', animation.file_id);
  }
});

function logMileagePhoto(telegramId, fileId, state) {
  appendLog(photoLogPath, {
    at: new Date().toISOString(),
    telegramId,
    fileId,
    fio: state?.fio || null,
    date: state?.date || null,
    stage: state?.stage || null,
    auto: state?.auto || null,
    workplace: state?.workplace || null
  });
}

function getNextRouteSheetNumber(state, date) {
  try {
    if (!fs.existsSync(routeSheetLogPath)) {
      return 1;
    }

    const lines = fs.readFileSync(routeSheetLogPath, 'utf8').split('\n').filter(Boolean);
    const count = lines.reduce((total, line) => {
      try {
        const entry = JSON.parse(line);
        return entry.date === date && entry.fio === state?.fio ? total + 1 : total;
      } catch (_) {
        return total;
      }
    }, 0);

    return count + 1;
  } catch (error) {
    console.error('route sheet count error', error);
    return 1;
  }
}

function logRouteSheetPhoto(telegramId, fileId, state, date, routeSheetNumber) {
  appendLog(routeSheetLogPath, {
    at: new Date().toISOString(),
    date,
    routeSheetNumber,
    telegramId,
    fileId,
    fio: state?.fio || null,
    carNumber: state?.carNumber || null,
    workplace: state?.workplace || null
  });
}

function logReconciliationPhoto(telegramId, fileId, state, label) {
  appendLog(reconciliationLogPath, {
    at: new Date().toISOString(),
    telegramId,
    fileId,
    fio: state?.fio || null,
    carNumber: state?.carNumber || null,
    workplace: state?.workplace || null,
    device: state?.device || null,
    label
  });
}

function parseMoneyRu(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const cleaned = raw.replace(/[\s\u00A0]/g, '').replace(/в‚Ѕ/g, '').replace(/,/g, '.').replace(/[^0-9.]/g, '');
  if (!cleaned) return null;
  const number = Number(cleaned);
  if (!Number.isFinite(number) || number < 0) return null;
  return number;
}

function formatMoneyRu(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number) || number < 0) return null;
  const formatted = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(number);
  return `${formatted} в‚Ѕ`;
}

function formatMoneyRuNumber(value) {
  const withCurrency = formatMoneyRu(value);
  if (!withCurrency) return null;
  return withCurrency.replace(/\s*в‚Ѕ$/, '');
}

function extractOrdersCountFromOcrText(text) {
  const raw = String(text || '')
    .replace(/\u00A0/g, ' ')
    .trim();

  if (!raw) {
    return { totalOrders: null, reason: 'empty_text' };
  }

  const normalized = raw.replace(/\s+/g, ' ');

  const strictPatterns = [
    /Р·Р°РєР°Р·Рѕ[РєРІ]\s+Р·Р°\s*(?:СЃРµРіРѕРґРЅСЏ|СЃСѓС‚РєРё)\s*:?\s*(\d{1,5})/i,
    /Р·Р°\s*(?:СЃРµРіРѕРґРЅСЏ|СЃСѓС‚РєРё)\s*:?\s*(\d{1,5})/i,
  ];

  for (const pattern of strictPatterns) {
    const match = normalized.match(pattern);
    if (match && Number.isFinite(Number(match[1])) && Number(match[1]) > 0) {
      return { totalOrders: Number(match[1]), reason: 'ok' };
    }
  }

  const lines = raw.split(/\n/);
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i].trim();
    if (/Р·Р°РєР°Р·Рѕ[РєРІ]/i.test(line)) {
      for (let j = i + 1; j < Math.min(lines.length, i + 5); j += 1) {
        const candidate = lines[j].trim();
        const numMatch = candidate.match(/^(\d{1,5})$/);
        if (numMatch && Number.isFinite(Number(numMatch[1])) && Number(numMatch[1]) > 0) {
          return { totalOrders: Number(numMatch[1]), reason: 'ok' };
        }
      }
    }
  }

  const fallbackPatterns = [
    /Р·Р°РєР°Р·Рѕ[РєРІ]\s*:?\s*(\d{1,5})(?:\s|$)/i,
    /(\d{1,5})\s*Р·Р°РєР°Р·Рѕ[РєРІ]/i,
  ];

  for (const pattern of fallbackPatterns) {
    const match = normalized.match(pattern);
    if (match && Number.isFinite(Number(match[1])) && Number(match[1]) > 0) {
      return { totalOrders: Number(match[1]), reason: 'ok' };
    }
  }

  return { totalOrders: null, reason: 'no_orders_line' };
}

function extractCashFromOcrText(text) {
  const normalized = String(text || '')
    .replace(/\u00A0/g, ' ')
    .replace(/[|В¦]/g, '/')
    .replace(/в‚Ѕ/g, ' в‚Ѕ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!normalized) {
    return { orders: null, amount: null, valid: false, reason: 'empty_text' };
  }

  const cashWordSource = 'РЅР°Р»РёС‡[Р°-СЏa-z]*|[Hh]a[РЅn][Р»nM][РёiС‡4][РЅn][С‹b][Рµe]|[Hh]a[Р»n][РёiС‡][РЅh][bР»][Рµe]';
  const cashLineRegex = new RegExp(`(?:${cashWordSource})\\s*([0-9]{1,3})?\\s*/\\s*([0-9\\s.,]{1,20})?[Pв‚Ѕ]?`, 'i');
  const cashMatch = normalized.match(cashLineRegex);

  if (cashMatch) {
    const ordersRaw = cashMatch[1] || '';
    const amountRaw = cashMatch[2] || '';
    const orders = Number(String(ordersRaw).replace(/\D/g, ''));
    const amount = parseMoneyRu(amountRaw);
    const hasOrders = Number.isFinite(orders) && orders > 0;
    const hasAmount = Number.isFinite(amount) && amount >= 1;

    return {
      orders: Number.isFinite(orders) ? orders : 0,
      amount: Number.isFinite(amount) ? amount : null,
      valid: hasOrders && hasAmount,
      reason: hasOrders && hasAmount ? 'ok' : 'insufficient'
    };
  }

  const hasCashWord = new RegExp(`(?:${cashWordSource})`, 'i').test(normalized);
  if (hasCashWord) {
    return { orders: 0, amount: null, valid: false, reason: 'cash_line_empty' };
  }

  return { orders: null, amount: null, valid: false, reason: 'no_cash_line' };
}

function getReconciliationOcrTimeoutMs() {
  const value = Number(process.env.RECONCILIATION_OCR_TIMEOUT_MS || 30000);
  return Number.isFinite(value) && value >= 5000 ? value : 30000;
}

const MAX_REASONABLE_CASH_AMOUNT = 500000;

function roundMoney(value) {
  return Math.round(Number(value || 0) * 100) / 100;
}



function emptyReconciliationCash(reason, source = 'none') {
  return { orders: null, amount: null, totalOrders: null, valid: false, reason, source };
}

async function recognizeReconciliationCashSafe(ctx, fileId, label) {
  try {
    return await withTimeout(
      recognizeReconciliationCash(ctx, fileId),
      getReconciliationOcrTimeoutMs(),
      `reconciliation OCR ${label || ''}`.trim()
    );
  } catch (error) {
    console.error('reconciliation OCR safe fallback', label || '', error.message || error);
    return emptyReconciliationCash('ocr_timeout', 'none');
  }
}

function shouldWarnAboutReconciliationOcr(cashInfo) {
  if (!cashInfo) return true;
  if (cashInfo.valid) return false;
  if (cashInfo.totalOrders && cashInfo.totalOrders > 0) return false;
  return ['ocr_timeout', 'error', 'local_ocr_error', 'local_ocr_timeout', 'no_ocr_result'].includes(cashInfo.reason);
}

async function recognizeReconciliationCash(ctx, fileId) {
  try {
    const link = await ctx.telegram.getFileLink(fileId);
    const response = await axios.get(link.href, { responseType: 'arraybuffer', timeout: 30000 });
    const imageBuffer = Buffer.from(response.data);

    let totalOrdersFromRapid = null;

    if (isRapidOcrEnabled()) {
      const rapidText = await recognizeTextWithRapidOcr(imageBuffer);
      if (rapidText) {
        const parsed = extractCashFromOcrText(rapidText);
        const ordersParsed = extractOrdersCountFromOcrText(rapidText);
        totalOrdersFromRapid = ordersParsed.totalOrders;
        console.log('СЃРІРµСЂРєР° OCR:', JSON.stringify({ cashValid: parsed.valid, cashReason: parsed.reason, cashOrders: parsed.orders, cashAmount: parsed.amount, totalOrders: ordersParsed.totalOrders, ordersReason: ordersParsed.reason, source: 'rapidocr' }));

        if (parsed.valid) {
          return { ...parsed, totalOrders: ordersParsed.totalOrders, source: 'rapidocr' };
        }

        if (parsed.reason === 'cash_line_empty') {
          return { ...parsed, totalOrders: ordersParsed.totalOrders, source: 'rapidocr' };
        }
      } else {
        console.log('СЃРІРµСЂРєР° OCR: RapidOCR РІРµСЂРЅСѓР» РїСѓСЃС‚РѕР№ С‚РµРєСЃС‚');
      }
    }

    console.log('СЃРІРµСЂРєР° OCR: RapidOCR РЅРµ РґР°Р» СЂРµР·СѓР»СЊС‚Р°С‚Р°, fallback-OCR РЅРµ РїРѕРґРєР»СЋС‡С‘РЅ');
    return { orders: null, amount: null, totalOrders: totalOrdersFromRapid, valid: false, reason: 'no_ocr_result', source: 'none' };
  } catch (error) {
    console.error('reconciliation cash recognition error', error.message || error);
    return { orders: null, amount: null, totalOrders: null, valid: false, reason: 'error', source: 'none' };
  }
}

function makeMileageState(telegramId, baseState, extra = {}) {
  return {
    telegramId,
    ...baseState,
    awaitingMileagePhoto: true,
    awaitingManualMileage: false,
    photoReceived: false,
    ...extra
  };
}

function normalizeCarNumber(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').toUpperCase();
}

function isValidCarNumber(value) {
  const normalized = normalizeCarNumber(value);
  if (!normalized) return false;
  if (normalized.length < 4 || normalized.length > 12) return false;
  return /[Рђ-РЇРЃA-Z]/.test(normalized) && /\d/.test(normalized);
}

function normalizeTimeValue(value) {
  const text = String(value || '').trim();

  // 1) Р”РІРѕРµС‚РѕС‡РёРµ вЂ” РІСЃРµРіРґР° РІСЂРµРјСЏ (РїСЂРѕР±РµР»С‹ РІРѕРєСЂСѓРі ":" РёРіРЅРѕСЂРёСЂСѓРµРј)
  const noSpaces = text.replace(/\s+/g, '');
  const colonMatch = noSpaces.match(/^(\d{1,2}):(\d{1,2})$/);
  if (colonMatch) {
    const minutes = Number(colonMatch[2]);
    if (minutes > 59) return null;
    return roundMinutesToHalfHour(Number(colonMatch[1]), minutes);
  }

  // 2) РўРѕС‡РєР° / РїСЂРѕР±РµР» + Р”Р’Р• С†РёС„СЂС‹ в†’ РІСЂРµРјСЏ (8.46, 8 14, 8.05, 07.30)
  const dotTimeMatch = text.match(/^(\d{1,2})[.\s]+(\d{2})$/);
  if (dotTimeMatch) {
    const minutes = Number(dotTimeMatch[2]);
    if (minutes > 59) return null;
    return roundMinutesToHalfHour(Number(dotTimeMatch[1]), minutes);
  }

  // 3) РўРѕС‡РєР° / РїСЂРѕР±РµР» + РћР”РќРђ С†РёС„СЂР° в†’ РґРµСЃСЏС‚РёС‡РЅР°СЏ РґСЂРѕР±СЊ (8.5, 8 5, 7.3)
  const dotDecimalMatch = text.match(/^(\d{1,2})[.\s]+(\d)$/);
  if (dotDecimalMatch) {
    const minutes = Math.round(Number(dotDecimalMatch[2]) * 6); // 0.X * 60
    return roundMinutesToHalfHour(Number(dotDecimalMatch[1]), minutes);
  }

  // 4) Р—Р°РїСЏС‚Р°СЏ РёР»Рё С†РµР»РѕРµ вЂ” РґРµСЃСЏС‚РёС‡РЅР°СЏ РґСЂРѕР±СЊ
  const decimalMatch = noSpaces.match(/^(\d{1,2})(?:,(\d{1,2}))?$/);
  if (decimalMatch) {
    const hours = Number(decimalMatch[1]);
    const fraction = decimalMatch[2] ? Number(`0.${decimalMatch[2]}`) : 0;
    const minutes = Math.round(fraction * 60);
    return roundMinutesToHalfHour(hours, minutes);
  }

  return null;
}

function isMenuText(text) {
  return [
    BUTTONS.punchTime,
    BUTTONS.mileage,
    BUTTONS.routeSheet,
    BUTTONS.reconciliation,
    BUTTONS.cashCheck,
    BUTTONS.issues,
    BUTTONS.leaderBoard,
    BUTTONS.settings,
    BUTTONS.help,
    BUTTONS.profile,
    BUTTONS.changeCar,
    BUTTONS.changeWorkplace,
    BUTTONS.changeDevice,
    BUTTONS.switchUser,
    BUTTONS.sheetInfo,
    BUTTONS.myId,
    'Р’СЂРµРјСЏ СЃРјРµРЅС‹',
    'Р’РЅРµСЃС‚Рё РІСЂРµРјСЏ СЃРјРµРЅС‹',
    'Р’СЂРµРјСЏ',
    'Р’РЅРµСЃС‚Рё РїСЂРѕР±РµРі',
    'РџСЂРѕР±РµРі',
    'РњР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚',
    'РњР°СЂС€СЂСѓС‚РЅРёРє',
    'РЎРІРµСЂРєРё',
    'Р”РµРЅСЊРіРё Рє СЃРґР°С‡Рµ',
    'РќР°Р»РёС‡РЅС‹Рµ',
    'РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј',
    'РџСЂРѕР±Р»РµРјР°',
    'Р›РёРґРµСЂР±РѕСЂРґ',
    'РќР°СЃС‚СЂРѕР№РєРё',
    'РџРѕРјРѕС‰СЊ',
    'РџСЂРѕС„РёР»СЊ',
    'РР·РјРµРЅРёС‚СЊ РЅРѕРјРµСЂ РјР°С€РёРЅС‹',
    'РќРѕРјРµСЂ РјР°С€РёРЅС‹',
    'РџРѕРјРµРЅСЏС‚СЊ РјР°РіР°Р·РёРЅ',
    'РР·РјРµРЅРёС‚СЊ РёРЅС‚РµСЂРЅРµС‚-РјР°РіР°Р·РёРЅ',
    'РњР°РіР°Р·РёРЅ',
    'РР·РјРµРЅРёС‚СЊ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ',
    'РЈСЃС‚СЂРѕР№СЃС‚РІРѕ',
    'РџРѕРјРµРЅСЏС‚СЊ СЃРѕС‚СЂСѓРґРЅРёРєР°',
    'РЎРјРµРЅРёС‚СЊ СЃРѕС‚СЂСѓРґРЅРёРєР°',
    'РЎРѕС‚СЂСѓРґРЅРёРє',
    'РўР°Р±Р»РёС†С‹',
    'РњРѕР№ ID',
    'РЈРїСЂР°РІР»РµРЅРёРµ'
  ].includes(text) || WORKPLACES.includes(text) || DEVICES.includes(text);
}

async function askForCarNumber(ctx, fio = getUserField(ctx.from.id, 'fio')) {
  setState(ctx.from.id, { awaitingCarNumber: true, fio });
  await ctx.replyWithHTML(
    `рџљ— <b>РќРѕРјРµСЂ РјР°С€РёРЅС‹</b>\n\nР’РІРµРґРёС‚Рµ РіРѕСЃ. РЅРѕРјРµСЂ Р°РІС‚РѕРјРѕР±РёР»СЏ.\nРќР°РїСЂРёРјРµСЂ: <code>Рђ123Р’РЎ777</code>`,
    getMenuForRole(ctx.from.id)
  );
}

async function askForWorkplace(ctx, fio = getUserField(ctx.from.id, 'fio')) {
  setState(ctx.from.id, { awaitingWorkplace: true, fio });
  await ctx.replyWithHTML(
    'рџЏ¬ <b>РРЅС‚РµСЂРЅРµС‚-РјР°РіР°Р·РёРЅ</b>\n\nР’С‹Р±РµСЂРёС‚Рµ РІР°С€ РјР°РіР°Р·РёРЅ:',
    workplaceMenu()
  );
}

async function askForDevice(ctx, fio = getUserField(ctx.from.id, 'fio')) {
  setState(ctx.from.id, { awaitingDevice: true, fio });
  await ctx.replyWithHTML(
    'рџ’» <b>Р Р°Р±РѕС‡РµРµ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ</b>\n\nР’С‹Р±РµСЂРёС‚Рµ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ:',
    deviceMenu()
  );
}

async function saveCarNumber(ctx, value) {
  const carNumber = normalizeCarNumber(value);

  if (!carNumber || isMenuText(value)) {
    await ctx.replyWithHTML('вќЊ Р’РІРµРґРёС‚Рµ РЅРѕРјРµСЂ РјР°С€РёРЅС‹ С‚РµРєСЃС‚РѕРј.\nРќР°РїСЂРёРјРµСЂ: <code>Рђ123Р’РЎ777</code>');
    return;
  }

  if (!isValidCarNumber(carNumber)) {
    await ctx.replyWithHTML('вќЊ РќРµРІРµСЂРЅС‹Р№ С„РѕСЂРјР°С‚ РЅРѕРјРµСЂР°.\nРќРѕРјРµСЂ РґРѕР»Р¶РµРЅ СЃРѕРґРµСЂР¶Р°С‚СЊ Р±СѓРєРІС‹ Рё С†РёС„СЂС‹.\nРќР°РїСЂРёРјРµСЂ: <code>Рђ123Р’РЎ777</code>');
    return;
  }

  setUserField(ctx.from.id, 'carNumber', carNumber);
  console.log('РЅРѕРјРµСЂ РјР°С€РёРЅС‹ СЃРѕС…СЂР°РЅС‘РЅ');

  if (!getUserField(ctx.from.id, 'workplace')) {
    await ctx.replyWithHTML(`вњ… РќРѕРјРµСЂ РјР°С€РёРЅС‹ СЃРѕС…СЂР°РЅС‘РЅ: <code>${esc(carNumber)}</code>`);
    await askForWorkplace(ctx);
    return;
  }

  if (!getUserField(ctx.from.id, 'device')) {
    await ctx.replyWithHTML(`вњ… РќРѕРјРµСЂ РјР°С€РёРЅС‹ СЃРѕС…СЂР°РЅС‘РЅ: <code>${esc(carNumber)}</code>`);
    await askForDevice(ctx);
    return;
  }

  clearState(ctx.from.id);
  await ctx.replyWithHTML(`вњ… РќРѕРјРµСЂ РјР°С€РёРЅС‹ СЃРѕС…СЂР°РЅС‘РЅ: <code>${esc(carNumber)}</code>`, getMenuForRole(ctx.from.id));
}

async function saveWorkplace(ctx, value) {
  const workplace = WORKPLACES.find((item) => item.toLowerCase() === String(value || '').trim().toLowerCase());

  if (!workplace) {
    await ctx.replyWithHTML('вќЊ Р’С‹Р±РµСЂРёС‚Рµ РјР°РіР°Р·РёРЅ РєРЅРѕРїРєРѕР№ РЅРёР¶Рµ.', workplaceMenu());
    return;
  }

  setUserField(ctx.from.id, 'workplace', workplace);
  console.log('РёРЅС‚РµСЂРЅРµС‚-РјР°РіР°Р·РёРЅ СЃРѕС…СЂР°РЅС‘РЅ');
  const role = getUserRole(ctx.from.id);

  if (role === 'logist') {
    clearState(ctx.from.id);
    await ctx.replyWithHTML(`вњ… РњР°РіР°Р·РёРЅ СЃРѕС…СЂР°РЅС‘РЅ: <b>${esc(workplace)}</b>`, logistMainMenu(ctx.from.id));
    return;
  }

  if (!getUserField(ctx.from.id, 'device')) {
    await ctx.replyWithHTML(`вњ… РњР°РіР°Р·РёРЅ СЃРѕС…СЂР°РЅС‘РЅ: <b>${esc(workplace)}</b>`);
    await askForDevice(ctx);
    return;
  }

  clearState(ctx.from.id);
  await ctx.replyWithHTML(`вњ… РњР°РіР°Р·РёРЅ СЃРѕС…СЂР°РЅС‘РЅ: <b>${esc(workplace)}</b>`, getMenuForRole(ctx.from.id));
}

async function saveDevice(ctx, value) {
  const device = DEVICES.find((item) => item.toLowerCase() === String(value || '').trim().toLowerCase());

  if (!device) {
    await ctx.replyWithHTML('вќЊ Р’С‹Р±РµСЂРёС‚Рµ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ РєРЅРѕРїРєРѕР№ РЅРёР¶Рµ.', deviceMenu());
    return;
  }

  setUserField(ctx.from.id, 'device', device);
  clearState(ctx.from.id);
  console.log('СѓСЃС‚СЂРѕР№СЃС‚РІРѕ СЃРѕС…СЂР°РЅРµРЅРѕ');
  await ctx.replyWithHTML(`вњ… РЈСЃС‚СЂРѕР№СЃС‚РІРѕ СЃРѕС…СЂР°РЅРµРЅРѕ: <b>${esc(device)}</b>`, getMenuForRole(ctx.from.id));
}

async function ensureProfile(ctx) {
  const profile = getFullProfile(ctx.from.id);
  const role = getUserRole(ctx.from.id);

  if (!profile.fio) {
    await askForFio(ctx);
    return null;
  }

  if (role !== 'logist') {
    if (profile.courierType !== 'pedestrian' && !profile.carNumber) {
      await askForCarNumber(ctx, profile.fio);
      return null;
    }
  }

  if (!profile.workplace) {
    await askForWorkplace(ctx, profile.fio);
    return null;
  }

  if (role !== 'logist') {
    if (!profile.device) {
      await askForDevice(ctx, profile.fio);
      return null;
    }
  }

  return profile;
}

function applyCarNumber(result, carNumber) {
  return { ...result, auto: carNumber || result.auto };
}

function applyProfile(result, profile) {
  return { ...applyCarNumber(result, profile.carNumber), workplace: profile.workplace, device: profile.device };
}

async function askForFio(ctx) {
  const telegramId = ctx.from.id;
  setState(telegramId, { awaitingFio: true });
  await ctx.replyWithHTML(
    'рџ‘¤ <b>РђРІС‚РѕСЂРёР·Р°С†РёСЏ</b>\n\nР’РІРµРґРёС‚Рµ РёРјСЏ Рё С„Р°РјРёР»РёСЋ РєР°Рє РІ С‚Р°Р±Р»РёС†Рµ.',
    Markup.keyboard([[BUTTONS.back]]).resize()
  );
}

async function authorizeFio(ctx, fio) {
  const telegramId = ctx.from.id;

  try {
    console.log('Р°РІС‚РѕСЂРёР·Р°С†РёСЏ Р¤РРћ');
    const employee = await findCourierInAllSheets(fio);

    if (!employee) {
      console.log('СЃРѕС‚СЂСѓРґРЅРёРє РЅРµ РЅР°Р№РґРµРЅ');
      await ctx.replyWithHTML('вќЊ РЎРѕС‚СЂСѓРґРЅРёРє РЅРµ РЅР°Р№РґРµРЅ РІ С‚Р°Р±Р»РёС†Рµ.\nРџСЂРѕРІРµСЂСЊС‚Рµ РёРјСЏ Рё С„Р°РјРёР»РёСЋ Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.');
      return;
    }

    setUserField(telegramId, 'fio', employee.fio);
    console.log('СЃРѕС‚СЂСѓРґРЅРёРє РЅР°Р№РґРµРЅ');
    await ctx.replyWithHTML(`вњ… РЎРѕС‚СЂСѓРґРЅРёРє РЅР°Р№РґРµРЅ: <b>${esc(employee.fio)}</b>`);

    const auto = String(employee.auto || '').trim().toLowerCase();
    const workplace = employee.workplace;

    if (workplace === 'РРњ Р¦РµРЅС‚СЂ') {
      if (auto === 'РїРµС€РёР№') {
        setUserField(telegramId, 'courierType', 'pedestrian');
        setUserField(telegramId, 'role', 'courier');
        setUserField(telegramId, 'workplace', 'РРњ Р¦РµРЅС‚СЂ');
        await ctx.replyWithHTML('рџљ¶ <b>РџРµС€РёР№ РєСѓСЂСЊРµСЂ</b>, РјР°РіР°Р·РёРЅ <b>РРњ Р¦РµРЅС‚СЂ</b>.');
        await askForDevice(ctx, employee.fio);
        return;
      }
      if (auto === 'Р»РѕРіРёСЃС‚') {
        setUserField(telegramId, 'role', 'logist');
        await ctx.replyWithHTML('рџ“¦ <b>Р›РѕРіРёСЃС‚</b>.\n\nРўРµРїРµСЂСЊ РІС‹Р±РµСЂРёС‚Рµ РІР°С€ РјР°РіР°Р·РёРЅ.', logistMainMenu(telegramId));
        await askForWorkplace(ctx, employee.fio);
        return;
      }
      setUserField(telegramId, 'courierType', 'auto');
      setUserField(telegramId, 'role', 'courier');
      await ctx.replyWithHTML('рџљ— <b>РђРІС‚Рѕ-РєСѓСЂСЊРµСЂ</b>.\n\nРўРµРїРµСЂСЊ РІРІРµРґРёС‚Рµ РЅРѕРјРµСЂ РјР°С€РёРЅС‹.');
      await askForCarNumber(ctx, employee.fio);
      return;
    }

    if (workplace === 'РРњ Р’РѕСЃС‚РѕРє') {
      if (auto === 'Р»РѕРіРёСЃС‚') {
        setUserField(telegramId, 'role', 'logist');
        await ctx.replyWithHTML('рџ“¦ <b>Р›РѕРіРёСЃС‚</b>.\n\nРўРµРїРµСЂСЊ РІС‹Р±РµСЂРёС‚Рµ РІР°С€ РјР°РіР°Р·РёРЅ.', logistMainMenu(telegramId));
        await askForWorkplace(ctx, employee.fio);
        return;
      }
      setState(telegramId, { awaitingRoleChoice: true, fio: employee.fio, workplace: employee.workplace });
      await ctx.replyWithHTML(
        'рџ‘¤ <b>Р’С‹Р±РµСЂРёС‚Рµ РІР°С€Сѓ СЂРѕР»СЊ:</b>\n\n' +
        'в–«пёЏ <b>РљСѓСЂСЊРµСЂ</b> вЂ” РґРѕСЃС‚Р°РІРєР° Р·Р°РєР°Р·РѕРІ, РїСЂРѕР±РµРі, РјР°СЂС€СЂСѓС‚РЅРёРє, СЃРІРµСЂРєР°, РЅР°Р»РёС‡РЅС‹Рµ\n' +
        'в–«пёЏ <b>Р›РѕРіРёСЃС‚</b> вЂ” СѓС‡С‘С‚ РІСЂРµРјРµРЅРё, СЃР±РѕСЂ РЅР°Р»РёС‡РЅС‹С… СЃ РєСѓСЂСЊРµСЂРѕРІ, С‚Р°Р±Р»РёС†С‹',
        roleChoiceKeyboard()
      );
      return;
    }

    setState(telegramId, { awaitingRoleChoice: true, fio: employee.fio, workplace: employee.workplace });
    await ctx.replyWithHTML(
      'рџ‘¤ <b>Р’С‹Р±РµСЂРёС‚Рµ РІР°С€Сѓ СЂРѕР»СЊ:</b>\n\n' +
      'в–«пёЏ <b>РљСѓСЂСЊРµСЂ</b> вЂ” РґРѕСЃС‚Р°РІРєР° Р·Р°РєР°Р·РѕРІ, РїСЂРѕР±РµРі, РјР°СЂС€СЂСѓС‚РЅРёРє, СЃРІРµСЂРєР°, РЅР°Р»РёС‡РЅС‹Рµ\n' +
      'в–«пёЏ <b>Р›РѕРіРёСЃС‚</b> вЂ” СѓС‡С‘С‚ РІСЂРµРјРµРЅРё, СЃР±РѕСЂ РЅР°Р»РёС‡РЅС‹С… СЃ РєСѓСЂСЊРµСЂРѕРІ, С‚Р°Р±Р»РёС†С‹',
      roleChoiceKeyboard()
    );
  } catch (error) {
    console.error('РѕС€РёР±РєР° Google Sheets', error);
    await ctx.replyWithHTML('вљ пёЏ РћС€РёР±РєР° Google РўР°Р±Р»РёС†С‹.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
  }
}

async function punchTimeFlow(ctx, explicitStage = null) {
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  try {
    const isPedestrian = profile.courierType === 'pedestrian';
    const result = explicitStage
      ? await replaceTime(profile.fio, profile.workplace, explicitStage, isPedestrian)
      : await punchTime(profile.fio, profile.workplace, isPedestrian);

    if (result.notFound) {
      const msg = formatNoSheetMessage(result, profile.workplace);
      await ctx.replyWithHTML(msg);
      return;
    }

    if (result.needsReplaceChoice) {
      console.log('РЅСѓР¶РЅР° Р·Р°РјРµРЅР°');
      setState(telegramId, { awaitingReplaceChoice: true, fio: profile.fio });
      await ctx.replyWithHTML(
        `вљ пёЏ Р—Р° СЃРµРіРѕРґРЅСЏ СѓР¶Рµ РІРЅРµСЃРµРЅС‹ РЅР°С‡Р°Р»Рѕ Рё РєРѕРЅРµС† СЃРјРµРЅС‹.\n\n` +
        `рџџў РЎС‚Р°СЂС‚: <code>${esc(result.from)}</code>\n` +
        `рџ”ґ РљРѕРЅРµС†: <code>${esc(result.to)}</code>\n\n` +
        `Р’С‹Р±РµСЂРёС‚Рµ, С‡С‚Рѕ Р·Р°РјРµРЅРёС‚СЊ:`,
        replaceKeyboard()
      );
      return;
    }

    console.log('РІСЂРµРјСЏ Р·Р°РїРёСЃР°РЅРѕ', result.stage);

    const xpKey = result.stage === 'start' ? 'punchStart' : 'punchEnd';
    const xpLabel = result.stage === 'start' ? 'РЎС‚Р°СЂС‚' : 'РљРѕРЅРµС†';
    addXp(telegramId, getXpForAction(xpKey), `${xpLabel} СЃРјРµРЅС‹`);
    const todayIso = new Date().toISOString().split('T')[0];
    const streak = updateStreak(telegramId, todayIso);
    const streakBonus = getStreakBonus(streak.currentStreak);
    if (streakBonus > 0) {
      addXp(telegramId, streakBonus, `Р‘РѕРЅСѓСЃ Р·Р° СЃС‚СЂРёРє ${streak.currentStreak} СЃРјРµРЅ`);
    }

    const icon = result.stage === 'start' ? 'рџџў' : 'рџ”ґ';
    const label = result.stage === 'start' ? 'РЎС‚Р°СЂС‚' : 'РљРѕРЅРµС†';

    setState(telegramId, {
      awaitingTimeChange: true,
      awaitingManualTime: false,
      fio: result.fio,
      courierRow: result.courierRow,
      day: result.day,
      stage: result.stage,
      timeValue: result.timeValue,
      workplace: profile.workplace
    });

    await ctx.replyWithHTML(
      `${icon} <b>${label} СЃРјРµРЅС‹</b>: <code>${esc(result.timeValue)}</code>\n\n` +
      `<i>Р•СЃР»Рё РІСЂРµРјСЏ РЅРµРІРµСЂРЅРѕРµ вЂ” РЅР°Р¶РјРёС‚Рµ В«РР·РјРµРЅРёС‚СЊ РІСЂРµРјСЏВ».</i>`,
      timeChangeKeyboard()
    );

    if (result.stage === 'start') {
      const pendingCash = getPendingCash(telegramId);
      const pendingAmount = Number(pendingCash?.amount || 0);

      if (Number.isFinite(pendingAmount) && pendingAmount >= 1) {
        const formattedAmount = pendingCash?.formatted || formatMoneyRu(pendingAmount);
        const numberOnly = formatMoneyRuNumber(pendingAmount) || String(formattedAmount || '').replace(/\s*в‚Ѕ$/, '');
        await ctx.replyWithHTML(
          `вљ пёЏ <b>РќРµ Р·Р°Р±СѓРґСЊС‚Рµ СЃРґР°С‚СЊ РґРµРЅСЊРіРё</b>: <code>${esc(numberOnly)}</code> в‚Ѕ\n` +
          `рџЏ¬ <b>${esc(pendingCash?.workplace || profile.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ')}</b>`,
          cashSubmitConfirmKeyboard()
        );
      }
    }
  } catch (error) {
    console.error('РѕС€РёР±РєР° Google Sheets', error);
    await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
  }
}

async function mileageFlow(ctx, explicitStage = null) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  if (profile.courierType === 'pedestrian') {
    await ctx.replyWithHTML('рџљ¶ РџРµС€РёРј РєСѓСЂСЊРµСЂР°Рј РїСЂРѕР±РµРі РЅРµ С‚СЂРµР±СѓРµС‚СЃСЏ.', getMenuForRole(telegramId));
    return;
  }

  try {
    const result = await prepareMileage(profile.fio, profile.workplace, explicitStage);

    if (result.notFound) {
      const msg = formatNoSheetMessage(result, profile.workplace);
      await ctx.replyWithHTML(msg);
      return;
    }

    if (result.needsReplaceChoice) {
      console.log('РЅСѓР¶РЅР° Р·Р°РјРµРЅР° РїСЂРѕР±РµРіР°');
      setState(telegramId, { awaitingMileageReplaceChoice: true, fio: profile.fio });
      await ctx.replyWithHTML(
        `вљ пёЏ Р—Р° СЃРµРіРѕРґРЅСЏ СѓР¶Рµ РІРЅРµСЃС‘РЅ РїСЂРѕР±РµРі.\n\n` +
        `рџџў РЎС‚Р°СЂС‚: <code>${esc(result.startMileage)}</code>\n` +
        `рџ”ґ РљРѕРЅРµС†: <code>${esc(result.endMileage)}</code>\n\n` +
        `Р’С‹Р±РµСЂРёС‚Рµ, С‡С‚Рѕ Р·Р°РјРµРЅРёС‚СЊ:`,
        mileageReplaceKeyboard()
      );
      return;
    }

    setState(telegramId, makeMileageState(telegramId, applyProfile(result, profile), { source: 'mileage' }));
    console.log('РѕР¶РёРґР°РЅРёРµ РїСЂРѕР±РµРіР°', result.stage);
    await ctx.replyWithHTML(
      `рџ“· <b>РћС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ РѕРґРѕРјРµС‚СЂР°</b>\n\n` +
      `Р­С‚Р°Рї: <b>${esc(formatStage(result.stage))}</b>\n\n` +
      `рџ“Ћ <i>РќР°Р¶РјРёС‚Рµ РЅР° СЃРєСЂРµРїРєСѓ в†’ РљР°РјРµСЂР° РёР»Рё Р“Р°Р»РµСЂРµСЏ</i>`,
      skipMileageKeyboard()
    );
  } catch (error) {
    console.error('РѕС€РёР±РєР° Google Sheets', error);
    await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕРґРіРѕС‚РѕРІРёС‚СЊ Р·Р°РїРёСЃСЊ РїСЂРѕР±РµРіР°.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
  }
}

async function routeSheetFlow(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  setState(telegramId, {
    awaitingRouteSheetPhoto: true,
    fio: profile.fio,
    carNumber: profile.carNumber,
    workplace: profile.workplace
  });

  await ctx.replyWithHTML(
    `рџ“„ <b>РњР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚</b>\n\n` +
    `РћС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ. РњРѕР¶РЅРѕ РѕС‚РїСЂР°РІРёС‚СЊ РЅРµСЃРєРѕР»СЊРєРѕ С„РѕС‚Рѕ РїРѕРґСЂСЏРґ.\n\n` +
    `рџ“Ћ <i>РќР°Р¶РјРёС‚Рµ РЅР° СЃРєСЂРµРїРєСѓ в†’ РљР°РјРµСЂР° РёР»Рё Р“Р°Р»РµСЂРµСЏ</i>`,
    routeSheetKeyboard()
  );
}

async function reconciliationFlow(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  const isTerminal = profile.device === 'РўРµСЂРјРёРЅР°Р»';
  const totalPhotos = isTerminal ? 2 : 1;

  setState(telegramId, {
    awaitingReconciliationPhoto: true,
    reconciliationPhotosSent: 0,
    reconciliationTotal: totalPhotos,
    fio: profile.fio,
    carNumber: profile.carNumber,
    workplace: profile.workplace,
    device: profile.device
  });

  const firstLabel = isTerminal ? 'рџ“Љ РЎС‚Р°С‚РёСЃС‚РёРєР°' : 'РџРёРЅ-РџР°РЅРµР»СЊ';
  const orderHint = isTerminal
    ? '<b>РџРѕСЂСЏРґРѕРє:</b> СЃРЅР°С‡Р°Р»Р° СЃРєСЂРёРЅС€РѕС‚ СЃС‚Р°С‚РёСЃС‚РёРєРё, РїРѕС‚РѕРј С‡РµРє.'
    : '';

  const lines = [
    `рџ“ё <b>РЎРІРµСЂРєРё</b>`,
    '',
    `рџ“· Р¤РѕС‚Рѕ <b>1 РёР· ${totalPhotos}</b>: <b>${firstLabel}</b>`,
  ];
  if (orderHint) {
    lines.push('');
    lines.push(orderHint);
  }
  lines.push('');
  lines.push('рџ“Ћ <i>РќР°Р¶РјРёС‚Рµ РЅР° СЃРєСЂРµРїРєСѓ в†’ РљР°РјРµСЂР° РёР»Рё Р“Р°Р»РµСЂРµСЏ</i>');

  await ctx.replyWithHTML(lines.join('\n'), routeSheetKeyboard());
}

async function showPendingCashStatus(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const profile = await ensureProfile(ctx);
  if (!profile) return;

  const pendingCash = getPendingCash(ctx.from.id);
  const amount = Number(pendingCash?.amount || 0);

  if (!Number.isFinite(amount) || amount < 1) {
    await ctx.replyWithHTML('вњ… Р”РѕР»РіРѕРІ РЅРµС‚ вЂ” РІСЃРµ РґРµРЅСЊРіРё СЃРґР°РЅС‹.', getMenuForRole(ctx.from.id));
    return;
  }

  if (pendingCash?.confirmationStatus === 'awaiting') {
    await ctx.replyWithHTML('вЏі Р’С‹ СѓР¶Рµ РѕС‚РјРµС‚РёР»Рё СЃРґР°С‡Сѓ. РћР¶РёРґР°Р№С‚Рµ РїРѕРґС‚РІРµСЂР¶РґРµРЅРёСЏ Р»РѕРіРёСЃС‚Р°.', getMenuForRole(ctx.from.id));
    return;
  }

  const formatted = pendingCash?.formatted || formatMoneyRu(amount);
  const numberOnly = formatMoneyRuNumber(amount) || String(formatted || '').replace(/\s*в‚Ѕ$/, '');
  const workplace = pendingCash?.workplace || profile.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ';
  const fun = String(process.env.FUN_TONE || '').toLowerCase() === 'true';
  const lines = [
    `рџ’µ <b>Р”РµРЅСЊРіРё Рє СЃРґР°С‡Рµ</b>: <code>${esc(numberOnly)}</code> в‚Ѕ`,
    `рџЏ¬ <b>${esc(workplace)}</b>`,
    ''
  ];
  if (fun) lines.push('рџј РђР№-Р°Р№, РґРµРЅСЋР¶РєРё РЅР°РґРѕ СЃРґР°С‚СЊ!', '');
  lines.push('РЎРґР°Р»Рё РґРµРЅСЊРіРё РІ РєР°СЃСЃСѓ?');
  await ctx.replyWithHTML(lines.join('\n'), cashSubmitConfirmKeyboard());
}

async function sendHelp(ctx) {
  const role = getUserRole(ctx.from.id);

  if (role === 'logist') {
    const workplace = getUserField(ctx.from.id, 'workplace');
    const features = WORKPLACE_FEATURES[workplace] || {};
    const hasCash = features.cashCollection;
    let logistHelp = 'вќ“ <b>РџРѕРјРѕС‰СЊ</b>\n' +
      'в”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓ\n\n' +
      `1пёЏвѓЈ <b>Р—Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ</b> вЂ” В«${BUTTONS.punchTime}В» РѕС‚РјРµС‚РёС‚СЊ РЅР°С‡Р°Р»Рѕ РёР»Рё РєРѕРЅРµС† СЃРјРµРЅС‹.\n` +
      `2пёЏвѓЈ <b>РћС‚РєСЂС‹С‚СЊ РРњ</b> вЂ” В«${BUTTONS.openShop}В» РѕС‚РїСЂР°РІРёС‚СЊ СѓРІРµРґРѕРјР»РµРЅРёРµ РѕР± РѕС‚РєСЂС‹С‚РёРё РјР°РіР°Р·РёРЅР° РІ РіСЂСѓРїРїСѓ.\n`;
    if (hasCash) {
      logistHelp += `3пёЏвѓЈ <b>РџСЂРёРЅСЏС‚СЊ РЅР°Р»РёС‡РЅС‹Рµ</b> вЂ” В«${BUTTONS.cashCollect}В» РїРѕСЃРјРѕС‚СЂРµС‚СЊ РґРѕР»Р¶РЅРёРєРѕРІ Рё РѕС‚РїСЂР°РІРёС‚СЊ РЅР°РїРѕРјРёРЅР°РЅРёРµ.\n`;
      logistHelp += `4пёЏвѓЈ <b>РСЃС‚РѕСЂРёСЏ СЃР±РѕСЂРѕРІ</b> вЂ” В«${BUTTONS.cashHistory}В» РїСЂРѕСЃРјРѕС‚СЂ РёСЃС‚РѕСЂРёРё РїРѕ РґР°С‚Р°Рј.\n`;
    }
    logistHelp += `${hasCash ? '5пёЏвѓЈ' : '3пёЏвѓЈ'} <b>РўР°Р±Р»РёС†С‹</b> вЂ” В«${BUTTONS.sheetInfo}В» РёРЅС„РѕСЂРјР°С†РёСЏ Рѕ РїСЂРёРІСЏР·РєРµ С‚Р°Р±Р»РёС†.\n`;
    logistHelp += `${hasCash ? '6пёЏвѓЈ' : '4пёЏвѓЈ'} <b>РќР°СЃС‚СЂРѕР№РєРё</b> вЂ” В«${BUTTONS.settings}В» РјР°РіР°Р·РёРЅ, СЃРјРµРЅР° СЃРѕС‚СЂСѓРґРЅРёРєР°.\n\n`;
    logistHelp += 'рџ“‹ РљРѕРјР°РЅРґС‹:';
    await ctx.replyWithHTML(
      logistHelp,
      Markup.inlineKeyboard([
        [Markup.button.callback('рџ“‹ РљРѕРјР°РЅРґС‹', 'help_commands')]
      ])
    );
    return;
  }

  await ctx.replyWithHTML(
    'вќ“ <b>РџРѕРјРѕС‰СЊ</b>\n' +
    'в”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓ\n\n' +
    '1пёЏвѓЈ <b>РџРµСЂРІС‹Р№ РІС…РѕРґ</b> вЂ” РІРІРµРґРёС‚Рµ Р¤РРћ, РЅРѕРјРµСЂ РјР°С€РёРЅС‹, РјР°РіР°Р·РёРЅ Рё СѓСЃС‚СЂРѕР№СЃС‚РІРѕ.\n' +
    `2пёЏвѓЈ <b>Р—Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ</b> вЂ” В«${BUTTONS.punchTime}В» РѕС‚РјРµС‚РёС‚СЊ РЅР°С‡Р°Р»Рѕ РёР»Рё РєРѕРЅРµС† СЃРјРµРЅС‹.\n` +
    `3пёЏвѓЈ <b>Р¤РѕС‚Рѕ РїСЂРѕР±РµРіР°</b> вЂ” В«${BUTTONS.mileage}В» РѕС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ РѕРґРѕРјРµС‚СЂР° РёР»Рё РІРІРµРґРёС‚Рµ РІСЂСѓС‡РЅСѓСЋ.\n` +
    '   вЂў В«рџ“· Р—Р°РіСЂСѓР·РёС‚СЊ С„РѕС‚Рѕ РїРѕРІС‚РѕСЂРЅРѕВ» РёР»Рё В«вњЏпёЏ Р’РІРµСЃС‚Рё РІСЂСѓС‡РЅСѓСЋВ» РµСЃР»Рё РЅРµ СЂР°СЃРїРѕР·РЅР°Р»РѕСЃСЊ.\n' +
    `4пёЏвѓЈ <b>РћС‚РїСЂР°РІРёС‚СЊ РјР°СЂС€СЂСѓС‚РЅРёРє</b> вЂ” В«${BUTTONS.routeSheet}В» РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ РјР°СЂС€СЂСѓС‚РЅРѕРіРѕ Р»РёСЃС‚Р°.\n` +
    `5пёЏвѓЈ <b>РћС‚РїСЂР°РІРёС‚СЊ СЃРІРµСЂРєСѓ</b> вЂ” В«${BUTTONS.reconciliation}В» РўРµСЂРјРёРЅР°Р» вЂ” 2 С„РѕС‚Рѕ, РџРёРЅ-РџР°РЅРµР»СЊ вЂ” 1 С„РѕС‚Рѕ.\n` +
    `6пёЏвѓЈ <b>РЎРґР°С‚СЊ РЅР°Р»РёС‡РЅС‹Рµ</b> вЂ” В«${BUTTONS.cashCheck}В» РїРѕРєР°Р·Р°С‚СЊ СЃСѓРјРјСѓ Рє СЃРґР°С‡Рµ Рё РїРѕРґС‚РІРµСЂРґРёС‚СЊ.\n` +
    `7пёЏвѓЈ <b>РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј</b> вЂ” В«${BUTTONS.issues}В» СЃСЃС‹Р»РєРё РґР»СЏ СЂРµС€РµРЅРёСЏ РїСЂРѕР±Р»РµРј СЃ Р·Р°РєР°Р·Р°РјРё.\n` +
    `8пёЏвѓЈ <b>Р РµР№С‚РёРЅРі</b> вЂ” В«${BUTTONS.leaderBoard}В» СЂРµР№С‚РёРЅРі РєСѓСЂСЊРµСЂРѕРІ РїРѕ Р·Р°РєР°Р·Р°Рј.\n` +
    `9пёЏвѓЈ <b>РќР°СЃС‚СЂРѕР№РєРё</b> вЂ” В«${BUTTONS.settings}В» РЅРѕРјРµСЂ РјР°С€РёРЅС‹, РјР°РіР°Р·РёРЅ, СѓСЃС‚СЂРѕР№СЃС‚РІРѕ, СЃРѕС‚СЂСѓРґРЅРёРє.\n\n` +
    'рџ“‹ РљРѕРјР°РЅРґС‹:',
    Markup.inlineKeyboard([
      [Markup.button.callback('рџ“‹ РљРѕРјР°РЅРґС‹', 'help_commands')]
    ])
  );
}

async function sendCommandsList(ctx) {
  const isAdmin = isAdminUser(ctx.from.id);
  const role = getUserRole(ctx.from.id);
  let msg = 'рџ“‹ <b>РљРѕРјР°РЅРґС‹</b>\n' +
    'в”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓв”Ѓ\n\n' +
    '<b>РћСЃРЅРѕРІРЅС‹Рµ:</b>\n' +
    '/help вЂ” РїРѕРјРѕС‰СЊ\n' +
    '/cancel вЂ” РѕС‚РјРµРЅР° С‚РµРєСѓС‰РµРіРѕ РґРµР№СЃС‚РІРёСЏ\n\n';

  if (role !== 'logist') {
    msg += '<b>РќР°СЃС‚СЂРѕР№РєРё:</b>\n' +
      '/car вЂ” СЃРјРµРЅРёС‚СЊ РЅРѕРјРµСЂ РјР°С€РёРЅС‹\n' +
      '/workplace вЂ” СЃРјРµРЅРёС‚СЊ РјР°РіР°Р·РёРЅ\n' +
      '/device вЂ” СЃРјРµРЅРёС‚СЊ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ\n\n';
  } else {
    msg += '<b>РќР°СЃС‚СЂРѕР№РєРё:</b>\n' +
      '/workplace вЂ” СЃРјРµРЅРёС‚СЊ РјР°РіР°Р·РёРЅ\n\n';
  }

  if (isAdmin) {
    msg += '<b>РђРґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ:</b>\n' +
      '/chatid вЂ” РёРЅС„РѕСЂРјР°С†РёСЏ Рѕ С‡Р°С‚Рµ\n' +
      '/sheet вЂ” РїСЂРёРІСЏР·РєР° С‚Р°Р±Р»РёС†\n' +
      '/sheet_access вЂ” РґРѕСЃС‚СѓРї Рє В«рџ“‹ РўР°Р±Р»РёС†С‹В»\n' +
      '  <code>/sheet_access</code> вЂ” РїРѕРєР°Р·Р°С‚СЊ СЃРїРёСЃРѕРє\n' +
      '  <code>/sheet_access 123456789</code> вЂ” РґР°С‚СЊ РґРѕСЃС‚СѓРї\n' +
      '  <code>/sheet_access - 123456789</code> вЂ” СѓР±СЂР°С‚СЊ РґРѕСЃС‚СѓРї\n' +
      '/role вЂ” СЃРјРµРЅРёС‚СЊ СЂРѕР»СЊ РїРѕР»СЊР·РѕРІР°С‚РµР»СЏ\n\n';
  }

  if (role === 'logist') {
    msg += '<b>РљРЅРѕРїРєРё РјРµРЅСЋ:</b>\n' +
      `вЏ± <b>Р’СЂРµРјСЏ</b> вЂ” Р·Р°РїРёСЃР°С‚СЊ СЃС‚Р°СЂС‚/РєРѕРЅРµС†\n` +
      `рџ’і <b>РќР°Р»РёС‡РЅС‹Рµ</b> вЂ” РїРѕСЃРјРѕС‚СЂРµС‚СЊ РґРѕР»Р¶РЅРёРєРѕРІ, РѕС‚РїСЂР°РІРёС‚СЊ РЅР°РїРѕРјРёРЅР°РЅРёРµ\n` +
      `рџ“‹ <b>РўР°Р±Р»РёС†С‹</b> вЂ” РёРЅС„РѕСЂРјР°С†РёСЏ Рѕ РїСЂРёРІСЏР·РєРµ С‚Р°Р±Р»РёС†\n` +
      `вљ™пёЏ <b>РќР°СЃС‚СЂРѕР№РєРё</b> вЂ” РјР°РіР°Р·РёРЅ, СЃРѕС‚СЂСѓРґРЅРёРє`;
  } else {
    msg += '<b>РљРЅРѕРїРєРё РјРµРЅСЋ:</b>\n' +
      `вЏ± <b>Р’СЂРµРјСЏ</b> вЂ” Р·Р°РїРёСЃР°С‚СЊ СЃС‚Р°СЂС‚/РєРѕРЅРµС†\n` +
      `рџљ— <b>РџСЂРѕР±РµРі</b> вЂ” С„РѕС‚Рѕ РѕРґРѕРјРµС‚СЂР° в†’ СЂР°СЃРїРѕР·РЅР°РІР°РЅРёРµ\n` +
      `рџ“„ <b>РњР°СЂС€СЂСѓС‚РЅРёРє</b> вЂ” РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ\n` +
      `рџ“Љ <b>РЎРІРµСЂРєРё</b> вЂ” С„РѕС‚Рѕ С‚РµСЂРјРёРЅР°Р»Р°/РїРёРЅ-РїР°РЅРµР»Рё\n` +
      `рџ’µ <b>РќР°Р»РёС‡РЅС‹Рµ</b> вЂ” СЃСѓРјРјР° Рє СЃРґР°С‡Рµ\n` +
      `вљ пёЏ <b>РџСЂРѕР±Р»РµРјР°</b> вЂ” СЂРµС€РёС‚СЊ РїСЂРѕР±Р»РµРјСѓ СЃ Р·Р°РєР°Р·РѕРј\n` +
      `рџЏ† <b>Р›РёРґРµСЂР±РѕСЂРґ</b> вЂ” СЂРµР№С‚РёРЅРі РєСѓСЂСЊРµСЂРѕРІ\n` +
      `вљ™пёЏ <b>РќР°СЃС‚СЂРѕР№РєРё</b> вЂ” РјР°С€РёРЅР°, РјР°РіР°Р·РёРЅ, СѓСЃС‚СЂРѕР№СЃС‚РІРѕ, СЃРѕС‚СЂСѓРґРЅРёРє`;
  }

  await ctx.replyWithHTML(msg);
}

function parseUpdateNotesFromEnv() {
  const raw = String(process.env.UPDATE_NOTES || '').trim();
  if (!raw) return [];

  return raw
    .split('|')
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

function loadChangelog() {
  try {
    if (!fs.existsSync(changelogPath)) return null;
    return JSON.parse(fs.readFileSync(changelogPath, 'utf8'));
  } catch {
    return null;
  }
}

function getLatestChangelogNotes() {
  const changelog = loadChangelog();
  if (!changelog || !Array.isArray(changelog.updates) || changelog.updates.length === 0) return null;

  const latest = changelog.updates[changelog.updates.length - 1];
  if (!latest || !Array.isArray(latest.notes) || latest.notes.length === 0) return null;

  return latest.notes.slice(0, 4);
}

function getChangelogBump() {
  const changelog = loadChangelog();
  if (!changelog || !Array.isArray(changelog.updates) || changelog.updates.length === 0) return 'patch';

  const latest = changelog.updates[changelog.updates.length - 1];
  const bump = String(latest.bump || '').toLowerCase().trim();
  if (bump === 'major' || bump === 'minor') return bump;
  return 'patch';
}

function buildUpdateHighlights(changedFiles = [], version, updates = []) {
  if (Array.isArray(updates) && updates.length > 0) {
    return updates;
  }

  const changelogNotes = getLatestChangelogNotes();
  if (changelogNotes && changelogNotes.length > 0) {
    return changelogNotes;
  }

  const envNotes = parseUpdateNotesFromEnv();
  if (envNotes.length > 0) {
    return envNotes;
  }

  const files = new Set((changedFiles || []).map((file) => String(file || '').toLowerCase()));
  const includesAny = (targets) => targets.some((target) => files.has(target.toLowerCase()));
  const highlights = [];

  if (includesAny(['bot.js'])) {
    highlights.push('рџ¤– РџРѕРґРїСЂР°РІРёР»Рё СЃС†РµРЅР°СЂРёРё СЂР°Р±РѕС‚С‹ Рё СЃС‚Р°Р±РёР»СЊРЅРѕСЃС‚СЊ.');
  }

  if (includesAny(['sheetcommand.js', 'googlesheets.js', 'storage.js'])) {
    highlights.push('рџ—‚ РЈР»СѓС‡С€РёР»Рё СЂР°Р±РѕС‚Сѓ СЃ С‚Р°Р±Р»РёС†Р°РјРё Рё РїСЂРёРІСЏР·РєР°РјРё.');
  }

  if (includesAny(['mileageocr.js'])) {
    highlights.push('рџ“ё РЈР»СѓС‡С€РёР»Рё СЂР°СЃРїРѕР·РЅР°РІР°РЅРёРµ РїСЂРѕР±РµРіР° РїРѕ С„РѕС‚Рѕ.');
  }

  if (includesAny(['utils.js'])) {
    highlights.push('рџ§® РћР±РЅРѕРІРёР»Рё РІСЃРїРѕРјРѕРіР°С‚РµР»СЊРЅС‹Рµ С„СѓРЅРєС†РёРё.');
  }

  if (highlights.length === 0) {
    highlights.push('вњЁ РќРµР±РѕР»СЊС€РёРµ СѓР»СѓС‡С€РµРЅРёСЏ СЃС‚Р°Р±РёР»СЊРЅРѕСЃС‚Рё Рё СѓРґРѕР±СЃС‚РІР°.');
  }

  return highlights.slice(0, 4);
}

function formatUpdateMessage(version, changedFiles = [], updates = []) {
  const highlights = buildUpdateHighlights(changedFiles, version, updates);
  const lines = highlights.map((item) => `вЂў ${esc(item)}`).join('\n');

  return (
    `рџ†• <b><i>РћР±РЅРѕРІР»РµРЅРёРµ Р±РѕС‚Р° v${esc(version)}</i></b>\n\n` +
    '<b>РљРѕСЂРѕС‚РєРѕ, С‡С‚Рѕ РёР·РјРµРЅРёР»Рё:</b>\n' +
    `${lines}\n\n` +
    'рџ’™ РҐРѕСЂРѕС€РµР№ СЃРјРµРЅС‹!'
  );
}

async function notifyUsersAboutUpdate(version, changedFiles = [], updates = []) {
  const currentVersion = version || getVersion();
  const userIds = getAllUserIds();
  let notified = 0;
  let skipped = 0;
  let failed = 0;

  const message = formatUpdateMessage(currentVersion, changedFiles, updates);

  for (const telegramId of userIds) {
    const lastVersion = getUserField(telegramId, 'version');
    if (lastVersion === currentVersion) {
      skipped++;
      continue;
    }

    try {
      await withTimeout(
        bot.telegram.sendMessage(Number(telegramId), message, {
          parse_mode: 'HTML',
          disable_notification: true
        }),
        10000,
        'update notify'
      );
      setUserField(telegramId, 'version', currentVersion);
      notified++;
    } catch (error) {
      console.error('update notify error', error.message);
      failed++;
    }

    await new Promise((r) => setTimeout(r, 50));
  }

  console.log(`update v${currentVersion} notify summary: total=${userIds.length}, sent=${notified}, skipped=${skipped}, failed=${failed}`);
}

const _pendingUpdates = {};
const PENDING_UPDATES_FILE = path.join(__dirname, 'pending_updates.json');

function loadPendingUpdates() {
  try {
    if (fs.existsSync(PENDING_UPDATES_FILE)) {
      const data = JSON.parse(fs.readFileSync(PENDING_UPDATES_FILE, 'utf8'));
      Object.assign(_pendingUpdates, data);
      console.log('loaded pending updates', Object.keys(data));
    }
  } catch (e) {
    console.error('failed to load pending updates', e.message);
  }
}

function savePendingUpdates() {
  try {
    fs.writeFileSync(PENDING_UPDATES_FILE, JSON.stringify(_pendingUpdates, null, 2));
  } catch (e) {
    console.error('failed to save pending updates', e.message);
  }
}

loadPendingUpdates();

async function askAdminsAboutUpdate(version, changedFiles = [], updates = []) {
  const adminIds = getAdminIds();
  if (adminIds.length === 0) {
    console.log('no admin IDs configured, skipping update approval');
    return;
  }

  const message = formatUpdateMessage(version, changedFiles, updates);
  const previewText = (
    `рџ”” <b>РћР±РЅР°СЂСѓР¶РµРЅРѕ РѕР±РЅРѕРІР»РµРЅРёРµ v${esc(version)}</b>\n\n` +
    '<b>РџСЂРµРґРїСЂРѕСЃРјРѕС‚СЂ СЃРѕРѕР±С‰РµРЅРёСЏ:</b>\n\n' +
    `${message}\n\n` +
    'РћС‚РїСЂР°РІРёС‚СЊ СѓРІРµРґРѕРјР»РµРЅРёРµ РІСЃРµРј РїРѕР»СЊР·РѕРІР°С‚РµР»СЏРј?'
  );

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('вњ… РћС‚РїСЂР°РІРёС‚СЊ', `upd_send:${version}`),
      Markup.button.callback('вњЏпёЏ РР·РјРµРЅРёС‚СЊ С‚РµРєСЃС‚', `upd_edit:${version}`)
    ],
    [Markup.button.callback('вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊ', `upd_skip:${version}`)]
  ]);

  _pendingUpdates[version] = { changedFiles, updates, message };
  savePendingUpdates();

  for (const adminId of adminIds) {
    try {
      await bot.telegram.sendMessage(adminId, previewText, {
        parse_mode: 'HTML',
        ...keyboard
      });
    } catch (error) {
      console.error('admin update ask error', adminId, error.message);
    }
  }
}

bot.action(/^upd_send:(.+)$/, async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    await ctx.answerCbQuery();
    return;
  }
  const version = ctx.match[1];
  const pending = _pendingUpdates[version];
  if (!pending) {
    await ctx.answerCbQuery('вљ пёЏ РћР±РЅРѕРІР»РµРЅРёРµ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅРѕ');
    return;
  }
  delete _pendingUpdates[version];
  savePendingUpdates();
  await ctx.editMessageText('вњ… РЈРІРµРґРѕРјР»РµРЅРёРµ РѕС‚РїСЂР°РІР»СЏРµС‚СЃСЏ...', { parse_mode: 'HTML' });
  await notifyUsersAboutUpdate(version, pending.changedFiles, pending.updates || []);
  try {
    await ctx.editMessageText(`вњ… РЈРІРµРґРѕРјР»РµРЅРёРµ v${esc(version)} РѕС‚РїСЂР°РІР»РµРЅРѕ РІСЃРµРј РїРѕР»СЊР·РѕРІР°С‚РµР»СЏРј.`, { parse_mode: 'HTML' });
  } catch {}
});

bot.action(/^upd_edit:(.+)$/, async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    await ctx.answerCbQuery();
    return;
  }
  const version = ctx.match[1];
  const pending = _pendingUpdates[version];
  if (!pending) {
    await ctx.answerCbQuery('вљ пёЏ РћР±РЅРѕРІР»РµРЅРёРµ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅРѕ');
    return;
  }
  setState(ctx.from.id, { awaitingUpdateEdit: true, editVersion: version });
  await ctx.replyWithHTML('вњЏпёЏ <b>Р РµРґР°РєС‚РёСЂРѕРІР°РЅРёРµ СѓРІРµРґРѕРјР»РµРЅРёСЏ</b>\n\nРћС‚РїСЂР°РІСЊС‚Рµ РЅРѕРІС‹Р№ С‚РµРєСЃС‚ СЃРѕРѕР±С‰РµРЅРёСЏ (Р±РµР· Р·Р°РіРѕР»РѕРІРєР° В«РћР±РЅРѕРІР»РµРЅРёРµ Р±РѕС‚Р° v...В» Рё В«РҐРѕСЂРѕС€РµР№ СЃРјРµРЅС‹В» вЂ” РѕРЅРё РґРѕР±Р°РІСЏС‚СЃСЏ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё):');
  await ctx.answerCbQuery();
});

bot.action(/^upd_skip:(.+)$/, async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    await ctx.answerCbQuery();
    return;
  }
  const version = ctx.match[1];
  delete _pendingUpdates[version];
  savePendingUpdates();
  try {
    await ctx.editMessageText(`вЏ­пёЏ РЈРІРµРґРѕРјР»РµРЅРёРµ v${esc(version)} РїСЂРѕРїСѓС‰РµРЅРѕ.`, { parse_mode: 'HTML' });
  } catch {}
  await ctx.answerCbQuery('РџСЂРѕРїСѓС‰РµРЅРѕ');
});

async function saveMileageFromState(ctx, mileage, options = {}) {
  const { sourceBuffer, telegram, chatId, fallbackState } = options;
  const replyFn = telegram
    ? (html, extra) => telegram.sendMessage(chatId, html, { parse_mode: 'HTML', ...(extra || {}) })
    : (html, extra) => ctx.replyWithHTML(html, extra);

  const telegramId = ctx.from.id;
  let state = getState(telegramId);
  const mileageValue = parseMileageNumber(mileage);

  // Р•СЃР»Рё СЃРѕСЃС‚РѕСЏРЅРёРµ РѕС‡РёС‰РµРЅРѕ (РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ СѓС€С‘Р» РІ РјРµРЅСЋ) вЂ” РёСЃРїРѕР»СЊР·СѓРµРј fallback.
  // Р•СЃР»Рё РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ РЅР°С‡Р°Р» РЅРѕРІРѕРµ С„РѕС‚Рѕ (fileId РёР·РјРµРЅРёР»СЃСЏ) вЂ” РЅРµ РїРёС€РµРј СЃС‚Р°СЂС‹Р№ СЂРµР·СѓР»СЊС‚Р°С‚.
  if (!state || !state.mileageRow || !state.day) {
    if (!fallbackState) {
      await replyFn('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ РїСЂРѕР±РµРі.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
      return;
    }
    const live = getState(telegramId);
    if (live && live.fileId && live.fileId !== fallbackState.fileId) {
      console.log('mileage: user started new photo, skipping old save');
      return;
    }
    state = fallbackState;
  } else if (state.fileId && fallbackState && state.fileId !== fallbackState.fileId) {
    // Р–РёРІРѕРµ СЃРѕСЃС‚РѕСЏРЅРёРµ РµСЃС‚СЊ, РЅРѕ fileId СЂР°Р·РЅС‹Р№ вЂ” РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ РЅР°С‡Р°Р» РЅРѕРІС‹Р№ РїСЂРѕР±РµРі
    console.log('mileage: live state has different fileId, skipping old save');
    await replyFn('вљ пёЏ <b>РџСЂРѕР±РµРі СЂР°СЃРїРѕР·РЅР°РЅ, РЅРѕ РІС‹ РЅР°С‡Р°Р»Рё РЅРѕРІРѕРµ РґРµР№СЃС‚РІРёРµ.</b>\nР•СЃР»Рё РЅСѓР¶РЅРѕ, РѕС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ РїРѕРІС‚РѕСЂРЅРѕ.', mileageConfirmKeyboard());
    return;
  }

  if (!state || !state.mileageRow || !state.day || !state.stage) {
    await replyFn('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ РїСЂРѕР±РµРі.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
    return;
  }

  if (!mileageValue) {
    await replyFn('вќЊ РќРµРІРµСЂРЅС‹Р№ РїСЂРѕР±РµРі. Р”РѕРїСѓСЃС‚РёРјС‹ С‚РѕР»СЊРєРѕ 2-6 С†РёС„СЂ.\nРќР°РїСЂРёРјРµСЂ: <code>25408</code>');
    return;
  }

  try {
    if (state.stage === 'end') {
      const startCell = getMileageStageCell(state, 'start');

      if (startCell) {
        const sheetContext = resolveSheetInfo(startCell.workplace);
        if (!sheetContext.sheetId) {
          await replyFn(formatNoSheetMessage({
            noSheet: true,
            noSheetForMonth: sheetContext.noSheetForMonth,
            monthKey: sheetContext.monthKey
          }, startCell.workplace));
          return;
        }

        const startRaw = await readCell(startCell.sheetName, startCell.cell, sheetContext.sheetId);
        const startValue = parseMileageNumber(startRaw);
        const maxDelta = getMaxShiftMileageDelta();

        if (startValue && mileageValue < startValue) {
          await replyFn(
            `вќЊ РџСЂРѕР±РµРі РєРѕРЅС†Р° СЃРјРµРЅС‹ РЅРµ РјРѕР¶РµС‚ Р±С‹С‚СЊ РјРµРЅСЊС€Рµ СЃС‚Р°СЂС‚Р°.\n` +
            `РЎС‚Р°СЂС‚: <code>${startValue}</code> РєРј\n` +
            `Р’РІРµРґРµРЅРѕ: <code>${mileageValue}</code> РєРј`
          );
          return;
        }

        if (startValue && (mileageValue - startValue) > maxDelta) {
          await replyFn(
            `вќЊ РЎР»РёС€РєРѕРј Р±РѕР»СЊС€РѕР№ РїСЂРёСЂРѕСЃС‚ РїСЂРѕР±РµРіР° Р·Р° СЃРјРµРЅСѓ.\n` +
            `РЎС‚Р°СЂС‚: <code>${startValue}</code> РєРј\n` +
            `Р’РІРµРґРµРЅРѕ: <code>${mileageValue}</code> РєРј\n` +
            `РњР°РєСЃРёРјСѓРј Р·Р° СЃРјРµРЅСѓ: <code>${maxDelta}</code> РєРј`
          );
          return;
        }
      }
    }

    await updateMileage(state.mileageRow, state.day, state.stage, mileageValue, state.workplace);
    console.log('РїСЂРѕР±РµРі Р·Р°РїРёСЃР°РЅ');
    addXp(telegramId, getXpForAction('mileage'), 'Р—Р°РїРёСЃСЊ РїСЂРѕР±РµРіР°');
    updateChallengeProgress(telegramId, 'mileages');
    logOcrFeedback(telegramId, state.ocrValue || null, mileageValue, sourceBuffer, {
      stage: state.stage,
      workplace: state.workplace,
      fio: state.fio,
      fileId: state.fileId
    });
    setState(telegramId, {
      ...state,
      awaitingMileagePhoto: false,
      awaitingManualMileage: false,
      photoReceived: true,
      savedMileage: mileageValue,
      mileageProcessing: false
    });
    await replyFn(
      `вњ… <b>РџСЂРѕР±РµРі СЃРѕС…СЂР°РЅС‘РЅ</b>: <code>${mileageValue}</code> РєРј\n\nР•СЃР»Рё РЅРµРІРµСЂРЅРѕ вЂ” РЅР°Р¶РјРёС‚Рµ В«РР·РјРµРЅРёС‚СЊ РїСЂРѕР±РµРіВ».`,
      mileageSavedKeyboard()
    );
  } catch (error) {
    console.error('РѕС€РёР±РєР° Google Sheets', error);
    await replyFn('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ РїСЂРѕР±РµРі.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
  } finally {
    if (telegram) {
      const finalState = getState(telegramId);
      if (finalState) {
        setState(telegramId, { ...finalState, mileageProcessing: false });
      }
    }
  }
}

async function sendPhotoToChat(ctx, fileId, caption, { envChatId, envThreadId, parseMode, fallbackChatId } = {}) {
  let chatId = envChatId ? process.env[envChatId] : null;

  if (!chatId && fallbackChatId) {
    chatId = fallbackChatId;
  }

  if (!chatId) {
    console.log(`${envChatId || 'chatId'} is empty, photo is not forwarded`);
    return false;
  }

  const options = { caption };

  if (parseMode) {
    options.parse_mode = parseMode;
  }

  const threadId = envThreadId ? process.env[envThreadId] : null;
  if (threadId) {
    options.message_thread_id = Number(threadId);
  }

  try {
    await ctx.telegram.sendPhoto(chatId, fileId, options);
    return true;
  } catch (error) {
    console.error('telegram sendPhoto error', error?.message || error);
    return false;
  }
}

async function sendMediaGroupToChat(ctx, items, { envChatId, envThreadId, parseMode, fallbackChatId } = {}) {
  let chatId = envChatId ? process.env[envChatId] : null;

  if (!chatId && fallbackChatId) {
    chatId = fallbackChatId;
  }

  if (!chatId) {
    console.log(`${envChatId || 'chatId'} is empty, media group is not forwarded`);
    return false;
  }

  const media = items.map((item, index) => {
    const entry = {
      type: 'photo',
      media: item.fileId
    };
    if (index === 0 && item.caption) {
      entry.caption = item.caption;
      if (parseMode) {
        entry.parse_mode = parseMode;
      }
    }
    return entry;
  });

  const options = {};
  const threadId = envThreadId ? process.env[envThreadId] : null;
  if (threadId) {
    options.message_thread_id = Number(threadId);
  }

  try {
    await ctx.telegram.sendMediaGroup(chatId, media, options);
    return true;
  } catch (error) {
    console.error('telegram sendMediaGroup error', error?.message || error);
    return false;
  }
}

// РљРѕРЅС„РёРі РЅР°Р·РЅР°С‡РµРЅРёР№ С„РѕС‚Рѕ вЂ” РµРґРёРЅР°СЏ С‚Р°Р±Р»РёС†Р°. Р•СЃР»Рё РїРѕСЏРІРёС‚СЃСЏ РЅРѕРІС‹Р№ С‡Р°С‚
// (РЅР°РїСЂРёРјРµСЂ, РґР»СЏ С€С‚СЂР°С„РѕРІ), РґРѕР±Р°РІРёС‚СЊ Р·Р°РїРёСЃСЊ Рё РѕРґРЅСѓ С„СѓРЅРєС†РёСЋ-РѕР±С‘СЂС‚РєСѓ.
const PHOTO_DESTINATIONS = {
  work: {
    envChatId: 'WORK_CHAT_ID',
    envThreadId: 'WORK_THREAD_ID'
  },
  routeSheet: {
    envChatId: 'ROUTE_SHEET_CHAT_ID',
    envThreadId: 'ROUTE_SHEET_THREAD_ID',
    fallbackEnvChatId: 'WORK_CHAT_ID'
  },
  reconciliation: {
    envChatId: 'RECONCILIATION_CHAT_ID',
    envThreadId: 'RECONCILIATION_THREAD_ID',
    fallbackEnvChatId: 'WORK_CHAT_ID',
    parseMode: 'HTML'
  }
};

function forwardPhoto(ctx, fileId, caption, destinationKey) {
  const dest = PHOTO_DESTINATIONS[destinationKey];
  if (!dest) {
    console.error('forwardPhoto: unknown destination', destinationKey);
    return Promise.resolve(false);
  }
  return sendPhotoToChat(ctx, fileId, caption, {
    envChatId: dest.envChatId,
    envThreadId: dest.envThreadId,
    parseMode: dest.parseMode,
    fallbackChatId: dest.fallbackEnvChatId ? process.env[dest.fallbackEnvChatId] : undefined
  });
}

// РћР±С‘СЂС‚РєРё РѕСЃС‚Р°РІР»РµРЅС‹ РґР»СЏ С‡РёС‚Р°РµРјРѕСЃС‚Рё РІ РјРµСЃС‚Р°С… РІС‹Р·РѕРІР°.
const sendPhotoToWorkChat = (ctx, fileId, caption) => forwardPhoto(ctx, fileId, caption, 'work');
const sendPhotoToRouteSheetChat = (ctx, fileId, caption) => forwardPhoto(ctx, fileId, caption, 'routeSheet');
const sendPhotoToReconciliationChat = (ctx, fileId, caption) => forwardPhoto(ctx, fileId, caption, 'reconciliation');

function forwardMediaGroup(ctx, items, destinationKey) {
  const dest = PHOTO_DESTINATIONS[destinationKey];
  if (!dest) {
    console.error('forwardMediaGroup: unknown destination', destinationKey);
    return Promise.resolve(false);
  }
  return sendMediaGroupToChat(ctx, items, {
    envChatId: dest.envChatId,
    envThreadId: dest.envThreadId,
    parseMode: dest.parseMode,
    fallbackChatId: dest.fallbackEnvChatId ? process.env[dest.fallbackEnvChatId] : undefined
  });
}

const sendMediaGroupToReconciliationChat = (ctx, items) => forwardMediaGroup(ctx, items, 'reconciliation');

async function backToMainMenu(ctx) {
  const state = getState(ctx.from.id);

  if (state?.mileageProcessing) {
    await ctx.replyWithHTML('рџ“ё РћР±СЂР°Р±РѕС‚РєР° С„РѕС‚Рѕ РїСЂРѕР±РµРіР° РїСЂРѕРґРѕР»Р¶Р°РµС‚СЃСЏ... СЂРµР·СѓР»СЊС‚Р°С‚ РїСЂРёРґС‘С‚ РІ РЅРѕРІС‹Р№ С‡Р°С‚.', getMenuForRole(ctx.from.id));
    return;
  }

  clearState(ctx.from.id);

  const message = state?.savedMileage
    ? 'в¬…пёЏ Р’РѕР·РІСЂР°С‰Р°СЋ РІ РјРµРЅСЋ.'
    : state?.mileageRow
      ? 'в¬…пёЏ Р’РѕР·РІСЂР°С‰Р°СЋ РІ РјРµРЅСЋ. РџСЂРѕР±РµРі РЅРµ СЃРѕС…СЂР°РЅС‘РЅ.'
      : 'в¬…пёЏ Р’РѕР·РІСЂР°С‰Р°СЋ РІ РјРµРЅСЋ.';

  await ctx.replyWithHTML(message, getMenuForRole(ctx.from.id));
}

async function showLeaderboardMenu(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  setState(ctx.from.id, { lb_step: 'menu' });
  const settings = getNotificationSettings(ctx.from.id);
  const notifStatus = Object.values(settings).some(v => v) ? 'Р’РљР› вњ…' : 'Р’Р«РљР› вќЊ';
  await ctx.replyWithHTML(
    'рџЏ† <b>Р РµР№С‚РёРЅРі Рё РґРѕСЃС‚РёР¶РµРЅРёСЏ</b>\n\nР’С‹Р±РµСЂРёС‚Рµ СЂР°Р·РґРµР»:',
    Markup.inlineKeyboard([
      [Markup.button.callback('рџ“Љ РўР°Р±Р»РёС†Р° СЂРµР№С‚РёРЅРіР°', 'lb_table')],
      [Markup.button.callback('рџ”Ґ Р§РµР»Р»РµРЅРґР¶Рё РЅРµРґРµР»Рё', 'lb_challenges')],
      [Markup.button.callback('рџЏ† РњРѕРё РґРѕСЃС‚РёР¶РµРЅРёСЏ', 'lb_achievements')],
      [Markup.button.callback('рџ“€ РњРѕР№ РїСЂРѕРіСЂРµСЃСЃ', 'lb_progress')],
      [Markup.button.callback('вќ“ РљР°Рє СЂР°Р±РѕС‚Р°РµС‚ XP', 'lb_xp_info')],
      [Markup.button.callback(`рџ”” РЈРІРµРґРѕРјР»РµРЅРёСЏ СЂРµР№С‚РёРЅРіР°: ${notifStatus}`, 'lb_notifications')],
      [Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')]
    ])
  );
}

async function showLeaderboardFilter(ctx) {
  setState(ctx.from.id, { lb_step: 'filter' });
  await ctx.replyWithHTML(
    'рџЏ† <b>Р›РёРґРµСЂР±РѕСЂРґ 2.0</b>\n\nР’С‹Р±РµСЂРёС‚Рµ С‚РёРї РєСѓСЂСЊРµСЂРѕРІ:',
    Markup.inlineKeyboard([
      [Markup.button.callback('рџљ— РђРІС‚Рѕ', 'lb_filter_auto'), Markup.button.callback('рџљ¶ РџРµС€РёРµ', 'lb_filter_pedestrian')],
      [Markup.button.callback('рџЏЃ Р’СЃРµ', 'lb_filter_all')],
      [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_menu')]
    ])
  );
}

async function showMyAchievements(ctx) {
  const telegramId = ctx.from.id;
  const profile = getFullProfile(telegramId);
  const unlocked = getUnlockedAchievements(telegramId);
  const allAchievements = getAllAchievements();

  let text = 'рџЏ† <b>РњРѕРё РґРѕСЃС‚РёР¶РµРЅРёСЏ</b>\n\n';
  if (unlocked.length === 0) {
    text += 'РџРѕРєР° РЅРµС‚ СЂР°Р·Р±Р»РѕРєРёСЂРѕРІР°РЅРЅС‹С… РґРѕСЃС‚РёР¶РµРЅРёР№.\nРџСЂРѕРґРѕР»Р¶Р°Р№С‚Рµ СЂР°Р±РѕС‚Р°С‚СЊ вЂ” РѕРЅРё РїРѕСЏРІСЏС‚СЃСЏ!\n\n';
  } else {
    text += `<b>Р Р°Р·Р±Р»РѕРєРёСЂРѕРІР°РЅРѕ: ${unlocked.length} / ${allAchievements.length}</b>\n\n`;
    for (const ach of unlocked.slice(0, 15)) {
      text += `вњ… ${ach.name} вЂ” ${ach.desc} (+${ach.reward} XP)\n`;
    }
    if (unlocked.length > 15) {
      text += `\n... Рё РµС‰С‘ ${unlocked.length - 15} РґРѕСЃС‚РёР¶РµРЅРёР№.`;
    }
    text += '\n';
  }

  text += '\n<i>Р”РѕСЃС‚РёР¶РµРЅРёСЏ СЂР°Р·Р±Р»РѕРєРёСЂСѓСЋС‚СЃСЏ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё РїСЂРё РІС‹РїРѕР»РЅРµРЅРёРё СѓСЃР»РѕРІРёР№.</i>';

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_menu')]
  ]));
}

async function showMyProgress(ctx) {
  const telegramId = ctx.from.id;
  const profile = getFullProfile(telegramId);
  const xp = getTotalXp(telegramId);
  const rankInfo = formatRankInfo(telegramId, profile.courierType);
  const streak = getStreak(telegramId);

  let text = 'рџ“€ <b>РњРѕР№ РїСЂРѕРіСЂРµСЃСЃ</b>\n\n';
  text += `рџ‘¤ <b>${esc(profile.fio || 'РљСѓСЂСЊРµСЂ')}</b>\n`;
  text += `рџљ— РўРёРї: ${profile.courierType === 'pedestrian' ? 'рџљ¶ РџРµС€РёР№' : 'рџљ— РђРІС‚Рѕ'}\n\n`;
  text += `в­ђ ${rankInfo}\n\n`;
  text += `рџ”Ґ РЎС‚СЂРёРє: ${streak.currentStreak} СЃРјРµРЅ (СЂРµРєРѕСЂРґ: ${streak.maxStreak})\n`;
  text += `рџ’° Р’СЃРµРіРѕ XP: ${xp.toLocaleString('ru-RU')}\n`;

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_menu')]
  ]));
}

async function showXpInfo(ctx) {
  const text =
    'вќ“ <b>РљР°Рє СЂР°Р±РѕС‚Р°РµС‚ XP</b>\n\n' +
    'Р—Р° РєР°Р¶РґРѕРµ РґРµР№СЃС‚РІРёРµ РІС‹ РїРѕР»СѓС‡Р°РµС‚Рµ РѕС‡РєРё РѕРїС‹С‚Р° (XP):\n\n' +
    'вЏ± РќР°С‡Р°Р»Рѕ/РєРѕРЅРµС† СЃРјРµРЅС‹ вЂ” <b>15 XP</b>\n' +
    'рџ“„ РњР°СЂС€СЂСѓС‚РЅРёРє вЂ” <b>30 XP</b>\n' +
    'рџ“Љ РЎРІРµСЂРєР° вЂ” <b>50 XP</b>\n' +
    'рџ’µ РЎРґР°С‡Р° РЅР°Р»РёС‡РЅС‹С… вЂ” <b>80 XP</b>\n' +
    'рџљ— РџСЂРѕР±РµРі вЂ” <b>30 XP</b>\n\n' +
    'рџЏ† <b>Р‘РѕРЅСѓСЃС‹:</b>\n' +
    'РўРѕРї-10 РґРЅСЏ вЂ” <b>150 XP</b>\n' +
    'РўРѕРї-3 РґРЅСЏ вЂ” <b>300 XP</b>\n' +
    'рџҐ‡ 1-Рµ РјРµСЃС‚Рѕ вЂ” <b>800 XP</b>\n\n' +
    'рџ”Ґ <b>РЎС‚СЂРёРє:</b> РєР°Р¶РґС‹Рµ 5 СЃРјРµРЅ РїРѕРґСЂСЏРґ вЂ” <b>+50 XP</b>\n\n' +
    'РЎ РЅР°РєРѕРїР»РµРЅРёРµРј XP СЂР°СЃС‚С‘С‚ РІР°С€ СЂР°РЅРі вЂ” РѕС‚ РќРѕРІРёС‡РєР° РґРѕ РљРѕСЂРѕР»СЏ СЂРµР№С‚РёРЅРіР°! рџ‘‘';

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_menu')]
  ]));
}

async function showNotificationSettings(ctx) {
  const telegramId = ctx.from.id;
  const settings = getNotificationSettings(telegramId);

  const toggle = (key, label, emoji) => {
    const isOn = settings[key];
    return Markup.button.callback(`${isOn ? 'вњ…' : 'вќЊ'} ${label}`, `notif_${key}`);
  };

  await ctx.replyWithHTML(
    'рџ”” <b>РќР°СЃС‚СЂРѕР№РєРё СѓРІРµРґРѕРјР»РµРЅРёР№ СЂРµР№С‚РёРЅРіР°</b>\n\n' +
    'РќР°Р¶РјРёС‚Рµ, С‡С‚РѕР±С‹ РІРєР»СЋС‡РёС‚СЊ РёР»Рё РІС‹РєР»СЋС‡РёС‚СЊ:\n\n' +
    'вњ… вЂ” РІРєР»СЋС‡РµРЅРѕ\n' +
    'вќЊ вЂ” РІС‹РєР»СЋС‡РµРЅРѕ',
    Markup.inlineKeyboard([
      [toggle('personalRecord', 'Р›РёС‡РЅС‹Р№ СЂРµРєРѕСЂРґ')],
      [toggle('overtake', 'РћР±РіРѕРЅС‹ РІ СЂРµР№С‚РёРЅРіРµ')],
      [toggle('workplaceRecord', 'Р РµРєРѕСЂРґ С‚РѕС‡РєРё')],
      [toggle('dailyLeader', 'Р›РёРґРµСЂ РґРЅСЏ / СЃР±СЂРѕСЃ')],
      [toggle('top3Change', 'РР·РјРµРЅРµРЅРёРµ С‚РѕРї-3')],
      [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ Рє СЂРµР№С‚РёРЅРіСѓ', 'lb_back_menu')]
    ])
  );
}

async function showWeeklyChallenges(ctx) {
  const telegramId = ctx.from.id;
  const profile = getFullProfile(telegramId);
  generateWeeklyChallenges(telegramId, profile.courierType);
  const challenges = getChallenges(telegramId);

  let text = 'рџ”Ґ <b>Р§РµР»Р»РµРЅРґР¶Рё РЅРµРґРµР»Рё</b>\n\n';
  if (challenges.length === 0) {
    text += 'РџРѕРєР° РЅРµС‚ Р°РєС‚РёРІРЅС‹С… С‡РµР»Р»РµРЅРґР¶РµР№. РџСЂРёС…РѕРґРёС‚Рµ РІ РїРѕРЅРµРґРµР»СЊРЅРёРє!\n';
  } else {
    for (const ch of challenges) {
      const status = ch.completed ? 'вњ… Р’С‹РїРѕР»РЅРµРЅРѕ' : `вЏі ${ch.current} / ${ch.target}`;
      text += `вЂў <b>${ch.name}</b>\n  ${ch.desc}\n  РќР°РіСЂР°РґР°: <b>${ch.reward} XP</b> вЂ” ${status}\n\n`;
    }
  }
  text += '<i>Р§РµР»Р»РµРЅРґР¶Рё РѕР±РЅРѕРІР»СЏСЋС‚СЃСЏ РєР°Р¶РґС‹Р№ РїРѕРЅРµРґРµР»СЊРЅРёРє.</i>';

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_menu')]
  ]));
}

async function showLeaderboardWorkplace(ctx, filter) {
  setState(ctx.from.id, { lb_step: 'workplace', lb_filter: filter });
  const wpButtons = WORKPLACES.map((wp) => {
    const key = WORKPLACE_KEY_MAP[wp] || wp;
    return Markup.button.callback(`рџЏ¬ ${wp}`, `lb_wp_${key}`);
  });
  await ctx.replyWithHTML(
    'рџЏ† <b>Р›РёРґРµСЂР±РѕСЂРґ</b>\n\nР’С‹Р±РµСЂРёС‚Рµ РјР°РіР°Р·РёРЅ:',
    Markup.inlineKeyboard([
      wpButtons,
      [Markup.button.callback('рџЏЃ Р’СЃРµ РјР°РіР°Р·РёРЅС‹', 'lb_wp_all')],
      [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_filter')]
    ])
  );
}

async function showLeaderboardPeriod(ctx, filter, workplace) {
  setState(ctx.from.id, { lb_step: 'period', lb_filter: filter, lb_workplace: workplace });
  await ctx.replyWithHTML(
    'рџЏ† <b>Р›РёРґРµСЂР±РѕСЂРґ</b>\n\nР’С‹Р±РµСЂРёС‚Рµ РїРµСЂРёРѕРґ:',
    Markup.inlineKeyboard([
      [
        Markup.button.callback('рџ“… РќРµРґРµР»СЏ', `lb_p_7`),
        Markup.button.callback('рџ“… РњРµСЃСЏС†', `lb_p_30`)
      ],
      [
        Markup.button.callback('рџ“… Р“РѕРґ', `lb_p_365`),
        Markup.button.callback('рџ“… Р’СЃС‘ РІСЂРµРјСЏ', `lb_p_0`)
      ],
      [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_workplace')]
    ])
  );
}

async function showLeaderboardMode(ctx, filter, workplace, periodDays) {
  setState(ctx.from.id, { lb_step: 'mode', lb_filter: filter, lb_workplace: workplace, lb_period: periodDays });
  const periodLabel = periodDays === 0 ? 'Р·Р° РІСЃС‘ РІСЂРµРјСЏ' : periodDays === 7 ? 'Р·Р° РЅРµРґРµР»СЋ' : periodDays === 30 ? 'Р·Р° РјРµСЃСЏС†' : periodDays === 365 ? 'Р·Р° РіРѕРґ' : `Р·Р° ${periodDays} РґРЅРµР№`;
  await ctx.replyWithHTML(
    `рџЏ† <b>Р›РёРґРµСЂР±РѕСЂРґ</b>\n${esc(periodLabel)}\n\nР’С‹Р±РµСЂРёС‚Рµ СЂРµР¶РёРј:`,
    Markup.inlineKeyboard([
      [Markup.button.callback('рџ“Љ РџРѕ СЃСѓРјРјРµ Р·Р°РєР°Р·РѕРІ', 'lb_mode_sum')],
      [Markup.button.callback('рџ”Ґ Р›СѓС‡С€РёР№ РґРµРЅСЊ', 'lb_mode_max')],
      [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_period')]
    ])
  );
}

async function showLeaderboardResultV2(ctx) {
  const telegramId = ctx.from.id;
  const state = getState(telegramId);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  const periodDays = state?.lb_period ?? 0;
  const mode = state?.lb_mode || 'sum';

  const showWorkplace = workplace === 'all';
  const entries = calculateLeaderboard(mode, periodDays, workplace, filter);

  const wpLabels = { east: 'РРњ Р’РѕСЃС‚РѕРє', center: 'РРњ Р¦РµРЅС‚СЂ', all: 'Р’СЃРµ РјР°РіР°Р·РёРЅС‹' };
  const wpLabel = wpLabels[workplace] || workplace;
  const filterLabel = filter === 'auto' ? 'рџљ— РђРІС‚Рѕ' : filter === 'pedestrian' ? 'рџљ¶ РџРµС€РёРµ' : 'рџЏЃ Р’СЃРµ';
  const periodLabel = periodDays === 0 ? 'РІСЃС‘ РІСЂРµРјСЏ' : periodDays === 7 ? 'РЅРµРґРµР»СЏ' : periodDays === 30 ? 'РјРµСЃСЏС†' : periodDays === 365 ? 'РіРѕРґ' : `${periodDays} РґРЅРµР№`;
  const modeLabel = mode === 'max' ? 'рџ”Ґ Р›СѓС‡С€РёР№ РґРµРЅСЊ' : 'рџ“Љ РџРѕ СЃСѓРјРјРµ';

  const lines = [`рџЏ† <b>Р РµР№С‚РёРЅРі</b>\n${filterLabel} | ${esc(wpLabel)} | ${esc(periodLabel)} | ${modeLabel}\n`];
  lines.push(formatLeaderboard(entries, telegramId, showWorkplace));
  lines.push(`\nв¬…пёЏ <i>РќР°Р¶РјРёС‚Рµ В«РќР°Р·Р°РґВ» РёР»Рё В«Р’ РјРµРЅСЋВ».</i>`);

  await ctx.replyWithHTML(lines.join('\n'), Markup.inlineKeyboard([
    [Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'lb_back_mode')],
    [Markup.button.callback('рџЏ  Р’ РјРµРЅСЋ', 'back_to_menu')]
  ]));
}

async function handleLeaderboardNotifications(ctx, telegramId, fio, workplace, ordersCount, oldOrders = 0) {
  try {
    // Р—Р°С‰РёС‚Р° РѕС‚ СЃРїР°РјР°: СѓРІРµРґРѕРјР»РµРЅРёСЏ С‚РѕР»СЊРєРѕ РїСЂРё СѓРІРµР»РёС‡РµРЅРёРё СЃС‡С‘С‚Р°
    if (ordersCount <= oldOrders) return;

    const settings = getNotificationSettings(telegramId);
    const dayKey = getLbTodayKey();

    // 1. Р›РёС‡РЅС‹Р№ СЂРµРєРѕСЂРґ
    if (settings.personalRecord) {
      const notifications = checkLeaderboardNotifications(telegramId, fio, workplace, ordersCount);
      for (const notif of notifications) {
        if (notif.type === 'personal_record') {
          await ctx.replyWithHTML(
            `рџЋ‰ <b>РќРѕРІС‹Р№ Р»РёС‡РЅС‹Р№ СЂРµРєРѕСЂРґ!</b>\n\nР’С‹ РґРѕСЃС‚Р°РІРёР»Рё <b>${notif.value}</b> Р·Р°РєР°Р·РѕРІ Р·Р° РґРµРЅСЊ!` +
            (notif.previous > 0 ? `\nРџСЂРµРґС‹РґСѓС‰РёР№ СЂРµРєРѕСЂРґ: ${notif.previous} Р·Р°РєР°Р·РѕРІ.` : '')
          );
        }
      }
    }

    // 2. РћР±РіРѕРЅС‹ РІ СЂРµР№С‚РёРЅРіРµ
    if (settings.overtake && workplace) {
      const overtaken = findOvertakenCouriers(telegramId, workplace, oldOrders, ordersCount, dayKey)
        .filter(v => getUserRole(v.telegramId) !== 'logist');

      for (const victim of overtaken) {
        const victimSettings = getNotificationSettings(victim.telegramId);
        if (!victimSettings.overtake) continue;
        try {
          await bot.telegram.sendMessage(victim.telegramId,
            `вљ пёЏ <b>Р’Р°СЃ РѕР±РѕРіРЅР°Р»Рё РІ СЂРµР№С‚РёРЅРіРµ!</b>\n\n` +
            `${esc(fio)} РґРѕСЃС‚Р°РІРёР» <b>${ordersCount}</b> Р·Р°РєР°Р·РѕРІ Рё РѕР±РѕРіРЅР°Р» РІР°СЃ.\n` +
            `РЈ РІР°СЃ СЃРµР№С‡Р°СЃ <b>${victim.orders}</b> Р·Р°РєР°Р·РѕРІ.\n` +
            `рџЏ¬ ${esc(workplace)}`,
            { parse_mode: 'HTML' }
          );
        } catch (e) {
          console.error('overtaken notify error', victim.telegramId, e.message || e);
        }
      }

      if (overtaken.length > 0) {
        const names = overtaken.map(v => `${esc(v.fio)} (${v.orders})`).join(', ');
        try {
          await ctx.replyWithHTML(
            `рџЋ‰ <b>Р’С‹ РѕР±РѕРіРЅР°Р»Рё РІ СЂРµР№С‚РёРЅРіРµ!</b>\n\n${names}\n\nРўРµРїРµСЂСЊ Сѓ РІР°СЃ <b>${ordersCount}</b> Р·Р°РєР°Р·РѕРІ.`
          );
        } catch (e) {
          console.error('overtaken self notify error', e.message || e);
        }
      }
    }

    // 3. Р РµРєРѕСЂРґ С‚РѕС‡РєРё + Р»РёРґРµСЂ РґРЅСЏ + С‚РѕРї-3
    if (workplace) {
      const currentTop3 = getDailyTop3(workplace, dayKey);
      const previousTop3 = [];

      // РџРѕР»СѓС‡Р°РµРј РїСЂРµРґС‹РґСѓС‰РёР№ СЂРµРєРѕСЂРґ С‚РѕС‡РєРё РґР»СЏ РїСЂРѕРІРµСЂРєРё
      const previousRecord = getWorkplaceRecord(workplace, dayKey);
      const wasRecord = !previousRecord || ordersCount > previousRecord.orders;

      if (wasRecord && settings.workplaceRecord) {
        setWorkplaceRecord(workplace, dayKey, ordersCount, fio);
        await sendWorkplaceRecordNotifications(workplace, dayKey, { fio, orders: ordersCount }, telegramId);
      }

      // Р›РёРґРµСЂ РґРЅСЏ
      if (currentTop3[0] && currentTop3[0].telegramId === String(telegramId)) {
        await sendDailyLeaderNotification(workplace, dayKey, currentTop3[0]);
      }

      // РџСЂРѕРІРµСЂРєР° СЃР±СЂРѕСЃР° СЃ 1-РіРѕ РјРµСЃС‚Р°
      const prevLeader = previousRecord ? { telegramId: previousRecord.fio } : null;
      if (previousRecord && previousRecord.fio !== fio && currentTop3[0] && currentTop3[0].telegramId === String(telegramId)) {
        // РќР°Р№С‚Рё Р±С‹РІС€РµРіРѕ Р»РёРґРµСЂР° РїРѕ workplace records
        const allIds = getAllUserIds();
        for (const id of allIds) {
          if (id === String(telegramId)) continue;
          const userFio = getUserField(id, 'fio');
          if (userFio === previousRecord.fio) {
            const victimSettings = getNotificationSettings(id);
            if (victimSettings.dailyLeader) {
              try {
                await bot.telegram.sendMessage(id,
                  `рџ“‰ <b>Р’Р°СЃ СЃР±СЂРѕСЃРёР»Рё СЃ 1-РіРѕ РјРµСЃС‚Р°!</b>\n\n` +
                  `${esc(fio)} РѕР±РѕРіРЅР°Р» РІР°СЃ СЃ <b>${ordersCount}</b> Р·Р°РєР°Р·Р°РјРё.\n` +
                  `РЈ РІР°СЃ СЃРµР№С‡Р°СЃ вЂ” РїРѕСЃРјРѕС‚СЂРёС‚Рµ СЃРІРѕСЋ СЃРІРµСЂРєСѓ.`,
                  { parse_mode: 'HTML' }
                );
              } catch (e) {
                console.error('leader dethroned notify error', id, e.message || e);
              }
            }
            break;
          }
        }
      }

      // РўРѕРї-3 РёР·РјРµРЅРёР»СЃСЏ
      if (settings.top3Change) {
        await sendTop3ChangeNotifications(workplace, dayKey, previousTop3, currentTop3, telegramId);
      }
    }
  } catch (err) {
    console.error('leaderboard notification error', err.message || err);
  }
}

function getNotificationSettings(telegramId) {
  const defaults = {
    personalRecord: true,
    overtake: true,
    workplaceRecord: true,
    dailyLeader: true,
    top3Change: true
  };
  const record = getUserField(telegramId, 'notificationSettings');
  if (!record) return defaults;
  try {
    const parsed = typeof record === 'string' ? JSON.parse(record) : record;
    return { ...defaults, ...parsed };
  } catch (e) {
    return defaults;
  }
}

async function sendWorkplaceRecordNotifications(workplace, dayKey, recordInfo, senderId) {
  const settings = getNotificationSettings(senderId);
  if (!settings.workplaceRecord) return;

  const records = getDailyTop3(workplace, dayKey);
  if (records.length === 0) return;

  const record = getWorkplaceRecord(workplace, dayKey);
  if (!record) return;

  let text = `рџЏ† <b>РќРѕРІС‹Р№ СЂРµРєРѕСЂРґ С‚РѕС‡РєРё ${esc(workplace)}!</b>\n\n`;
  text += `рџҐ‡ <b>${esc(record.fio)}</b> вЂ” <b>${record.orders}</b> Р·Р°РєР°Р·РѕРІ (РЅРѕРІС‹Р№ СЂРµРєРѕСЂРґ!)\n`;
  if (records[1]) text += `рџҐ€ ${esc(records[1].fio)} вЂ” ${records[1].orders} Р·Р°РєР°Р·РѕРІ\n`;
  if (records[2]) text += `рџҐ‰ ${esc(records[2].fio)} вЂ” ${records[2].orders} Р·Р°РєР°Р·РѕРІ\n`;
  text += `\nрџ”Ґ Р РµРєРѕСЂРґ СЂР°СЃС‚С‘С‚! РџСЂРѕРґРѕР»Р¶Р°Р№С‚Рµ РІ С‚РѕРј Р¶Рµ РґСѓС…Рµ!`;

  const all = getAllUserIds();
  for (const id of all) {
    if (id === String(senderId)) continue;
    const role = getUserRole(id);
    if (role === 'logist') continue;
    const wp = getUserField(id, 'workplace');
    if (wp !== workplace) continue;
    const userSettings = getNotificationSettings(id);
    if (!userSettings.workplaceRecord) continue;
    try {
      await bot.telegram.sendMessage(id, text, { parse_mode: 'HTML' });
    } catch (e) {
      console.error('workplace record notify error', id, e.message || e);
    }
  }
}

async function sendDailyLeaderNotification(workplace, dayKey, leader) {
  const settings = getNotificationSettings(leader.telegramId);
  if (!settings.dailyLeader) return;

  try {
    await bot.telegram.sendMessage(leader.telegramId,
      `рџҐ‡ <b>Р’С‹ Р»РёРґРµСЂ РґРЅСЏ РІ ${esc(workplace)}!</b>\n\n` +
      `<b>${leader.orders}</b> Р·Р°РєР°Р·РѕРІ. РўР°Рє РґРµСЂР¶Р°С‚СЊ!`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('daily leader notify error', leader.telegramId, e.message || e);
  }
}

async function sendTop3ChangeNotifications(workplace, dayKey, previousTop3, currentTop3, senderId) {
  const changed = JSON.stringify(previousTop3.map(x => x.telegramId).sort()) !== JSON.stringify(currentTop3.map(x => x.telegramId).sort());
  if (!changed) return;

  let text = `рџ”” <b>РўРѕРї-3 ${esc(workplace)} РёР·РјРµРЅРёР»СЃСЏ!</b>\n\n`;
  if (currentTop3[0]) text += `рџҐ‡ ${esc(currentTop3[0].fio)} вЂ” ${currentTop3[0].orders}\n`;
  if (currentTop3[1]) text += `рџҐ€ ${esc(currentTop3[1].fio)} вЂ” ${currentTop3[1].orders}\n`;
  if (currentTop3[2]) text += `рџҐ‰ ${esc(currentTop3[2].fio)} вЂ” ${currentTop3[2].orders}\n`;

  const all = getAllUserIds();
  for (const id of all) {
    if (id === String(senderId)) continue;
    const role = getUserRole(id);
    if (role === 'logist') continue;
    const wp = getUserField(id, 'workplace');
    if (wp !== workplace) continue;
    const settings = getNotificationSettings(id);
    if (!settings.top3Change) continue;

    // РќР°Р№С‚Рё РїРѕР·РёС†РёСЋ РїРѕР»СѓС‡Р°С‚РµР»СЏ
    const recipientEntry = currentTop3.find(x => x.telegramId === id);
    if (recipientEntry) {
      text += `\nрџЏ… Р’С‹ РЅР° ${recipientEntry.rank || '?'} РјРµСЃС‚Рµ!`;
    } else {
      const allRecords = [];
      for (const [tid, r] of Object.entries(_getAllRecords())) {
        if (r.workplace === workplace && r.dailyOrders && r.dailyOrders[dayKey]) {
          allRecords.push({ telegramId: tid, orders: r.dailyOrders[dayKey] });
        }
      }
      allRecords.sort((a, b) => b.orders - a.orders);
      const idx = allRecords.findIndex(x => x.telegramId === id);
      if (idx >= 0) text += `\nрџ“Љ Р’С‹ РЅР° ${idx + 1} РјРµСЃС‚Рµ (${allRecords[idx].orders} Р·Р°РєР°Р·РѕРІ).`;
    }

    try {
      await bot.telegram.sendMessage(id, text, { parse_mode: 'HTML' });
    } catch (e) {
      console.error('top3 change notify error', id, e.message || e);
    }
  }
}

async function showIssuesMenu(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const deliveryUrl = process.env.ISSUE_DELIVERY_URL;
  const flowwowUrl = process.env.ISSUE_FLOWWOW_URL;
  const techsupportUrl = process.env.ISSUE_TECHSUPPORT_URL;

  const buttons = [];

  if (deliveryUrl) {
    buttons.push([Markup.button.url('рџ“¦ Р”РѕСЃС‚Р°РІРєР° вЂ” РїСЂРѕР±Р»РµРјС‹ СЃ РЅР°С€РёРјРё Р·Р°РєР°Р·Р°РјРё', deliveryUrl)]);
  }
  if (flowwowUrl) {
    buttons.push([Markup.button.url('рџЊё Flowwow вЂ” Р·Р°РєР°Р·С‹ Flowwow', flowwowUrl)]);
  }
  if (techsupportUrl) {
    buttons.push([Markup.button.url('рџ”§ РўРµС…РїРѕРґРґРµСЂР¶РєР° вЂ” С‚РµС…РЅРёС‡РµСЃРєРёРµ РїСЂРѕР±Р»РµРјС‹', techsupportUrl)]);
  }

  if (buttons.length === 0) {
    await ctx.replyWithHTML('вљ пёЏ Р Р°Р·РґРµР» В«РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРјВ» РІСЂРµРјРµРЅРЅРѕ РЅРµРґРѕСЃС‚СѓРїРµРЅ.', getMenuForRole(ctx.from.id));
    return;
  }

  buttons.push([Markup.button.callback('в¬…пёЏ РќР°Р·Р°Рґ', 'issues_back')]);

  await ctx.replyWithHTML(
    'вљ пёЏ <b>РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј</b>\n\nР’С‹Р±РµСЂРёС‚Рµ С‡Р°С‚ РґР»СЏ РѕР±СЂР°С‰РµРЅРёСЏ:',
    Markup.inlineKeyboard(buttons)
  );
}

bot.start(async (ctx) => {
  console.log('/start');

  if (!getUserField(ctx.from.id, 'fio')) {
    setUserField(ctx.from.id, 'version', getVersion());
    const isNew = markUserSeen(ctx.from.id);
    if (isNew) {
      const firstName = ctx.from.first_name || '';
      const lastName = ctx.from.last_name || '';
      const username = ctx.from.username ? `@${ctx.from.username}` : '';
      const displayName = [firstName, lastName].filter(Boolean).join(' ') || 'Р‘РµР· РёРјРµРЅРё';
      const adminIds = getAdminIds();
      for (const adminId of adminIds) {
        try {
          await ctx.telegram.sendMessage(adminId,
            `рџ†• <b>РќРѕРІС‹Р№ РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ</b>\n\n` +
            `рџ‘¤ ${esc(displayName)} ${esc(username)}\n` +
            `рџ†” <code>${ctx.from.id}</code>`,
            { parse_mode: 'HTML' }
          );
        } catch (e) { /* ignore */ }
      }
    }
    await ctx.replyWithHTML(`${getTimeGreeting()}! рџ‘‹ <b>РџСЂРёРІРµС‚!</b>\n\nР­С‚Рѕ Р±РѕС‚ РґР»СЏ СѓС‡С‘С‚Р° СЃРјРµРЅС‹, РІСЂРµРјРµРЅРё Рё РїСЂРѕР±РµРіР° Р°РІС‚РѕРјРѕР±РёР»СЏ.`);
    await askForFio(ctx);
    return;
  }

  setUserField(ctx.from.id, 'version', getVersion());

  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  const role = getUserRole(ctx.from.id);

  if (role === 'logist') {
    await ctx.replyWithHTML(
      `${getTimeGreeting()}, <b>${esc(getEmployeeDisplayName(profile.fio))}</b>! рџ‘‹\n\n` +
      `вЏ± <b>Р—Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ</b> вЂ” РѕС‚РјРµС‚РёС‚СЊ РЅР°С‡Р°Р»Рѕ РёР»Рё РєРѕРЅРµС† СЃРјРµРЅС‹.\n` +
      `рџ”“ <b>РћС‚РєСЂС‹С‚СЊ РРњ</b> вЂ” РѕС‚РїСЂР°РІРёС‚СЊ СѓРІРµРґРѕРјР»РµРЅРёРµ РѕР± РѕС‚РєСЂС‹С‚РёРё РјР°РіР°Р·РёРЅР° РІ РіСЂСѓРїРїСѓ.\n` +
      `рџ’і <b>РџСЂРёРЅСЏС‚СЊ РЅР°Р»РёС‡РЅС‹Рµ</b> вЂ” РїРѕСЃРјРѕС‚СЂРµС‚СЊ РєСѓСЂСЊРµСЂРѕРІ СЃ РґРѕР»РіР°РјРё Рё РѕС‚РїСЂР°РІРёС‚СЊ РЅР°РїРѕРјРёРЅР°РЅРёРµ.\n` +
      `рџ“‹ <b>РўР°Р±Р»РёС†С‹</b> вЂ” РёРЅС„РѕСЂРјР°С†РёСЏ Рѕ РїСЂРёРІСЏР·РєРµ С‚Р°Р±Р»РёС†.\n` +
      `вљ™пёЏ <b>РќР°СЃС‚СЂРѕР№РєРё</b> вЂ” РїСЂРѕС„РёР»СЊ, РјР°РіР°Р·РёРЅ, СЃРјРµРЅР° СЃРѕС‚СЂСѓРґРЅРёРєР°.`,
      logistMainMenu(ctx.from.id)
    );
  } else {
    await ctx.replyWithHTML(
      `${getTimeGreeting()}, <b>${esc(getEmployeeDisplayName(profile.fio))}</b>! рџ‘‹\n\n` +
      `вЏ± <b>Р—Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ</b> вЂ” РѕС‚РјРµС‚РёС‚СЊ РЅР°С‡Р°Р»Рѕ РёР»Рё РєРѕРЅРµС† СЃРјРµРЅС‹, Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё РІС‹Р±РёСЂР°РµС‚СЃСЏ РІСЂРµРјСЏ СЃС‚Р°СЂС‚Р° Рё РІРЅРѕСЃРёС‚СЃСЏ РІ С‚Р°Р±Р»РёС†Сѓ Р±РѕС‚РѕРј.\n` +
      `рџљ— <b>Р¤РѕС‚Рѕ РїСЂРѕР±РµРіР°</b> вЂ” РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ РѕРґРѕРјРµС‚СЂР° Рё Р±РѕС‚ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё СЃРєРёРЅРµС‚ С„РѕС‚Рѕ РІ РЅСѓР¶РЅС‹Р№ С‡Р°С‚ Рё Р·Р°РїРёС€РµС‚ РїСЂРѕР±РµРі РІ С‚Р°Р±Р»РёС†Сѓ.\n` +
      `рџ“„ <b>РћС‚РїСЂР°РІРёС‚СЊ РјР°СЂС€СЂСѓС‚РЅРёРє</b> вЂ” РїСЂРёРєСЂРµРїРёС‚СЊ РјР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚, Р±РѕС‚ РѕС‚РїСЂР°РІРёС‚ С„РѕС‚Рѕ РІ РЅСѓР¶РЅС‹Р№ С‡Р°С‚.\n` +
      `рџ“Љ <b>РћС‚РїСЂР°РІРёС‚СЊ СЃРІРµСЂРєСѓ</b> вЂ” РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ СЃРІРµСЂРєРё, Р±РѕС‚ РѕС‚РїСЂР°РІРёС‚ С„РѕС‚Рѕ РІ РЅСѓР¶РЅС‹Р№ С‡Р°С‚.\n` +
      `рџ’µ <b>РЎРґР°С‚СЊ РЅР°Р»РёС‡РЅС‹Рµ</b> вЂ” РѕС‚РјРµС‚РёС‚СЊ СЃРґР°С‡Сѓ РЅР°Р»РёС‡РЅС‹С…, С‚Р°РєР¶Рµ СѓРєР°Р¶РµС‚ СЃСѓРјРјСѓ РЅСѓР¶РЅСѓСЋ СЃРґР°С‚СЊ Рё РїРѕРґС‚РІРµСЂР¶РґРµРЅРёРµ СЃРґР°Р»/РЅРµ СЃРґР°Р».\n` +
      `вљ пёЏ <b>РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј</b> вЂ” СЃРѕРѕР±С‰РёС‚СЊ Рѕ РїСЂРѕР±Р»РµРјРµ, Р±РѕС‚ РїСЂРµРґР»Р°РіР°РµС‚ РІР°СЂРёР°РЅС‚С‹ СЃСЃС‹Р»РєР°РјРё РЅР° РЅСѓР¶РЅС‹Р№ С‡Р°С‚/Р±РѕС‚Р° РїРѕРґРґРµСЂР¶РєРё.\n` +
      `рџЏ† <b>Р РµР№С‚РёРЅРі</b> вЂ” РїРѕСЃРјРѕС‚СЂРµС‚СЊ СЂРµР№С‚РёРЅРі РєСѓСЂСЊРµСЂРѕРІ.\n` +
      `вљ™пёЏ <b>РќР°СЃС‚СЂРѕР№РєРё</b> вЂ” РїСЂРѕС„РёР»СЊ, РјР°С€РёРЅР°, РјР°РіР°Р·РёРЅ, С‚Р°РєР¶Рµ СЃРјРµРЅР° СЃРѕС‚СЂСѓРґРЅРёРєР° Рё С‚Рґ.`,
      getMenuForRole(ctx.from.id)
    );
  }
});

bot.help(sendHelp);

bot.command('car', async (ctx) => {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° РєРѕРјР°РЅРґР° РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) { await askForFio(ctx); return; }
  await askForCarNumber(ctx, fio);
});

bot.command('workplace', async (ctx) => {
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) { await askForFio(ctx); return; }
  await askForWorkplace(ctx, fio);
});

bot.command('device', async (ctx) => {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° РєРѕРјР°РЅРґР° РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) { await askForFio(ctx); return; }
  await askForDevice(ctx, fio);
});

// РџР°СЂСЃРёРј ADMIN_IDS РёР· .env. РљСЌС€РёСЂСѓРµРј СЂРµР·СѓР»СЊС‚Р°С‚ РІ _adminIdsCache, С‡С‚РѕР±С‹
// РЅРµ СЂР°Р·Р±РёСЂР°С‚СЊ СЃС‚СЂРѕРєСѓ РЅР° РєР°Р¶РґРѕРј СЃРѕРѕР±С‰РµРЅРёРё (СЂР°РЅСЊС€Рµ СЌС‚Рѕ РїСЂРѕРёСЃС…РѕРґРёР»Рѕ РІ
// 5+ РјРµСЃС‚Р°С… РєРѕРґР°).


async function notifyAdmins(html, options = {}) {
  // РЈРІРµРґРѕРјРёС‚СЊ РІСЃРµС… Р°РґРјРёРЅРѕРІ. Р—Р°Р±Р»РѕРєРёСЂРѕРІР°РЅРЅС‹Р№ Р°РґРјРёРЅ РїСЂРѕРїСѓСЃРєР°РµС‚СЃСЏ Р±РµР· С€СѓРјР°.
  for (const adminId of getAdminIds()) {
    try {
      await bot.telegram.sendMessage(adminId, html, { parse_mode: 'HTML', ...options });
    } catch (e) {
      console.error('admin notify failed', adminId, e.message);
    }
  }
}

bot.command('chatid', async (ctx) => {
  await ctx.replyWithHTML(
    `рџ“Ќ <b>Chat info</b>\n\nchat_id: <code>${ctx.chat.id}</code>\nmessage_thread_id: <code>${ctx.message.message_thread_id || 'РЅРµС‚'}</code>`
  );
});

bot.command('sheet_access', async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    return;
  }

  const args = (ctx.message.text || '').replace(/^\/sheet_access\s*/, '').trim().split(/\s+/);

  if (args.length === 1 && args[0] === '') {
    const users = getSheetAccessUsers();
    const adminIds = getAdminIds();
    let msg = 'рџ“‹ <b>Р”РѕСЃС‚СѓРї Рє РўР°Р±Р»РёС†Р°Рј</b>\n\n';
    msg += 'рџ”‘ <b>РђРґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂС‹:</b>\n';
    for (const id of adminIds) {
      msg += `   вЂў <code>${id}</code>\n`;
    }
    msg += '\nрџ‘Ґ <b>Р”РѕРїСѓС‰РµРЅРЅС‹Рµ РїРѕР»СЊР·РѕРІР°С‚РµР»Рё:</b>\n';
    if (users.length === 0) {
      msg += '   (РїСѓСЃС‚Рѕ)\n';
    } else {
      for (const id of users) {
        msg += `   вЂў <code>${id}</code>\n`;
      }
    }
    msg += '\n<b>РљРѕРјР°РЅРґС‹:</b>\n';
    msg += '<code>/sheet_access 123456789</code> вЂ” РґР°С‚СЊ РґРѕСЃС‚СѓРї\n';
    msg += '<code>/sheet_access - 123456789</code> вЂ” СѓР±СЂР°С‚СЊ РґРѕСЃС‚СѓРї';
    await ctx.replyWithHTML(msg);
    return;
  }

  if (args[0] === '-' || args[0] === 'del' || args[0] === 'remove') {
    const targetId = Number(args[1]);
    if (!Number.isFinite(targetId) || targetId <= 0) {
      await ctx.replyWithHTML('вќЊ РќРµРІРµСЂРЅС‹Р№ Telegram ID.');
      return;
    }
    const removed = removeSheetAccessUser(targetId);
    if (removed) {
      await ctx.replyWithHTML(`вњ… Р”РѕСЃС‚СѓРї Рє РўР°Р±Р»РёС†Р°Рј СѓР±СЂР°РЅ РґР»СЏ <code>${targetId}</code>`);
    } else {
      await ctx.replyWithHTML(`в„№пёЏ РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ <code>${targetId}</code> РЅРµ РёРјРµР» РґРѕСЃС‚СѓРїР°.`);
    }
    return;
  }

  const targetId = Number(args[0]);
  if (!Number.isFinite(targetId) || targetId <= 0) {
    await ctx.replyWithHTML('вќЊ РќРµРІРµСЂРЅС‹Р№ Telegram ID. РСЃРїРѕР»СЊР·СѓР№С‚Рµ: <code>/sheet_access 123456789</code>');
    return;
  }

  const added = addSheetAccessUser(targetId);
  if (added) {
    await ctx.replyWithHTML(`вњ… Р”РѕСЃС‚СѓРї Рє РўР°Р±Р»РёС†Р°Рј РїСЂРµРґРѕСЃС‚Р°РІР»РµРЅ РґР»СЏ <code>${targetId}</code>\n\nРџРѕР»СЊР·РѕРІР°С‚РµР»СЊ СѓРІРёРґРёС‚ РєРЅРѕРїРєСѓ В«рџ“‹ РўР°Р±Р»РёС†С‹В» РІ РќР°СЃС‚СЂРѕР№РєР°С….`);
  } else {
    await ctx.replyWithHTML(`в„№пёЏ РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ <code>${targetId}</code> СѓР¶Рµ РёРјРµРµС‚ РґРѕСЃС‚СѓРї.`);
  }
});

bot.command('role', async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    return;
  }

  const args = (ctx.message.text || '').replace(/^\/role\s*/, '').trim().split(/\s+/);

  if (args.length < 2) {
    await ctx.replyWithHTML(
      'рџ”‘ <b>РЎРјРµРЅР° СЂРѕР»Рё</b>\n\n' +
      'РСЃРїРѕР»СЊР·РѕРІР°РЅРёРµ: <code>/role &lt;telegram_id&gt; &lt;courier|logist&gt;</code>\n\n' +
      'РџСЂРёРјРµСЂС‹:\n' +
      '<code>/role 123456789 courier</code> вЂ” СЃРґРµР»Р°С‚СЊ РєСѓСЂСЊРµСЂРѕРј\n' +
      '<code>/role 123456789 logist</code> вЂ” СЃРґРµР»Р°С‚СЊ Р»РѕРіРёСЃС‚РѕРј'
    );
    return;
  }

  const targetId = args[0];
  const newRole = args[1].toLowerCase();

  if (newRole !== 'courier' && newRole !== 'logist') {
    await ctx.replyWithHTML('вќЊ Р РѕР»СЊ РґРѕР»Р¶РЅР° Р±С‹С‚СЊ <code>courier</code> РёР»Рё <code>logist</code>.');
    return;
  }

  const currentFio = getUserField(targetId, 'fio');
  if (!currentFio) {
    await ctx.replyWithHTML(`вќЊ РџРѕР»СЊР·РѕРІР°С‚РµР»СЊ <code>${targetId}</code> РЅРµ РЅР°Р№РґРµРЅ.`);
    return;
  }

  const oldRole = getUserRole(targetId);
  const displayRole = newRole === 'logist' ? 'Р›РѕРіРёСЃС‚' : 'РљСѓСЂСЊРµСЂ';
  const oldDisplayRole = oldRole === 'logist' ? 'Р›РѕРіРёСЃС‚' : 'РљСѓСЂСЊРµСЂ';

  setUserField(targetId, 'role', newRole);

  if (newRole === 'logist') {
    const carNumber = getUserField(targetId, 'carNumber');
    const device = getUserField(targetId, 'device');
    if (carNumber) setUserField(targetId, 'carNumber', null);
    if (device) setUserField(targetId, 'device', null);
  }

  await ctx.replyWithHTML(
    `вњ… Р РѕР»СЊ РёР·РјРµРЅРµРЅР°: <b>${esc(currentFio)}</b> (<code>${targetId}</code>)\n\n` +
    `${oldDisplayRole} в†’ ${displayRole}`
  );
});

function formatNoSheetMessage(result, workplace) {
  if (result?.noSheetForMonth && result?.monthKey) {
    return `вќЊ Р”Р»СЏ РјР°РіР°Р·РёРЅР° <b>${esc(workplace)}</b> РЅРµ РїСЂРёРІСЏР·Р°РЅР° С‚Р°Р±Р»РёС†Р° РЅР° РјРµСЃСЏС† <code>${esc(result.monthKey)}</code>.\nРћР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.`;
  }

  if (result?.noSheet) {
    return 'вќЊ РўР°Р±Р»РёС†Р° РЅРµ РїСЂРёРІСЏР·Р°РЅР° РґР»СЏ РІР°С€РµРіРѕ РјР°РіР°Р·РёРЅР°.\nРћР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.';
  }

  return 'вќЊ РќРµ СѓРґР°Р»РѕСЃСЊ РЅР°Р№С‚Рё СЃРѕС‚СЂСѓРґРЅРёРєР° РІ С‚Р°Р±Р»РёС†Рµ.';
}

const ocrFeedbackPath = path.join(__dirname, 'ocr_feedback.json');
const MAX_OCR_FEEDBACK = LIMITS.MAX_OCR_FEEDBACK;

function logOcrFeedback(telegramId, ocrMileage, confirmedMileage, sourceBuffer, meta = {}) {
  if (!Number.isFinite(confirmedMileage) || confirmedMileage <= 0) return;

  const isMismatch = ocrMileage !== confirmedMileage;

  if (isMismatch) {
    try {
      let feedback = [];
      try {
        if (fs.existsSync(ocrFeedbackPath)) {
          feedback = JSON.parse(fs.readFileSync(ocrFeedbackPath, 'utf8'));
        }
      } catch (e) { /* ignore */ }

      feedback.push({
        ocr: ocrMileage,
        confirmed: confirmedMileage,
        diff: confirmedMileage - (ocrMileage || 0),
        date: new Date().toISOString(),
        userId: telegramId
      });

      if (feedback.length > MAX_OCR_FEEDBACK) {
        feedback = feedback.slice(-MAX_OCR_FEEDBACK);
      }

      fs.writeFileSync(ocrFeedbackPath, JSON.stringify(feedback, null, 2), 'utf8');
    } catch (error) {
      console.error('OCR feedback log error', error.message);
    }

    if (sourceBuffer) {
      saveOcrDebugImage(sourceBuffer, {
        status: 'ocr_mismatch',
        ocrResult: ocrMileage,
        userCorrectedValue: confirmedMileage,
        telegramId,
        stage: meta.stage || null,
        workplace: meta.workplace || null,
        fio: meta.fio || null,
        fileId: meta.fileId || null
      });
    }
  } else if (ocrMileage === confirmedMileage && ocrMileage !== null) {
    updateOcrDebugStatus(meta.fileId, 'confirmed_ok');
  }
}

function parseMileageNumber(value) {
  const text = String(value || '').replace(/\D/g, '');
  if (!text) return null;

  const number = Number(text);
  if (!Number.isInteger(number)) return null;
  if (text.length < 2 || text.length > 6) return null;

  return number;
}

function getMaxShiftMileageDelta() {
  const value = Number(process.env.OCR_MAX_SHIFT_DELTA || 800);
  if (!Number.isFinite(value) || value < 0) return 800;
  return value;
}

async function buildMileageRecognitionOptions(state) {
  const options = {
    minMileage: getMinMileageThreshold(),
    maxMileage: null,
    stage: state?.stage || null
  };

  if (state?.stage === 'end') {
    try {
      const startCell = getMileageStageCell(state, 'start');
      if (startCell) {
        const sheetContext = resolveSheetInfo(startCell.workplace);
        if (sheetContext.sheetId) {
          const startRaw = await readCell(startCell.sheetName, startCell.cell, sheetContext.sheetId);
          const startMileage = parseMileageNumber(startRaw);
          if (startMileage) {
            options.maxMileage = startMileage + getMaxShiftMileageDelta();
            options.startMileage = startMileage;
            options.minMileage = Math.max(options.minMileage, startMileage);
          }
        }
      }
    } catch (error) {
      console.error('mileage recognition options error (stage=end)', error.message || error);
    }
  } else if (state?.stage === 'start') {
    try {
      const endCell = getMileageStageCell(state, 'end');
      if (endCell) {
        const sheetContext = resolveSheetInfo(endCell.workplace);
        if (sheetContext.sheetId) {
          const endRaw = await readCell(endCell.sheetName, endCell.cell, sheetContext.sheetId);
          const prevEndMileage = parseMileageNumber(endRaw);
          if (prevEndMileage) {
            const prevMinMileage = Math.max(prevEndMileage - getMaxShiftMileageDelta(), getMinMileageThreshold());
            options.minMileage = prevMinMileage;
            options.prevEndMileage = prevEndMileage;
          }
        }
      }
    } catch (error) {
      console.error('mileage recognition options error (stage=start)', error.message || error);
    }
  }

  return options;
}

function getMileageColumnsForState(workplace, day) {
  const base = getMileageColumnsByDay(day);
  const offset = getSheetConfig(workplace)?.mileageDayOffset || 0;

  return {
    startColumn: base.startColumn + offset,
    endColumn: base.endColumn + offset,
    totalColumn: base.totalColumn + offset
  };
}

function getMileageStageCell(state, stage = state?.stage) {
  if (!state?.mileageRow || !state?.day) return null;

  const workplace = state.workplace || getUserField(state.telegramId, 'workplace');
  if (!workplace) return null;

  const config = getSheetConfig(workplace);
  const columns = getMileageColumnsForState(workplace, state.day);
  const column = stage === 'start' ? columns.startColumn : columns.endColumn;

  return {
    workplace,
    sheetName: config.mileageSheet,
    cell: `${getColumnLetter(column)}${state.mileageRow}`
  };
}

registerSheetCommand(bot, { esc, workplaces: WORKPLACES, isAdminUser });

bot.command('cancel', async (ctx) => {
  await backToMainMenu(ctx);
});

bot.action('back_to_menu', async (ctx) => {
  await ctx.answerCbQuery();
  await backToMainMenu(ctx);
});

bot.action('show_my_id', async (ctx) => {
  await ctx.answerCbQuery();
  const userId = ctx.from.id;
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  const username = ctx.from.username ? `@${ctx.from.username}` : '';
  const displayName = [firstName, lastName].filter(Boolean).join(' ') || 'Р‘РµР· РёРјРµРЅРё';

  await ctx.replyWithHTML(
    `рџ†” <b>Р’Р°С€ Telegram ID:</b> <code>${userId}</code>\n\n` +
    'РћС‚РїСЂР°РІСЊС‚Рµ СЌС‚РѕС‚ ID Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ РґР»СЏ РїРѕР»СѓС‡РµРЅРёСЏ РґРѕСЃС‚СѓРїР°.'
  );

  // РџР°СЂР°Р»Р»РµР»СЊРЅРѕ СѓРІРµРґРѕРјР»СЏРµРј Р°РґРјРёРЅРѕРІ
  for (const adminId of getAdminIds()) {
    try {
      await ctx.telegram.sendMessage(adminId,
        `рџ†” <b>Р—Р°РїСЂРѕСЃ РґРѕСЃС‚СѓРїР° Рє РўР°Р±Р»РёС†Р°Рј</b>\n\n` +
        `рџ‘¤ ${esc(displayName)} ${esc(username)}\n` +
        `рџ†” <code>${userId}</code>\n\n` +
        `Р”Р°С‚СЊ РґРѕСЃС‚СѓРї: <code>/sheet_access ${userId}</code>`,
        { parse_mode: 'HTML' }
      );
    } catch (e) { /* Р°РґРјРёРЅ Р·Р°Р±Р»РѕРєРёСЂРѕРІР°РЅ вЂ” РїСЂРѕРїСѓСЃРєР°РµРј */ }
  }
});

bot.action('issues_back', async (ctx) => {
  await ctx.answerCbQuery();
  try {
    await ctx.deleteMessage();
  } catch (e) { /* СЃРѕРѕР±С‰РµРЅРёРµ СѓР¶Рµ СѓРґР°Р»РµРЅРѕ */ }
  await backToMainMenu(ctx);
});

const _workplaceKeys = Object.values(WORKPLACE_KEY_MAP).concat(['all']).join('|');

bot.action('lb_table', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardFilter(ctx);
});

bot.action('lb_challenges', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showWeeklyChallenges(ctx);
});

bot.action('lb_achievements', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showMyAchievements(ctx);
});

bot.action('lb_progress', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showMyProgress(ctx);
});

bot.action('lb_xp_info', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showXpInfo(ctx);
});

bot.action('lb_back_menu', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMenu(ctx);
});

bot.action('lb_notifications', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showNotificationSettings(ctx);
});

const NOTIFICATION_KEYS = ['personalRecord', 'overtake', 'workplaceRecord', 'dailyLeader', 'top3Change'];
for (const key of NOTIFICATION_KEYS) {
  bot.action(`notif_${key}`, async (ctx) => {
    await ctx.answerCbQuery();
    const telegramId = ctx.from.id;
    const current = getNotificationSettings(telegramId);
    current[key] = !current[key];
    setUserField(telegramId, 'notificationSettings', JSON.stringify(current));
    try { await ctx.deleteMessage(); } catch {}
    await showNotificationSettings(ctx);
  });
}

bot.action('lb_filter_auto', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, 'auto');
});

bot.action('lb_filter_pedestrian', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, 'pedestrian');
});

bot.action('lb_filter_all', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, 'all');
});

bot.action(new RegExp(`^lb_wp_(${_workplaceKeys})$`), async (ctx) => {
  await ctx.answerCbQuery();
  const workplace = ctx.match[1];
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardPeriod(ctx, filter, workplace);
});

bot.action('lb_wp_all', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardPeriod(ctx, filter, 'all');
});

bot.action(/^lb_p_(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery();
  const days = Number(ctx.match[1]);
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMode(ctx, filter, workplace, days);
});

bot.action('lb_mode_sum', async (ctx) => {
  await ctx.answerCbQuery();
  setState(ctx.from.id, { ...getState(ctx.from.id), lb_mode: 'sum' });
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardResultV2(ctx);
});

bot.action('lb_mode_max', async (ctx) => {
  await ctx.answerCbQuery();
  setState(ctx.from.id, { ...getState(ctx.from.id), lb_mode: 'max' });
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardResultV2(ctx);
});

bot.action('lb_back_filter', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMenu(ctx);
});

bot.action('lb_back_workplace', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, filter);
});

bot.action('lb_back_period', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardPeriod(ctx, filter, workplace);
});

bot.action('lb_back_mode', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  const periodDays = state?.lb_period ?? 0;
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMode(ctx, filter, workplace, periodDays);
});

bot.action('route_sheet_done', async (ctx) => {
  await ctx.answerCbQuery('Р“РѕС‚РѕРІРѕ');
  const state = getState(ctx.from.id);
  // РћС‚С‡С‘С‚РѕРј Р·Р°РІРµСЂС€РµРЅРёСЏ РјРѕР¶РµС‚ Р±С‹С‚СЊ Рё В«РјР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚В», Рё В«СЃРІРµСЂРєРёВ»
  // (РѕР±Рµ РёСЃРїРѕР»СЊР·СѓСЋС‚ routeSheetKeyboard). РЎРѕРѕР±С‰РµРЅРёРµ РЅРµР№С‚СЂР°Р»СЊРЅРѕ вЂ” РїСЂРѕСЃС‚Рѕ
  // С„РёРЅР°Р»РёР·РёСЂСѓРµРј Рё РІРѕР·РІСЂР°С‰Р°РµРј РІ РјРµРЅСЋ.
  clearState(ctx.from.id);
  if (state?.awaitingReconciliationPhoto) {
    const sent = state.reconciliationPhotosSent || 0;
    await ctx.replyWithHTML(
      sent > 0
        ? `вњ… Р—Р°РІРµСЂС€РµРЅРѕ. РћС‚РїСЂР°РІР»РµРЅРѕ С„РѕС‚Рѕ: <b>${sent}</b>.`
        : 'вњ… Р—Р°РІРµСЂС€РµРЅРѕ. Р¤РѕС‚Рѕ РЅРµ РѕС‚РїСЂР°РІР»РµРЅС‹.',
      courierMainMenu(ctx.from.id)
    );
    return;
  }
  // РњР°СЂС€СЂСѓС‚РЅРёРє Р·Р°РІРµСЂС€С‘РЅ вЂ” РЅР°С‡РёСЃР»СЏРµРј XP
  addXp(ctx.from.id, getXpForAction('routeSheet'), 'РњР°СЂС€СЂСѓС‚РЅРёРє');
  updateChallengeProgress(ctx.from.id, 'routeSheets');
  await ctx.replyWithHTML('вњ… Р—Р°РІРµСЂС€РµРЅРѕ. РЎРїР°СЃРёР±Рѕ.', courierMainMenu(ctx.from.id));
});

bot.action('help_commands', async (ctx) => {
  await ctx.answerCbQuery();
  await sendCommandsList(ctx);
});

bot.action('confirm_switch_user', async (ctx) => {
  await ctx.answerCbQuery();
  deleteUser(ctx.from.id);
  setState(ctx.from.id, { awaitingFio: true });
  await ctx.replyWithHTML('рџ‘¤ <b>РЎРјРµРЅР° СЃРѕС‚СЂСѓРґРЅРёРєР°</b>\n\nРџСЂРµРґС‹РґСѓС‰РёРµ РґР°РЅРЅС‹Рµ СѓРґР°Р»РµРЅС‹.\nР’РІРµРґРёС‚Рµ РёРјСЏ Рё С„Р°РјРёР»РёСЋ РєР°Рє РІ С‚Р°Р±Р»РёС†Рµ.');
});

bot.action('role_courier', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const state = getState(telegramId);
  if (!state?.awaitingRoleChoice) {
    await ctx.replyWithHTML('вљ пёЏ Р’С‹Р±РѕСЂ СЂРѕР»Рё СѓСЃС‚Р°СЂРµР». РќР°Р¶РјРёС‚Рµ /start.', getMenuForRole(telegramId));
    return;
  }
  setUserField(telegramId, 'role', 'courier');
  setUserField(telegramId, 'courierType', 'auto');
  if (state?.workplace) {
    setUserField(telegramId, 'workplace', state.workplace);
  }
  clearState(telegramId);
  await ctx.replyWithHTML('вњ… Р РѕР»СЊ: <b>РљСѓСЂСЊРµСЂ</b> (Р°РІС‚Рѕ).\n\nРўРµРїРµСЂСЊ РІРІРµРґРёС‚Рµ РЅРѕРјРµСЂ РјР°С€РёРЅС‹.');
  await askForCarNumber(ctx, state.fio);
});

bot.action('role_logist', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const state = getState(telegramId);
  if (!state?.awaitingRoleChoice) {
    await ctx.replyWithHTML('вљ пёЏ Р’С‹Р±РѕСЂ СЂРѕР»Рё СѓСЃС‚Р°СЂРµР». РќР°Р¶РјРёС‚Рµ /start.', getMenuForRole(telegramId));
    return;
  }
  setUserField(telegramId, 'role', 'logist');
  clearState(telegramId);
  await ctx.replyWithHTML('вњ… Р РѕР»СЊ: <b>Р›РѕРіРёСЃС‚</b>\n\nРўРµРїРµСЂСЊ РІС‹Р±РµСЂРёС‚Рµ РІР°С€ РјР°РіР°Р·РёРЅ.', logistMainMenu(ctx.from.id));
  await askForWorkplace(ctx, state.fio);
});

bot.action('cash_submit_yes', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const pendingCash = getPendingCash(telegramId);
  const amount = Number(pendingCash?.amount || 0);

  if (!Number.isFinite(amount) || amount < 1) {
    await ctx.replyWithHTML('вњ… Р”РѕР»РіРѕРІ РЅРµС‚ вЂ” РІСЃРµ РґРµРЅСЊРіРё СЃРґР°РЅС‹.', getMenuForRole(telegramId));
    return;
  }

  const formatted = pendingCash?.formatted || formatMoneyRu(amount);
  const courierFio = getUserField(telegramId, 'fio') || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№';
  const workplace = pendingCash?.workplace || getUserField(telegramId, 'workplace') || 'РЅРµ СѓРєР°Р·Р°РЅРѕ';

  const wpFeatures = WORKPLACE_FEATURES[workplace];
  if (!wpFeatures || !wpFeatures.cashCollection) {
    clearPendingCashAndReminders(telegramId);
    logCashAction({
      logistId: null,
      logistFio: null,
      courierId: String(telegramId),
      courierFio: courierFio,
      workplace: workplace,
      amount: amount,
      action: 'self_cleared'
    });
    addXp(telegramId, getXpForAction('cashSubmit'), 'РЎРґР°С‡Р° РЅР°Р»РёС‡РЅС‹С…');
    updateChallengeProgress(telegramId, 'cashSubmits');
    try {
      await ctx.editMessageText(`вњ… <b>${esc(courierFio)}</b>, СЃРґР°С‡Р° <code>${esc(formatted)}</code> в‚Ѕ РїРѕРґС‚РІРµСЂР¶РґРµРЅР°.`);
    } catch (e) { /* ignore */ }
    await ctx.replyWithHTML(
      `вњ… <b>РЎРґР°С‡Р° РїРѕРґС‚РІРµСЂР¶РґРµРЅР°</b>\n\n` +
      `Р’С‹ СЃРґР°Р»Рё <code>${esc(formatted)}</code> в‚Ѕ.\n` +
      `РЎРїР°СЃРёР±Рѕ!`,
      getMenuForRole(telegramId)
    );
    return;
  }

  setCashConfirmationStatus(telegramId, 'awaiting');

  logCashAction({
    logistId: null,
    logistFio: null,
    courierId: String(telegramId),
    courierFio: courierFio,
    workplace: workplace,
    amount: amount,
    action: 'self_cleared_requested'
  });

  await notifyLogistsAboutSelfClearance(telegramId, courierFio, amount, formatted, workplace);

  try {
    await ctx.editMessageText('вЏі Р—Р°РїСЂРѕСЃ РѕС‚РїСЂР°РІР»РµРЅ. РћР¶РёРґР°Р№С‚Рµ РїРѕРґС‚РІРµСЂР¶РґРµРЅРёСЏ Р»РѕРіРёСЃС‚Р°.');
  } catch (e) { /* ignore */ }

  await ctx.replyWithHTML(
    `вЏі <b>Р—Р°РїСЂРѕСЃ РѕС‚РїСЂР°РІР»РµРЅ</b>\n\n` +
    `Р’С‹ РѕС‚РјРµС‚РёР»Рё СЃРґР°С‡Сѓ <code>${esc(formatted)}</code> в‚Ѕ.\n` +
    `РћР¶РёРґР°Р№С‚Рµ РїРѕРґС‚РІРµСЂР¶РґРµРЅРёСЏ РѕС‚ Р»РѕРіРёСЃС‚Р°.`,
    getMenuForRole(telegramId)
  );
});

bot.action('cash_submit_no', async (ctx) => {
  await ctx.answerCbQuery('вќЊ РћС‚Р»РѕР¶РµРЅРѕ');
  const fun = String(process.env.FUN_TONE || '').toLowerCase() === 'true';
  const message = fun
    ? 'рџј РўРѕРіРґР° Р±РµРіРѕРј СЃРґР°РІР°С‚СЊ РґРµРЅСЊРіРё! РљРѕС‚РѕРєРѕРЅС‚СЂРѕР»СЊ РЅРµ РґСЂРµРјР»РµС‚ рџђѕ\n\nРљРѕРіРґР° СЃРґР°РґРёС‚Рµ вЂ” РЅР°Р¶РјРёС‚Рµ В«рџ’µ Р”РµРЅСЊРіРё Рє СЃРґР°С‡РµВ» Рё РїРѕРґС‚РІРµСЂРґРёС‚Рµ.'
    : 'вљ пёЏ РќРµ Р·Р°Р±СѓРґСЊС‚Рµ СЃРґР°С‚СЊ РґРµРЅСЊРіРё.\n\nРљРѕРіРґР° СЃРґР°РґРёС‚Рµ вЂ” РЅР°Р¶РјРёС‚Рµ В«рџ’µ Р”РµРЅСЊРіРё Рє СЃРґР°С‡РµВ» Рё РїРѕРґС‚РІРµСЂРґРёС‚Рµ.';
  await ctx.replyWithHTML(message, getMenuForRole(ctx.from.id));
});

bot.action(/^d_(\d+)$/, async (ctx) => {
  const courierId = ctx.match[1];
  await pokeCourier(ctx, courierId);
});

bot.action(/^ack_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('вљ пёЏ РќР°РїРѕРјРёРЅР°РЅРёРµ СѓСЃС‚Р°СЂРµР»Рѕ РёР»Рё СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅРѕ.'); } catch (e) { /* ignore */ }
    return;
  }

  if (reminder.status !== 'reminded' && reminder.status !== 'acknowledged') {
    try { await ctx.editMessageText('вљ пёЏ РќР°РїРѕРјРёРЅР°РЅРёРµ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅРѕ.'); } catch (e) { /* ignore */ }
    return;
  }

  updateReminder(shortId, { status: 'acknowledged' });

  const courierFio = reminder.courierFio;
  const formatted = reminder.formatted;
  const logistId = reminder.logistId;

  logCashAction({
    logistId: logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'acknowledged'
  });

  try {
    await ctx.editMessageText(
      `вњ… РћС‚РјРµС‚РєР° РїРѕР»СѓС‡РµРЅР°. РљРѕРіРґР° СЃРґР°РґРёС‚Рµ вЂ” РЅР°Р¶РјРёС‚Рµ В«РЎРґР°Р»В».\n\n` +
      `рџ’¶ Рљ СЃРґР°С‡Рµ: <code>${esc(formatted)}</code> в‚Ѕ`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('вњ… РЎРґР°Р»', `c_${shortId}`)]
          ]
        }
      }
    );
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(logistId,
      `рџЏѓ <b>${esc(courierFio)}</b> СѓР¶Рµ Р±РµР¶РёС‚ СЃРґР°РІР°С‚СЊ <code>${esc(formatted)}</code> в‚Ѕ`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify logist about acknowledgement', e.message);
  }
});

bot.action(/^c_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('вљ пёЏ РќР°РїРѕРјРёРЅР°РЅРёРµ СѓСЃС‚Р°СЂРµР»Рѕ РёР»Рё СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅРѕ.'); } catch (e) { /* ignore */ }
    return;
  }

  if (reminder.status === 'approved' || reminder.status === 'declined') {
    try { await ctx.editMessageText('вњ… РќР°Р»РёС‡РЅС‹Рµ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅС‹.'); } catch (e) { /* ignore */ }
    return;
  }

  updateReminder(shortId, { status: 'confirmed' });

  logCashAction({
    logistId: reminder.logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: reminder.courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'confirmed'
  });

  try {
    await ctx.editMessageText('вЏі Р›РѕРіРёСЃС‚ РїСЂРѕРІРµСЂСЏРµС‚...', { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    const sent = await bot.telegram.sendMessage(reminder.logistId,
      `вњ… <b>${esc(reminder.courierFio)}</b> СЃРґР°Р» <code>${esc(reminder.formatted)}</code> в‚Ѕ\n\nРџРѕРґС‚РІРµСЂРґРёС‚Рµ СЃРґР°С‡Сѓ:`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('вњ… РџРѕРґС‚РІРµСЂРґРёС‚СЊ', `appr_${shortId}`)],
            [Markup.button.callback('вќЊ РћС‚РєР»РѕРЅРёС‚СЊ', `decl_${shortId}`)]
          ]
        }
      }
    );
    updateReminder(shortId, { logistMsgId: sent.message_id });
  } catch (e) {
    console.error('failed to notify logist about confirmation', e.message);
  }
});

bot.action(/^appr_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('вљ пёЏ РќР°РїРѕРјРёРЅР°РЅРёРµ СѓСЃС‚Р°СЂРµР»Рѕ.'); } catch (e) { /* ignore */ }
    return;
  }

  clearPendingCashAndReminders(reminder.courierId);

  logCashAction({
    logistId: reminder.logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: reminder.courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'approved'
  });

  addXp(reminder.courierId, getXpForAction('cashSubmit'), 'РЎРґР°С‡Р° РЅР°Р»РёС‡РЅС‹С… (РїРѕРґС‚РІРµСЂР¶РґРµРЅРѕ)');
  updateChallengeProgress(reminder.courierId, 'cashSubmits');

  deleteReminder(shortId);

  try {
    await ctx.editMessageText(`вњ… РџРѕРґС‚РІРµСЂР¶РґРµРЅРѕ: <b>${esc(reminder.courierFio)}</b> СЃРґР°Р» <code>${esc(reminder.formatted)}</code> в‚Ѕ`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(reminder.courierId,
      `вњ… <b>${esc(reminder.logistFio)}</b> РїРѕРґС‚РІРµСЂРґРёР» СЃРґР°С‡Сѓ <code>${esc(reminder.formatted)}</code> в‚Ѕ\n\nРЎРїР°СЃРёР±Рѕ!`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify courier about approval', e.message);
  }

  await sendFunReaction(ctx, 'success');
});

bot.action(/^decl_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('вљ пёЏ РќР°РїРѕРјРёРЅР°РЅРёРµ СѓСЃС‚Р°СЂРµР»Рѕ.'); } catch (e) { /* ignore */ }
    return;
  }

  logCashAction({
    logistId: reminder.logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: reminder.courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'declined'
  });

  updateReminder(shortId, { status: 'declined' });

  try {
    await ctx.editMessageText(`вќЊ РћС‚РєР»РѕРЅРµРЅРѕ: <b>${esc(reminder.courierFio)}</b>`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(reminder.courierId,
      `вќЊ <b>${esc(reminder.logistFio)}</b> РѕС‚РєР»РѕРЅРёР» СЃРґР°С‡Сѓ.\n\nРџСЂРѕРІРµСЂСЊС‚Рµ СЃСѓРјРјСѓ Рё РЅР°Р¶РјРёС‚Рµ В«РЎРґР°Р»В» СЃРЅРѕРІР°.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('вњ… РЎРґР°Р»', `c_${shortId}`)]
          ]
        }
      }
    );
  } catch (e) {
    console.error('failed to notify courier about decline', e.message);
  }
});

bot.action(/^sc_appr_(\d+)$/, async (ctx) => {
  const courierId = ctx.match[1];
  await ctx.answerCbQuery('вњ… РЎРґР°С‡Р° РїРѕРґС‚РІРµСЂР¶РґРµРЅР°');

  const pendingCash = getPendingCash(courierId);
  if (!pendingCash || pendingCash.confirmationStatus !== 'awaiting') {
    try { await ctx.editMessageText('вњ… РЈР¶Рµ РїРѕРґС‚РІРµСЂР¶РґРµРЅРѕ РґСЂСѓРіРёРј Р»РѕРіРёСЃС‚РѕРј.'); } catch (e) { /* ignore */ }
    return;
  }

  const approverId = String(ctx.from.id);

  if (approverId === courierId) {
    await ctx.answerCbQuery('в›” Р’С‹ РЅРµ РјРѕР¶РµС‚Рµ РїРѕРґС‚РІРµСЂРґРёС‚СЊ СЃРІРѕСЋ СЃРґР°С‡Сѓ.');
    return;
  }
  if (getUserRole(approverId) !== 'logist') {
    await ctx.answerCbQuery('в›” РўРѕР»СЊРєРѕ Р»РѕРіРёСЃС‚ РјРѕР¶РµС‚ РїРѕРґС‚РІРµСЂР¶РґР°С‚СЊ СЃРґР°С‡Сѓ.');
    return;
  }
  const approverWorkplace = getUserField(approverId, 'workplace');
  const cashWorkplace = pendingCash.workplace || getUserField(courierId, 'workplace') || '';
  if (approverWorkplace !== cashWorkplace) {
    await ctx.answerCbQuery('в›” Р’С‹ РЅРµ РїСЂРёРІСЏР·Р°РЅС‹ Рє СЌС‚РѕРјСѓ РјР°РіР°Р·РёРЅСѓ.');
    return;
  }

  const courierFio = getUserField(courierId, 'fio') || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№';
  const amount = Number(pendingCash.amount || 0);
  const formatted = pendingCash.formatted || formatMoneyRu(amount);
  const workplace = pendingCash.workplace || getUserField(courierId, 'workplace') || 'РЅРµ СѓРєР°Р·Р°РЅРѕ';
  const logistId = approverId;
  const logistFio = getUserField(logistId, 'fio') || 'Р›РѕРіРёСЃС‚';

  clearPendingCashAndReminders(courierId);

  addXp(courierId, getXpForAction('cashSubmit'), 'РЎРґР°С‡Р° РЅР°Р»РёС‡РЅС‹С… (self-clearance)');
  updateChallengeProgress(courierId, 'cashSubmits');

  logCashAction({
    logistId: logistId,
    logistFio: logistFio,
    courierId: courierId,
    courierFio: courierFio,
    workplace: workplace,
    amount: amount,
    action: 'logist_approved'
  });

  try {
    await ctx.editMessageText(`вњ… РџРѕРґС‚РІРµСЂР¶РґРµРЅРѕ: <b>${esc(courierFio)}</b> СЃРґР°Р» <code>${esc(formatted)}</code> в‚Ѕ`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(courierId,
      `вњ… <b>${esc(logistFio)}</b> РїРѕРґС‚РІРµСЂРґРёР» СЃРґР°С‡Сѓ <code>${esc(formatted)}</code> в‚Ѕ\n\nРЎРїР°СЃРёР±Рѕ!`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify courier about sc approval', e.message);
  }
});

bot.action(/^sc_decl_(\d+)$/, async (ctx) => {
  const courierId = ctx.match[1];
  await ctx.answerCbQuery('вќЊ РЎРґР°С‡Р° РѕС‚РєР»РѕРЅРµРЅР°');

  const pendingCash = getPendingCash(courierId);
  if (!pendingCash || pendingCash.confirmationStatus !== 'awaiting') {
    try { await ctx.editMessageText('вљ пёЏ Р—Р°РїСЂРѕСЃ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅ.'); } catch (e) { /* ignore */ }
    return;
  }

  const declinerId = String(ctx.from.id);

  if (declinerId === courierId) {
    await ctx.answerCbQuery('в›” Р’С‹ РЅРµ РјРѕР¶РµС‚Рµ РѕС‚РєР»РѕРЅРёС‚СЊ СЃРІРѕСЋ СЃРґР°С‡Сѓ.');
    return;
  }
  if (getUserRole(declinerId) !== 'logist') {
    await ctx.answerCbQuery('в›” РўРѕР»СЊРєРѕ Р»РѕРіРёСЃС‚ РјРѕР¶РµС‚ РѕС‚РєР»РѕРЅСЏС‚СЊ СЃРґР°С‡Сѓ.');
    return;
  }
  const declinerWorkplace = getUserField(declinerId, 'workplace');
  if (declinerWorkplace !== (pendingCash.workplace || '')) {
    await ctx.answerCbQuery('в›” Р’С‹ РЅРµ РїСЂРёРІСЏР·Р°РЅС‹ Рє СЌС‚РѕРјСѓ РјР°РіР°Р·РёРЅСѓ.');
    return;
  }

  setCashConfirmationStatus(courierId, null);

  const courierFio = getUserField(courierId, 'fio') || 'РќРµРёР·РІРµСЃС‚РЅС‹Р№';
  const logistId = declinerId;
  const logistFio = getUserField(logistId, 'fio') || 'Р›РѕРіРёСЃС‚';

  logCashAction({
    logistId: logistId,
    logistFio: logistFio,
    courierId: courierId,
    courierFio: courierFio,
    workplace: pendingCash.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ',
    amount: Number(pendingCash.amount || 0),
    action: 'declined'
  });

  try {
    await ctx.editMessageText(`вќЊ РћС‚РєР»РѕРЅРµРЅРѕ: <b>${esc(courierFio)}</b>`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(courierId,
      `вќЊ <b>${esc(logistFio)}</b> РѕС‚РєР»РѕРЅРёР» СЃРґР°С‡Сѓ.\n\nРџСЂРѕРІРµСЂСЊС‚Рµ СЃСѓРјРјСѓ Рё РїРѕРїСЂРѕР±СѓР№С‚Рµ СЃРЅРѕРІР°.`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify courier about sc decline', e.message);
  }
});

bot.action(/^ch_(\d{4}-\d{2}-\d{2})$/, async (ctx) => {
  const dateStr = ctx.match[1];
  await ctx.answerCbQuery();
  await showCashHistoryForDate(ctx, dateStr);
});

bot.action('edit_time', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);

  if (!state?.awaitingTimeChange || !state?.courierRow || !state?.day || !state?.stage) {
    await ctx.replyWithHTML(`вљ пёЏ РЎРЅР°С‡Р°Р»Р° РЅР°Р¶РјРёС‚Рµ В«${BUTTONS.punchTime}В».`, getMenuForRole(ctx.from.id));
    return;
  }

  setState(ctx.from.id, {
    ...state,
    awaitingTimeChange: false,
    awaitingManualTime: true
  });

  await ctx.replyWithHTML(
    `вњЏпёЏ <b>РР·РјРµРЅРµРЅРёРµ РІСЂРµРјРµРЅРё</b>\n\n` +
    `Р­С‚Р°Рї: <b>${esc(formatStage(state.stage))}</b>\n\n` +
    `Р’РІРµРґРёС‚Рµ РІСЂРµРјСЏ РІ Р»СЋР±РѕРј С„РѕСЂРјР°С‚Рµ:\n` +
    `вЂў С†РµР»РѕРµ С‡РёСЃР»Рѕ вЂ” <code>7</code>\n` +
    `вЂў СЃ РїРѕР»РѕРІРёРЅРѕР№ вЂ” <code>7,5</code> РёР»Рё <code>7.5</code>\n` +
    `вЂў С‡Р°СЃС‹:РјРёРЅСѓС‚С‹ вЂ” <code>07:30</code>, <code>07:44</code>, <code>08.46</code>, <code>8 14</code>\n\n` +
    `РњРёРЅСѓС‚С‹ РѕРєСЂСѓРіР»СЏС‚СЃСЏ РґРѕ Р±Р»РёР¶Р°Р№С€РёС… 30 (08:14 в†’ 8, 08:46 в†’ 9).`,
    getMenuForRole(ctx.from.id)
  );
});

bot.action('retry_mileage_photo', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);

  if (!state?.mileageRow || !state?.day || !state?.stage) {
    await ctx.replyWithHTML(`вљ пёЏ РЎРЅР°С‡Р°Р»Р° РЅР°Р¶РјРёС‚Рµ В«${BUTTONS.mileage}В».`, getMenuForRole(ctx.from.id));
    return;
  }

  setState(ctx.from.id, {
    ...state,
    mileageProcessing: false,
    awaitingMileagePhoto: true,
    awaitingManualMileage: false,
    recognizedMileage: null,
    ocrValue: null
  });

  await ctx.replyWithHTML('рџ“· РћС‚РїСЂР°РІСЊС‚Рµ РЅРѕРІРѕРµ С„РѕС‚Рѕ РїСЂРѕР±РµРіР° РєСЂСѓРїРЅС‹Рј РїР»Р°РЅРѕРј РёР»Рё РЅР°Р¶РјРёС‚Рµ В«вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊВ».', skipMileageKeyboard());
});

async function replaceMileageFlow(ctx, stage) {
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  try {
    const result = await prepareMileage(profile.fio, profile.workplace, stage);

    if (result.notFound) {
      const msg = formatNoSheetMessage(result, profile.workplace);
      await ctx.replyWithHTML(msg);
      return;
    }

    setState(ctx.from.id, makeMileageState(ctx.from.id, applyProfile(result, profile), { source: 'mileage' }));
    console.log('РѕР¶РёРґР°РЅРёРµ Р·Р°РјРµРЅС‹ РїСЂРѕР±РµРіР°', stage);
    await ctx.replyWithHTML(`рџ“· <b>Р—Р°РјРµРЅР° РїСЂРѕР±РµРіР°</b>\n\nРћС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ РґР»СЏ: <b>${esc(formatStage(stage))}</b>`, skipMileageKeyboard());
  } catch (error) {
    console.error('РѕС€РёР±РєР° Google Sheets', error);
    await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РїРѕРґРіРѕС‚РѕРІРёС‚СЊ Р·Р°РјРµРЅСѓ РїСЂРѕР±РµРіР°.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
  }
}

bot.action('replace_mileage_start', async (ctx) => {
  await ctx.answerCbQuery();
  await replaceMileageFlow(ctx, 'start');
});

bot.action('replace_mileage_end', async (ctx) => {
  await ctx.answerCbQuery();
  await replaceMileageFlow(ctx, 'end');
});

// Р¤Р°Р±СЂРёРєР° РѕР±СЂР°Р±РѕС‚С‡РёРєРѕРІ РґР»СЏ replace_start / replace_end. Р Р°РЅСЊС€Рµ СЌС‚Рѕ Р±С‹Р»Рё
// РґРІР° РїРѕС‡С‚Рё РёРґРµРЅС‚РёС‡РЅС‹С… Р±Р»РѕРєР° РїРѕ 25 СЃС‚СЂРѕРє, РѕС‚Р»РёС‡Р°СЋС‰РёС…СЃСЏ Р»РёС€СЊ stage Рё РёРєРѕРЅРєРѕР№.
function replaceTimeAction(stage) {
  return async (ctx) => {
    await ctx.answerCbQuery();
    const profile = await ensureProfile(ctx);
    if (!profile) return;

    try {
      const result = await replaceTime(profile.fio, profile.workplace, stage);

      if (result.notFound) {
        await ctx.replyWithHTML(formatNoSheetMessage(result, profile.workplace));
        return;
      }

      console.log('РІСЂРµРјСЏ Р·Р°РїРёСЃР°РЅРѕ', `replace_${stage}`);
      clearState(ctx.from.id);
      const icon = stage === 'start' ? 'рџџў' : 'рџ”ґ';
      const label = stage === 'start' ? 'РЎС‚Р°СЂС‚' : 'РљРѕРЅРµС†';
      await ctx.replyWithHTML(
        `${icon} <b>${label} СЃРјРµРЅС‹</b> Р·Р°РјРµРЅС‘РЅ: <code>${esc(result.timeValue)}</code>`,
        getMenuForRole(ctx.from.id)
      );
    } catch (error) {
      console.error('РѕС€РёР±РєР° Google Sheets', error);
      await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ РІСЂРµРјСЏ.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
    }
  };
}

bot.action('replace_start', replaceTimeAction('start'));
bot.action('replace_end', replaceTimeAction('end'));

bot.action('skip_mileage', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const savedMileage = state?.savedMileage;

  if (state?.mileageProcessing) {
    setState(ctx.from.id, { ...state, mileageProcessing: false, awaitingMileagePhoto: false, awaitingManualMileage: false });
    clearState(ctx.from.id);
    await ctx.replyWithHTML('вЏ­пёЏ РћР±СЂР°Р±РѕС‚РєР° С„РѕС‚Рѕ РѕС‚РјРµРЅРµРЅР°.', getMenuForRole(ctx.from.id));
    return;
  }

  if (savedMileage) {
    clearState(ctx.from.id);
    await ctx.replyWithHTML('в¬…пёЏ Р’РѕР·РІСЂР°С‰Р°СЋ РІ РјРµРЅСЋ.', getMenuForRole(ctx.from.id));
    return;
  }

  await ctx.replyWithHTML(
    'вљ пёЏ <b>РџСЂРѕРїСѓСЃС‚РёС‚СЊ РїСЂРѕР±РµРі?</b>\n\nРџСЂРѕР±РµРі РЅРµ Р±СѓРґРµС‚ Р·Р°РїРёСЃР°РЅ РІ С‚Р°Р±Р»РёС†Сѓ.',
    Markup.inlineKeyboard([
      [Markup.button.callback('вњ… Р”Р°, РїСЂРѕРїСѓСЃС‚РёС‚СЊ', 'confirm_skip_mileage')],
      [Markup.button.callback('вќЊ РћС‚РјРµРЅР°', 'cancel_skip_mileage')]
    ])
  );
});

bot.action('confirm_skip_mileage', async (ctx) => {
  await ctx.answerCbQuery('вЏ­пёЏ РџСЂРѕРїСѓС‰РµРЅРѕ');
  clearState(ctx.from.id);
  console.log('РїСЂРѕРїСѓСЃРє РїСЂРѕР±РµРіР° РїРѕРґС‚РІРµСЂР¶РґС‘РЅ');
  await ctx.replyWithHTML('вЏ­пёЏ РџСЂРѕР±РµРі РїСЂРѕРїСѓС‰РµРЅ.', getMenuForRole(ctx.from.id));
});

bot.action('cancel_skip_mileage', async (ctx) => {
  await ctx.answerCbQuery('РћС‚РјРµРЅРµРЅРѕ');
  try { await ctx.deleteMessage(); } catch {}
});

bot.action('edit_mileage', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);

  if (!state?.mileageRow || !state?.day || !state?.stage) {
    await ctx.replyWithHTML(`вљ пёЏ РЎРЅР°С‡Р°Р»Р° РЅР°Р¶РјРёС‚Рµ В«${BUTTONS.mileage}В».`, getMenuForRole(ctx.from.id));
    return;
  }

  setState(ctx.from.id, { ...state, mileageProcessing: false, awaitingManualMileage: true, awaitingMileagePhoto: false });
  await ctx.replyWithHTML('вњЏпёЏ <b>Р’РІРѕРґ РїСЂРѕР±РµРіР° РІСЂСѓС‡РЅСѓСЋ</b>\n\nР’РІРµРґРёС‚Рµ РїСЂРѕР±РµРі С‚РѕР»СЊРєРѕ С†РёС„СЂР°РјРё РёР»Рё Р·Р°РіСЂСѓР·РёС‚Рµ С„РѕС‚Рѕ РїРѕРІС‚РѕСЂРЅРѕ.', manualMileageKeyboard());
});

async function handleRouteSheetPhoto(ctx, state, fileId) {
  const telegramId = ctx.from.id;
  console.log('С„РѕС‚Рѕ РјР°СЂС€СЂСѓС‚РЅРѕРіРѕ Р»РёСЃС‚Р° РїРѕР»СѓС‡РµРЅРѕ');
  const date = getTodayText();
  const routeSheetNumber = getNextRouteSheetNumber(state, date);
  logRouteSheetPhoto(telegramId, fileId, state, date, routeSheetNumber);

  try {
    const forwarded = await sendPhotoToRouteSheetChat(ctx, fileId, buildRouteSheetCaption(state, routeSheetNumber));

    if (!forwarded) {
      await ctx.replyWithHTML('вљ пёЏ Р’СЂРµРјРµРЅРЅС‹Рµ РїСЂРѕР±Р»РµРјС‹ СЃ РѕС‚РїСЂР°РІРєРѕР№.\nРЎРѕРѕР±С‰РёС‚Рµ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.', routeSheetKeyboard());
      return;
    }

    await ctx.replyWithHTML(`вњ… <b>РњР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚ в„–${routeSheetNumber}</b> РѕС‚РїСЂР°РІР»РµРЅ.\n\nРњРѕР¶РЅРѕ РѕС‚РїСЂР°РІРёС‚СЊ РµС‰С‘ РѕРґРЅРѕ С„РѕС‚Рѕ.`, routeSheetKeyboard());
  } catch (error) {
    console.error('telegram send route sheet photo error', error);
    await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.', routeSheetKeyboard());
  }
}

async function finalizeReconciliationPostSend(ctx, state, telegramId, totalOrders) {
  const errors = [];

  if (totalOrders && totalOrders > 0 && state.fio && state.workplace) {
    const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
    const { day } = getCurrentDateInfo(timezone);

    try {
      const result = await updateEfficiencyOrders(state.fio, state.workplace, day, totalOrders);
      if (result.ok) {
        console.log(`СЌС„С„РµРєС‚РёРІРЅРѕСЃС‚СЊ: Р·Р°РїРёСЃР°РЅРѕ ${totalOrders} Р·Р°РєР°Р·РѕРІ РґР»СЏ ${state.fio}, РґРµРЅСЊ ${day}, СЏС‡РµР№РєР° ${result.cell}`);
      } else {
        console.error('СЌС„С„РµРєС‚РёРІРЅРѕСЃС‚СЊ: РЅРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ', result.error);
        errors.push('Р·Р°РєР°Р·С‹ РІ С‚Р°Р±Р»РёС†Сѓ СЌС„С„РµРєС‚РёРІРЅРѕСЃС‚Рё');
      }
    } catch (effError) {
      console.error('СЌС„С„РµРєС‚РёРІРЅРѕСЃС‚СЊ: РѕС€РёР±РєР° Р·Р°РїРёСЃРё', effError.message || effError);
      errors.push('Р·Р°РєР°Р·С‹ РІ С‚Р°Р±Р»РёС†Сѓ СЌС„С„РµРєС‚РёРІРЅРѕСЃС‚Рё');
    }

    try {
      const dayKey = getLbTodayKey();
      const oldOrders = getLbDayOrders(String(telegramId), dayKey);
      const profileLb = getFullProfile(telegramId);
      recordLeaderboardOrders(String(telegramId), state.fio, state.workplace, totalOrders, profileLb.courierType);
      await handleLeaderboardNotifications(ctx, String(telegramId), state.fio, state.workplace, totalOrders, oldOrders);
      addXp(telegramId, getXpForAction('reconciliation'), 'РЎРІРµСЂРєР°');
      updateChallengeProgress(telegramId, 'reconciliations');
    } catch (lbErr) {
      console.error('leaderboard record error', lbErr.message || lbErr);
      errors.push('СЂРµР№С‚РёРЅРі');
    }
  }

  if (errors.length > 0) {
    try {
      await ctx.replyWithHTML(
        `вљ пёЏ <b>Р¤РѕС‚Рѕ РѕС‚РїСЂР°РІР»РµРЅС‹, РЅРѕ РЅРµ СѓРґР°Р»РѕСЃСЊ Р·Р°РїРёСЃР°С‚СЊ:</b>\n` +
        errors.map((e) => `вЂў ${esc(e)}`).join('\n') +
        '\n\nРЎРѕРѕР±С‰РёС‚Рµ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.',
        getMenuForRole(telegramId)
      );
    } catch (notifyErr) {
      console.error('failed to notify user about reconciliation errors', notifyErr.message);
    }
  }
}

async function handleReconciliationPhoto(ctx, state, fileId) {
  const telegramId = ctx.from.id;
  const photosSent = (state.reconciliationPhotosSent || 0) + 1;
  const total = state.reconciliationTotal || 1;
  const isTerminal = state.device === 'РўРµСЂРјРёРЅР°Р»';
  const isTerminalFirstPhoto = isTerminal && photosSent === 1;

  if (isTerminalFirstPhoto) {
    const cashInfo = await recognizeReconciliationCashSafe(ctx, fileId, 'terminal_first_photo');
    const shouldAttachCash = cashInfo.valid && Number(cashInfo.amount) >= 1 && Number(cashInfo.orders) > 0;
    const cashFormatted = shouldAttachCash ? formatMoneyRu(cashInfo.amount) : null;

    const captionLines = [
      `рџ“Љ РЎРІРµСЂРєРё вЂ” РўРµСЂРјРёРЅР°Р» (СЃС‚Р°С‚РёСЃС‚РёРєР°)`,
      `рџ‘¤ ${esc(getEmployeeDisplayName(state.fio))}`,
      `рџЏ¬ ${esc(state.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ')}`
    ];

    if (shouldAttachCash && cashFormatted) {
      const rawAmount = Number(cashInfo.amount);
      if (!Number.isFinite(rawAmount) || rawAmount < 1 || rawAmount > MAX_REASONABLE_CASH_AMOUNT) {
        console.log('СЃРІРµСЂРєР° OCR: СЃСѓРјРјР° РЅР°Р»РёС‡РЅС‹С… РІРЅРµ РґРѕРїСѓСЃС‚РёРјРѕРіРѕ РґРёР°РїР°Р·РѕРЅР°', rawAmount);
      } else {
        const previousPending = getPendingCash(telegramId);
        const previousAmount = Number(previousPending?.amount || 0);
        const totalAmount = roundMoney(
          Number.isFinite(previousAmount) && previousAmount >= 1
            ? previousAmount + rawAmount
            : rawAmount
        );
        const totalFormatted = formatMoneyRu(totalAmount);
        const currentNumberOnly = formatMoneyRuNumber(rawAmount) || String(cashFormatted).replace(/\s*в‚Ѕ$/, '');

        captionLines.push(`рџ’µ Рљ СЃРґР°С‡Рµ РІ СЃР»РµРґСѓСЋС‰СѓСЋ СЃРјРµРЅСѓ: <code>${esc(currentNumberOnly)}</code> в‚Ѕ`);

        setPendingCash(telegramId, {
          amount: totalAmount,
          formatted: totalFormatted,
          orders: cashInfo.orders,
          workplace: state.workplace || null,
          sourceLabel: 'РўРµСЂРјРёРЅР°Р»',
          updatedAt: new Date().toISOString(),
          fileId
        });
      }
    }

    const caption = truncateCaption(captionLines.join('\n'));

    console.log('С„РѕС‚Рѕ СЃРІРµСЂРѕРє РїРѕР»СѓС‡РµРЅРѕ', `${photosSent}/${total}`, '(СЃС‚Р°С‚РёСЃС‚РёРєР°)');
    logReconciliationPhoto(telegramId, fileId, state, 'РўРµСЂРјРёРЅР°Р» (СЃС‚Р°С‚РёСЃС‚РёРєР°)');
    appendLog(reconciliationLogPath, {
      at: new Date().toISOString(),
      type: 'cash_detection',
      telegramId,
      fileId,
      workplace: state?.workplace || null,
      label: 'РўРµСЂРјРёРЅР°Р» (СЃС‚Р°С‚РёСЃС‚РёРєР°)',
      cashOrders: cashInfo.orders,
      cashAmount: cashInfo.amount,
      totalOrders: cashInfo.totalOrders,
      cashApplied: Boolean(shouldAttachCash),
      reason: cashInfo.reason || null
    });

    setState(telegramId, {
      ...state,
      reconciliationPhotosSent: photosSent,
      reconciliationPhoto1FileId: fileId,
      reconciliationPhoto1Caption: caption,
      reconciliationPhoto1TotalOrders: cashInfo.totalOrders || null,
      reconciliationPhoto1OcrReason: cashInfo.reason || null
    });

    await ctx.replyWithHTML(
      `вњ… Р¤РѕС‚Рѕ <b>1</b> РёР· <b>2</b> (СЃС‚Р°С‚РёСЃС‚РёРєР°) РїРѕР»СѓС‡РµРЅРѕ.\n\n` +
      `рџ“· РўРµРїРµСЂСЊ РѕС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ <b>2 РёР· 2</b>: <b>рџ§ѕ Р§РµРє</b>`,
      routeSheetKeyboard()
    );
    return;
  }

  if (isTerminal && photosSent === 2) {
    console.log('С„РѕС‚Рѕ СЃРІРµСЂРѕРє РїРѕР»СѓС‡РµРЅРѕ', `${photosSent}/${total}`, '(С‡РµРє)');
    logReconciliationPhoto(telegramId, fileId, state, 'РўРµСЂРјРёРЅР°Р» (С‡РµРє)');
    appendLog(reconciliationLogPath, {
      at: new Date().toISOString(),
      type: 'cash_detection',
      telegramId,
      fileId,
      workplace: state?.workplace || null,
      label: 'РўРµСЂРјРёРЅР°Р» (С‡РµРє)',
      cashOrders: 0,
      cashAmount: 0,
      cashApplied: false,
      reason: 'С‡РµРє вЂ” OCR РїСЂРѕРїСѓС‰РµРЅ'
    });

    const photo1FileId = state.reconciliationPhoto1FileId;
    const photo1Caption = state.reconciliationPhoto1Caption || '';

    try {
      const forwarded = await sendMediaGroupToReconciliationChat(ctx, [
        { fileId: photo1FileId, caption: photo1Caption },
        { fileId, caption: '' }
      ]);

      if (!forwarded) {
        await ctx.replyWithHTML('вљ пёЏ Р’СЂРµРјРµРЅРЅС‹Рµ РїСЂРѕР±Р»РµРјС‹ СЃ РѕС‚РїСЂР°РІРєРѕР№.\nРЎРѕРѕР±С‰РёС‚Рµ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.', routeSheetKeyboard());
        return;
      }

      clearState(telegramId);
      const ocrWarning = !state.reconciliationPhoto1TotalOrders && state.reconciliationPhoto1OcrReason
        ? `\n\nвљ пёЏ OCR РЅРµ СЂР°СЃРїРѕР·РЅР°Р» Р·Р°РєР°Р·С‹/РЅР°Р»РёС‡РЅС‹Рµ. Р¤РѕС‚Рѕ РѕС‚РїСЂР°РІР»РµРЅС‹, РЅРѕ РґР°РЅРЅС‹Рµ РЅРµ Р·Р°РїРёСЃР°РЅС‹ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё.`
        : '';
      await ctx.replyWithHTML(`вњ… <b>Р’СЃРµ С„РѕС‚Рѕ (2 С€С‚.) РѕС‚РїСЂР°РІР»РµРЅС‹.</b>${ocrWarning}`, getMenuForRole(ctx.from.id));

      const totalOrders = state.reconciliationPhoto1TotalOrders;
      await finalizeReconciliationPostSend(ctx, state, telegramId, totalOrders);
    } catch (error) {
      console.error('telegram send reconciliation album error', error);
      await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.', routeSheetKeyboard());
    }
    return;
  }

  const label = 'РџРёРЅ-РџР°РЅРµР»СЊ';
  const cashInfo = await recognizeReconciliationCashSafe(ctx, fileId, 'pin_panel');
  const shouldAttachCash = cashInfo.valid && Number(cashInfo.amount) >= 1 && Number(cashInfo.orders) > 0;
  const cashFormatted = shouldAttachCash ? formatMoneyRu(cashInfo.amount) : null;

  const captionLines = [
    `рџ“Љ РЎРІРµСЂРєРё вЂ” ${esc(label)}`,
    `рџ‘¤ ${esc(getEmployeeDisplayName(state.fio))}`,
    `рџЏ¬ ${esc(state.workplace || 'РЅРµ СѓРєР°Р·Р°РЅРѕ')}`
  ];

  if (shouldAttachCash && cashFormatted) {
    const rawAmount = Number(cashInfo.amount);
    if (!Number.isFinite(rawAmount) || rawAmount < 1 || rawAmount > MAX_REASONABLE_CASH_AMOUNT) {
      console.log('СЃРІРµСЂРєР° OCR: СЃСѓРјРјР° РЅР°Р»РёС‡РЅС‹С… РІРЅРµ РґРѕРїСѓСЃС‚РёРјРѕРіРѕ РґРёР°РїР°Р·РѕРЅР°', rawAmount);
    } else {
      const previousPending = getPendingCash(telegramId);
      const previousAmount = Number(previousPending?.amount || 0);
      const totalAmount = roundMoney(
        Number.isFinite(previousAmount) && previousAmount >= 1
          ? previousAmount + rawAmount
          : rawAmount
      );
      const totalFormatted = formatMoneyRu(totalAmount);
      const currentNumberOnly = formatMoneyRuNumber(rawAmount) || String(cashFormatted).replace(/\s*в‚Ѕ$/, '');

      captionLines.push(`рџ’µ Рљ СЃРґР°С‡Рµ РІ СЃР»РµРґСѓСЋС‰СѓСЋ СЃРјРµРЅСѓ: <code>${esc(currentNumberOnly)}</code> в‚Ѕ`);

      setPendingCash(telegramId, {
        amount: totalAmount,
        formatted: totalFormatted,
        orders: cashInfo.orders,
        workplace: state.workplace || null,
        sourceLabel: label,
        updatedAt: new Date().toISOString(),
        fileId
      });
    }
  }

  const caption = truncateCaption(captionLines.join('\n'));

  console.log('С„РѕС‚Рѕ СЃРІРµСЂРѕРє РїРѕР»СѓС‡РµРЅРѕ', `${photosSent}/${total}`);
  logReconciliationPhoto(telegramId, fileId, state, label);
  appendLog(reconciliationLogPath, {
    at: new Date().toISOString(),
    type: 'cash_detection',
    telegramId,
    fileId,
    workplace: state?.workplace || null,
    label,
    cashOrders: cashInfo.orders,
    cashAmount: cashInfo.amount,
    totalOrders: cashInfo.totalOrders,
    cashApplied: Boolean(shouldAttachCash),
    reason: cashInfo.reason || null
  });

  try {
    const forwarded = await sendPhotoToReconciliationChat(ctx, fileId, caption);

    if (!forwarded) {
      await ctx.replyWithHTML('вљ пёЏ Р’СЂРµРјРµРЅРЅС‹Рµ РїСЂРѕР±Р»РµРјС‹ СЃ РѕС‚РїСЂР°РІРєРѕР№.\nРЎРѕРѕР±С‰РёС‚Рµ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.', routeSheetKeyboard());
      return;
    }

    clearState(telegramId);
    const ocrWarning = shouldWarnAboutReconciliationOcr(cashInfo)
      ? `\n\nвљ пёЏ OCR РЅРµ СЂР°СЃРїРѕР·РЅР°Р» Р·Р°РєР°Р·С‹/РЅР°Р»РёС‡РЅС‹Рµ. Р¤РѕС‚Рѕ РѕС‚РїСЂР°РІР»РµРЅРѕ, РЅРѕ РґР°РЅРЅС‹Рµ РЅРµ Р·Р°РїРёСЃР°РЅС‹ Р°РІС‚РѕРјР°С‚РёС‡РµСЃРєРё.`
      : '';
    await ctx.replyWithHTML(`вњ… <b>Р’СЃРµ С„РѕС‚Рѕ (${total} С€С‚.) РѕС‚РїСЂР°РІР»РµРЅС‹.</b>${ocrWarning}`, getMenuForRole(ctx.from.id));

    const totalOrders = cashInfo.totalOrders;
    await finalizeReconciliationPostSend(ctx, state, telegramId, totalOrders);
  } catch (error) {
    console.error('telegram send reconciliation photo error', error);
    await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РѕС‚РїСЂР°РІРёС‚СЊ С„РѕС‚Рѕ.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.', routeSheetKeyboard());
  }
}

async function handleMileagePhoto(ctx, state, fileId) {
  const telegramId = ctx.from.id;
  console.log('С„РѕС‚Рѕ РїРѕР»СѓС‡РµРЅРѕ');
  logMileagePhoto(telegramId, fileId, state);

  const photoState = {
    ...state,
    awaitingMileagePhoto: false,
    awaitingManualMileage: false,
    photoReceived: true,
    fileId,
    mileageProcessing: true
  };
  setState(telegramId, photoState);

  const ocrAvailable = isRapidOcrEnabled();
  if (!ocrAvailable) {
    setState(telegramId, {
      ...photoState,
      mileageProcessing: false,
      awaitingMileagePhoto: true,
      awaitingManualMileage: true,
      recognizedMileage: null,
      ocrValue: null
    });
    sendPhotoToWorkChat(ctx, fileId, buildPhotoCaption(state)).catch((error) => {
      console.error('telegram send photo error', error);
    });
    await ctx.replyWithHTML('вљ пёЏ РђРІС‚Рѕ-СЂР°СЃРїРѕР·РЅР°РІР°РЅРёРµ СЃРµР№С‡Р°СЃ РЅРµРґРѕСЃС‚СѓРїРЅРѕ.\nР’РІРµРґРёС‚Рµ РїСЂРѕР±РµРі РІСЂСѓС‡РЅСѓСЋ РёР»Рё РЅР°Р¶РјРёС‚Рµ В«вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊВ».', mileageConfirmKeyboard());
    return;
  }

  const ocrHealthy = await checkRapidOcrHealth();
  if (!ocrHealthy) {
    console.warn('RapidOCR health check failed, falling back to manual input');
    setState(telegramId, {
      ...photoState,
      mileageProcessing: false,
      awaitingMileagePhoto: true,
      awaitingManualMileage: true,
      recognizedMileage: null,
      ocrValue: null
    });
    sendPhotoToWorkChat(ctx, fileId, buildPhotoCaption(state)).catch((error) => {
      console.error('telegram send photo error', error);
    });
    await ctx.replyWithHTML('вљ пёЏ РЎРµСЂРІРµСЂ СЂР°СЃРїРѕР·РЅР°РІР°РЅРёСЏ РЅРµРґРѕСЃС‚СѓРїРµРЅ.\nР’РІРµРґРёС‚Рµ РїСЂРѕР±РµРі РІСЂСѓС‡РЅСѓСЋ РёР»Рё РЅР°Р¶РјРёС‚Рµ В«вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊВ».', mileageConfirmKeyboard());
    return;
  }

  await ctx.replyWithHTML('рџ“ё Р¤РѕС‚Рѕ РїСЂРёРЅСЏС‚Рѕ. РЎС‡РёС‚С‹РІР°СЋ РїСЂРѕР±РµРі...');

  const chatId = ctx.chat.id;
  const telegram = ctx.telegram;

  const MILEAGE_TIMEOUT_MS = 45000;

  const bgPromise = processMileagePhotoInBackground(telegram, chatId, telegramId, photoState, fileId, photoState);

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error(' mileage processing timeout')), MILEAGE_TIMEOUT_MS)
  );

  Promise.race([bgPromise, timeoutPromise]).catch((err) => {
    console.error('mileage bg error:', err.message);
    if (err.message && err.message.includes('timeout')) {
      telegram.sendMessage(chatId, 'вљ пёЏ РџСЂРµРІС‹С€РµРЅРѕ РІСЂРµРјСЏ СЂР°СЃРїРѕР·РЅР°РІР°РЅРёСЏ. Р’РІРµРґРёС‚Рµ РїСЂРѕР±РµРі РІСЂСѓС‡РЅСѓСЋ РёР»Рё РЅР°Р¶РјРёС‚Рµ В«вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊВ».', { parse_mode: 'HTML' }).catch(() => {});
    }
  });
}

async function processMileagePhotoInBackground(telegram, chatId, telegramId, originalState, fileId, photoState) {
  const sendMsg = async (html, extra) => {
    try {
      await telegram.sendMessage(chatId, html, { parse_mode: 'HTML', ...(extra || {}) });
    } catch (e) {
      console.error('background sendMsg error', e.message);
    }
  };

  try {
    console.log('mileage bg: start processing', { telegramId, fileId });

    const [recognitionOptions] = await Promise.all([
      buildMileageRecognitionOptions(originalState),
      forwardPhoto({ telegram }, fileId, buildPhotoCaption(originalState), 'work').catch((error) => {
        console.error('telegram send photo error', error);
      })
    ]);
    console.log('mileage bg: recognition options built', recognitionOptions);

    const sourceBuffer = await downloadTelegramFile({ telegram }, fileId);
    console.log('mileage bg: file downloaded', { size: sourceBuffer?.length });

    const ocrResult = await recognizeMileage({ telegram, chat: { id: chatId } }, fileId, {
      ...recognitionOptions,
      sourceBuffer,
      onStatus: async (msg) => {
        try { await sendMsg(msg); } catch (e) { /* ignore */ }
      }
    });

    const mileageValue = ocrResult?.mileage || null;
    const ocrCandidates = ocrResult?.candidates || [];
    console.log('mileage bg: OCR result', { mileageValue, candidateCount: ocrCandidates.length });

    if (!mileageValue) {
      if (sourceBuffer) {
        saveOcrDebugImage(sourceBuffer, {
          status: ocrCandidates.length > 0 ? 'ocr_weak' : 'ocr_fail',
          ocrResult: ocrCandidates.length > 0 ? ocrCandidates[0].mileage : null,
          userCorrectedValue: null,
          telegramId,
          stage: originalState.stage,
          workplace: originalState.workplace,
          fio: originalState.fio,
          fileId
        });
      }

      const cs = getState(telegramId);
      if (cs?.fileId === fileId) {
        setState(telegramId, {
          ...photoState,
          mileageProcessing: false,
          awaitingMileagePhoto: true,
          awaitingManualMileage: true,
          recognizedMileage: null,
          ocrValue: null
        });
      }

      let failMsg = 'вљ пёЏ <b>РќРµ СѓРґР°Р»РѕСЃСЊ СЂР°СЃРїРѕР·РЅР°С‚СЊ РїСЂРѕР±РµРі</b>\n\n';
      if (ocrCandidates.length > 0) {
        const candidateList = ocrCandidates.slice(0, 3).map((c) => `<code>${c.mileage}</code> РєРј`).join(', ');
        failMsg += `Р’РѕР·РјРѕР¶РЅС‹Рµ Р·РЅР°С‡РµРЅРёСЏ: ${candidateList}\n\n`;
      }
      failMsg += 'РћС‚РїСЂР°РІСЊС‚Рµ С„РѕС‚Рѕ РїРѕРІС‚РѕСЂРЅРѕ РєСЂСѓРїРЅС‹Рј РїР»Р°РЅРѕРј, РІРІРµРґРёС‚Рµ РІСЂСѓС‡РЅСѓСЋ РёР»Рё РЅР°Р¶РјРёС‚Рµ В«вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊВ».';
      await sendMsg(failMsg, mileageConfirmKeyboard());
      return;
    }

    // OCR СѓСЃРїРµС€РЅРѕ СЂР°СЃРїРѕР·РЅР°Р» вЂ” СЃРѕС…СЂР°РЅСЏРµРј РІ Р»СЋР±РѕРј СЃР»СѓС‡Р°Рµ, РґР°Р¶Рµ РµСЃР»Рё РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ
    // РЅР°Р¶РёРјР°Р» РєРЅРѕРїРєРё РІРѕ РІСЂРµРјСЏ РѕР±СЂР°Р±РѕС‚РєРё. РСЃРїРѕР»СЊР·СѓРµРј originalState РєР°Рє fallback.
    await saveMileageFromState(
      { from: { id: telegramId }, telegram, replyWithHTML: sendMsg },
      mileageValue,
      { sourceBuffer, telegram, chatId, fallbackState: originalState }
    );
  } catch (error) {
    console.error('background mileage processing error', error);
    await sendMsg('вљ пёЏ <b>РћС€РёР±РєР° РѕР±СЂР°Р±РѕС‚РєРё С„РѕС‚Рѕ</b>\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р·.', mileageConfirmKeyboard());
  } finally {
    const cs = getState(telegramId);
    if (cs && cs.fileId === fileId && cs.mileageProcessing) {
      setState(telegramId, {
        ...cs,
        mileageProcessing: false,
        awaitingMileagePhoto: true,
        awaitingManualMileage: true
      });
    }
  }
}

bot.on('photo', async (ctx) => {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const state = getState(telegramId);

  const photos = ctx.message.photo;
  const bestPhoto = photos[photos.length - 1];
  const fileId = bestPhoto.file_id;

  if (state?.awaitingRouteSheetPhoto) {
    return handleRouteSheetPhoto(ctx, state, fileId);
  }

  if (state?.awaitingReconciliationPhoto) {
    return handleReconciliationPhoto(ctx, state, fileId);
  }

  if (!state?.awaitingMileagePhoto) {
    await ctx.replyWithHTML(`вљ пёЏ РЎРЅР°С‡Р°Р»Р° РЅР°Р¶РјРёС‚Рµ В«${BUTTONS.mileage}В».`, getMenuForRole(ctx.from.id));
    return;
  }

  return handleMileagePhoto(ctx, state, fileId);
});

async function handleManualTime(ctx, state, text) {
  const telegramId = ctx.from.id;
  const timeValue = normalizeTimeValue(text);

  if (!timeValue) {
    await ctx.replyWithHTML(
      'вќЊ РќРµРІРµСЂРЅС‹Р№ С„РѕСЂРјР°С‚ РІСЂРµРјРµРЅРё.\n\n' +
      'РџРѕРґРґРµСЂР¶РёРІР°СЋС‚СЃСЏ: <code>7</code>, <code>7,5</code>, <code>07:30</code>, <code>08:46</code>, <code>08.46</code>, <code>8 14</code> (С‡Р°СЃС‹ 0вЂ“24).\n' +
      'РњРёРЅСѓС‚С‹ РѕРєСЂСѓРіР»СЏСЋС‚СЃСЏ РґРѕ Р±Р»РёР¶Р°Р№С€РёС… 30.'
    );
    return;
  }

  try {
    await updateCourierTime(state.courierRow, state.day, state.stage, timeValue, state.workplace);
    clearState(telegramId);
    console.log('РІСЂРµРјСЏ РёР·РјРµРЅРµРЅРѕ', state.stage);
    const icon = state.stage === 'start' ? 'рџџў' : 'рџ”ґ';
    const label = state.stage === 'start' ? 'РЎС‚Р°СЂС‚' : 'РљРѕРЅРµС†';
    await ctx.replyWithHTML(`${icon} <b>${label} СЃРјРµРЅС‹</b> РёР·РјРµРЅС‘РЅ: <code>${esc(timeValue)}</code>`, getMenuForRole(ctx.from.id));
  } catch (error) {
    console.error('РѕС€РёР±РєР° Google Sheets', error);
    await ctx.replyWithHTML('вљ пёЏ РќРµ СѓРґР°Р»РѕСЃСЊ РёР·РјРµРЅРёС‚СЊ РІСЂРµРјСЏ.\nРџРѕРїСЂРѕР±СѓР№С‚Рµ РµС‰С‘ СЂР°Р· РёР»Рё РѕР±СЂР°С‚РёС‚РµСЃСЊ Рє Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.');
  }
}

async function requireFio(ctx) {
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) {
    await askForFio(ctx);
    return null;
  }
  return fio;
}

// в”Ђв”Ђв”Ђ РҐРµРЅРґР»РµСЂС‹, РІС‹РЅРµСЃРµРЅРЅС‹Рµ РёР· bot.on('text') РґР»СЏ С‡РёС‚Р°Р±РµР»СЊРЅРѕСЃС‚Рё в”Ђв”Ђв”Ђ

async function handleSwitchUser(ctx, state, text, telegramId) {
  setState(telegramId, { awaitingSwitchUser: true });
  await ctx.replyWithHTML(
    'вљ пёЏ <b>РЎРјРµРЅР° СЃРѕС‚СЂСѓРґРЅРёРєР°</b>\n\nР’СЃРµ РґР°РЅРЅС‹Рµ (Р¤РРћ, РЅРѕРјРµСЂ РјР°С€РёРЅС‹, РјР°РіР°Р·РёРЅ, СѓСЃС‚СЂРѕР№СЃС‚РІРѕ) Р±СѓРґСѓС‚ СѓРґР°Р»РµРЅС‹.\n\nР’С‹ СѓРІРµСЂРµРЅС‹?',
    switchUserKeyboard()
  );
}

async function handleSheetsInfo(ctx, state, text, telegramId) {
  const hasAccess = isAdminUser(telegramId) || isSheetAccessUser(telegramId) || getUserRole(telegramId) === 'logist';
  if (!hasAccess) {
    // Р Р°РЅСЊС€Рµ РїСЂРµРґР»Р°РіР°Р»Рё В«РЅР°Р¶РјРёС‚Рµ РњРѕР№ IDВ», РЅРѕ СЌС‚Р° РєРЅРѕРїРєР° СЃРїСЂСЏС‚Р°РЅР° РІ
    // РїРѕРґРјРµРЅСЋ РЈРїСЂР°РІР»РµРЅРёРµ вЂ” РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ РЅРµ Р·РЅР°Р» РєСѓРґР° РёРґС‚Рё. РўРµРїРµСЂСЊ
    // inline-РєРЅРѕРїРєР° РїСЂСЏРјРѕ Р·РґРµСЃСЊ.
    await ctx.replyWithHTML(
      'в›” РЈ РІР°СЃ РЅРµС‚ РґРѕСЃС‚СѓРїР° Рє СЌС‚РѕРјСѓ СЂР°Р·РґРµР»Сѓ.\n\n' +
      'РџРѕР»СѓС‡РёС‚Рµ РІР°С€ Telegram ID Рё РѕС‚РїСЂР°РІСЊС‚Рµ РµРіРѕ Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ.',
      Markup.inlineKeyboard([
        [Markup.button.callback('рџ†” РџРѕР»СѓС‡РёС‚СЊ РјРѕР№ ID', 'show_my_id')]
      ])
    );
    return;
  }
  const cm = getCurrentMonthKey();
  const nm = getNextMonthKey();
  let msg = `рџ“‹ <b>РџСЂРёРІСЏР·РєР° С‚Р°Р±Р»РёС†</b>\n\nрџ—“ РђРєС‚РёРІРЅС‹Р№ РјРµСЃСЏС†: <code>${cm}</code>\nрџ—“ РЎР»РµРґСѓСЋС‰РёР№ РјРµСЃСЏС†: <code>${nm}</code>\n\n`;
  for (const wp of WORKPLACES) {
    const info = resolveSheetInfo(wp);
    const activeId = getWorkplaceSheetIdByMonth(wp, cm);
    const nextId = getWorkplaceSheetIdByMonth(wp, nm);
    msg += `рџЏ¬ <b>${esc(wp)}</b>\n`;
    msg += `   РўРµРєСѓС‰РёР№: ${activeId ? 'вњ… РїСЂРёРІСЏР·Р°РЅР°' : 'вќЊ РЅРµС‚'}\n`;
    msg += `   РЎР»РµРґСѓСЋС‰РёР№: ${nextId ? 'вњ… РїСЂРёРІСЏР·Р°РЅР°' : 'вќЊ РЅРµС‚'}\n`;
    msg += `   РСЃС‚РѕС‡РЅРёРє: ${esc(info.source)}\n\n`;
  }
  msg += `<b>РљРѕРјР°РЅРґС‹:</b>\n`;
  msg += `<code>/sheet east URL</code> вЂ” РїСЂРёРІСЏР·Р°С‚СЊ РґР»СЏ РРњ Р’РѕСЃС‚РѕРє\n`;
  msg += `<code>/sheet center URL</code> вЂ” РїСЂРёРІСЏР·Р°С‚СЊ РґР»СЏ РРњ Р¦РµРЅС‚СЂ\n`;
  msg += `<code>/sheet east active URL</code> вЂ” РЅР° С‚РµРєСѓС‰РёР№ РјРµСЃСЏС†\n`;
  msg += `<code>/sheet east next URL</code> вЂ” РЅР° СЃР»РµРґСѓСЋС‰РёР№\n`;
  msg += `<code>/sheet</code> вЂ” РїРѕРґСЂРѕР±РЅС‹Р№ СЃРїРёСЃРѕРє`;
  await ctx.replyWithHTML(msg);
}

async function handleMyId(ctx) {
  const userId = ctx.from.id;
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  const username = ctx.from.username ? `@${ctx.from.username}` : '';
  const displayName = [firstName, lastName].filter(Boolean).join(' ') || 'Р‘РµР· РёРјРµРЅРё';

  await ctx.replyWithHTML(
    `рџ†” <b>Р’Р°С€ Telegram ID:</b> <code>${userId}</code>\n\n` +
    'РЎРѕРѕР±С‰РёС‚Рµ СЌС‚РѕС‚ ID Р°РґРјРёРЅРёСЃС‚СЂР°С‚РѕСЂСѓ РґР»СЏ РїРѕР»СѓС‡РµРЅРёСЏ РґРѕСЃС‚СѓРїР° Рє СЂР°Р·РґРµР»Сѓ В«рџ“‹ РўР°Р±Р»РёС†С‹В».'
  );

  await notifyAdmins(
    `рџ†” <b>Р—Р°РїСЂРѕСЃ РґРѕСЃС‚СѓРїР° Рє РўР°Р±Р»РёС†Р°Рј</b>\n\n` +
    `рџ‘¤ ${esc(displayName)} ${esc(username)}\n` +
    `рџ†” <code>${userId}</code>\n\n` +
    `Р”Р°С‚СЊ РґРѕСЃС‚СѓРї: <code>/sheet_access ${userId}</code>`
  );
}

async function handleUpdateEditText(ctx, state, text) {
  if (!isAdminUser(ctx.from.id)) {
    clearState(ctx.from.id);
    return;
  }
  const editVersion = state.editVersion;
  const pending = _pendingUpdates[editVersion];
  clearState(ctx.from.id);
  if (!pending) {
    await ctx.replyWithHTML('вљ пёЏ РћР±РЅРѕРІР»РµРЅРёРµ СѓР¶Рµ РѕР±СЂР°Р±РѕС‚Р°РЅРѕ РёР»Рё СѓСЃС‚Р°СЂРµР»Рѕ.');
    return;
  }
  const customHighlights = text.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 4);
  const fullMessage = (
    `рџ†• <b><i>РћР±РЅРѕРІР»РµРЅРёРµ Р±РѕС‚Р° v${esc(editVersion)}</i></b>\n\n` +
    '<b>РљРѕСЂРѕС‚РєРѕ, С‡С‚Рѕ РёР·РјРµРЅРёР»Рё:</b>\n' +
    customHighlights.map((item) => `вЂў ${esc(item)}`).join('\n') +
    '\n\nрџ’™ РҐРѕСЂРѕС€РµР№ СЃРјРµРЅС‹!'
  );
  _pendingUpdates[editVersion] = { ...pending, message: fullMessage };
  savePendingUpdates();
  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('вњ… РћС‚РїСЂР°РІРёС‚СЊ', `upd_send:${editVersion}`),
      Markup.button.callback('вњЏпёЏ РР·РјРµРЅРёС‚СЊ С‚РµРєСЃС‚', `upd_edit:${editVersion}`)
    ],
    [Markup.button.callback('вЏ­пёЏ РџСЂРѕРїСѓСЃС‚РёС‚СЊ', `upd_skip:${editVersion}`)]
  ]);
  await ctx.replyWithHTML('<b>РџСЂРµРґРїСЂРѕСЃРјРѕС‚СЂ:</b>\n\n' + fullMessage, keyboard);
}

async function handleManualMileageInput(ctx, state, text) {
  if (!/^\d{2,6}$/.test(text)) {
    await ctx.replyWithHTML('вќЊ Р’РІРµРґРёС‚Рµ РїСЂРѕР±РµРі РѕС‚ <b>2 РґРѕ 6 С†РёС„СЂ</b>.\n\nРќР°РїСЂРёРјРµСЂ: <code>25408</code>', manualMileageKeyboard());
    return;
  }
  await saveMileageFromState(ctx, Number(text));
}

// в”Ђв”Ђв”Ђ Dispatcher РґР»СЏ bot.on('text') в”Ђв”Ђв”Ђ
// РљР°Р¶РґР°СЏ Р·Р°РїРёСЃСЊ РѕРїРёСЃС‹РІР°РµС‚ РѕРґРёРЅ РјР°СЂС€СЂСѓС‚. Р Р°РЅСЊС€Рµ РІСЃС‘ СЌС‚Рѕ Р±С‹Р»Рѕ ifelse'Р°РјРё
// РґР»РёРЅРѕР№ РІ 200+ СЃС‚СЂРѕРє вЂ” С‚РµРїРµСЂСЊ СЃСЂР°Р·Сѓ РІРёРґРЅРѕ, РєС‚Рѕ С‡С‚Рѕ РѕР±СЂР°Р±Р°С‚С‹РІР°РµС‚.
//
// РџРѕР»СЏ:
//   match(text, state) в†’ bool вЂ” РєР°СЃС‚РѕРјРЅРѕРµ СѓСЃР»РѕРІРёРµ (РІС‹РїРѕР»РЅСЏРµС‚СЃСЏ РџР•Р Р’Р«Рњ РµСЃР»Рё РµСЃС‚СЊ)
//   state: 'awaitingFoo' вЂ” РІС‹РїРѕР»РЅСЏРµС‚СЃСЏ РїСЂРё state.awaitingFoo === true
//   button: BUTTONS.foo вЂ” С‚РѕС‡РЅРѕРµ СЃРѕРІРїР°РґРµРЅРёРµ С‚РµРєСЃС‚Р°
//   legacy: ['РЎС‚Р°СЂС‹Р№ С‚РµРєСЃС‚', ...] вЂ” Р°Р»РёР°СЃС‹ РґР»СЏ РѕР±СЂР°С‚РЅРѕР№ СЃРѕРІРјРµСЃС‚РёРјРѕСЃС‚Рё
//   handler: (ctx, state, text, telegramId) в†’ Promise
//
// РџРѕСЂСЏРґРѕРє Р’РђР–Р•Рќ: state-РјР°СЂС€СЂСѓС‚С‹ РґРѕР»Р¶РЅС‹ Р±С‹С‚СЊ РІС‹С€Рµ button-РјР°СЂС€СЂСѓС‚РѕРІ,
// С‡С‚РѕР±С‹ СЋР·РµСЂ РїСЂРё Р·Р°РїРѕР»РЅРµРЅРёРё С„РѕСЂРјС‹ РЅРµ В«РІС‹РїР°РґР°Р»В» РІ РјРµРЅСЋ.

const TEXT_ROUTES = [
  // 1) В«РќР°Р·Р°Рґ РІ РјРµРЅСЋВ» вЂ” РѕР±С‰Р°СЏ РєРЅРѕРїРєР°
  { match: (text) => ['рџЏ  Р’ РјРµРЅСЋ', 'в¬…пёЏ РќР°Р·Р°Рґ', 'РќР°Р·Р°Рґ'].includes(text) || text === BUTTONS.back, handler: (ctx) => backToMainMenu(ctx) },

  // 2) State-based: РїРѕР»СЊР·РѕРІР°С‚РµР»СЊ СЃРµР№С‡Р°СЃ С‡С‚Рѕ-С‚Рѕ РІРІРѕРґРёС‚
  { state: 'awaitingCarNumber', handler: (ctx, s, text) => saveCarNumber(ctx, text) },
  { state: 'awaitingWorkplace', handler: (ctx, s, text) => saveWorkplace(ctx, text) },
  { state: 'awaitingDevice', handler: (ctx, s, text) => saveDevice(ctx, text) },
  { state: 'awaitingFio', handler: (ctx, s, text) => authorizeFio(ctx, text) },
  { state: 'awaitingRoleChoice', handler: (ctx) => ctx.replyWithHTML('вљ пёЏ Р’С‹Р±РµСЂРёС‚Рµ СЂРѕР»СЊ РєРЅРѕРїРєРѕР№ РІС‹С€Рµ.', roleChoiceKeyboard()) },
  { state: 'awaitingManualTime', handler: (ctx, state, text) => handleManualTime(ctx, state, text) },
  { state: 'awaitingUpdateEdit', handler: (ctx, state, text) => handleUpdateEditText(ctx, state, text) },
  { state: 'awaitingManualMileage', handler: (ctx, state, text) => handleManualMileageInput(ctx, state, text) },

  // 3) РљРЅРѕРїРєРё РіР»Р°РІРЅРѕРіРѕ РјРµРЅСЋ
  { button: BUTTONS.punchTime, legacy: ['Р’СЂРµРјСЏ СЃРјРµРЅС‹', 'Р’РЅРµСЃС‚Рё РІСЂРµРјСЏ СЃРјРµРЅС‹', 'вЏ± Р’СЂРµРјСЏ'], handler: (ctx) => punchTimeFlow(ctx) },
  { button: BUTTONS.mileage, legacy: ['Р’РЅРµСЃС‚Рё РїСЂРѕР±РµРі', 'рџљ— РџСЂРѕР±РµРі'], handler: (ctx) => mileageFlow(ctx) },
  { button: BUTTONS.routeSheet, legacy: ['РњР°СЂС€СЂСѓС‚РЅС‹Р№ Р»РёСЃС‚', 'рџ“„ РњР°СЂС€СЂСѓС‚РЅРёРє'], handler: (ctx) => routeSheetFlow(ctx) },
  { button: BUTTONS.reconciliation, legacy: ['РЎРІРµСЂРєРё', 'рџ“Љ РЎРІРµСЂРєРё'], handler: (ctx) => reconciliationFlow(ctx) },
  { button: BUTTONS.cashCheck, legacy: ['Р”РµРЅСЊРіРё Рє СЃРґР°С‡Рµ', 'рџ’µ РќР°Р»РёС‡РЅС‹Рµ'], handler: (ctx) => showPendingCashStatus(ctx) },
  { button: BUTTONS.issues, legacy: ['РџСЂРѕР±Р»РµРјР° СЃ Р·Р°РєР°Р·РѕРј', 'вљ пёЏ РџСЂРѕР±Р»РµРјР°'], handler: (ctx) => showIssuesMenu(ctx) },
  { button: BUTTONS.leaderBoard, legacy: ['Р›РёРґРµСЂР±РѕСЂРґ', 'рџЏ† Р›РёРґРµСЂР±РѕСЂРґ'], handler: (ctx) => showLeaderboardMenu(ctx) },
  { button: BUTTONS.cashCollect, handler: (ctx) => showDebtorsList(ctx) },
  { button: BUTTONS.openShop, handler: (ctx) => openShopNotify(ctx) },

  // 4) РњРµРЅСЋ РЅР°СЃС‚СЂРѕРµРє
  { button: BUTTONS.settings, legacy: ['РќР°СЃС‚СЂРѕР№РєРё'], handler: async (ctx, s, text, id) => ctx.replyWithHTML('вљ™пёЏ <b>РќР°СЃС‚СЂРѕР№РєРё</b>', getSettingsMenuForRole(id)) },
  { button: BUTTONS.profile, legacy: ['РџСЂРѕС„РёР»СЊ'], handler: async (ctx, s, text, id) => ctx.replyWithHTML('вњЏпёЏ <b>РџСЂРѕС„РёР»СЊ</b>', getProfileMenuForRole(ctx.from.id)) },
  { button: BUTTONS.help, legacy: ['РџРѕРјРѕС‰СЊ'], handler: (ctx) => sendHelp(ctx) },

  // 5) РџСЂРѕС„РёР»СЊ (С‚СЂРµР±СѓСЋС‚ Р¤РРћ)
  { button: BUTTONS.changeCar, legacy: ['РР·РјРµРЅРёС‚СЊ РЅРѕРјРµСЂ РјР°С€РёРЅС‹', 'РќРѕРјРµСЂ РјР°С€РёРЅС‹'], handler: async (ctx) => {
    if (isLogist(ctx.from.id)) {
      await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
      return;
    }
    const fio = await requireFio(ctx);
    if (fio) await askForCarNumber(ctx, fio);
  }},
  { button: BUTTONS.changeWorkplace, legacy: ['РР·РјРµРЅРёС‚СЊ РёРЅС‚РµСЂРЅРµС‚-РјР°РіР°Р·РёРЅ', 'РџРѕРјРµРЅСЏС‚СЊ РјР°РіР°Р·РёРЅ', 'РњР°РіР°Р·РёРЅ'], handler: async (ctx) => {
    const fio = await requireFio(ctx);
    if (fio) await askForWorkplace(ctx, fio);
  }},
  { button: BUTTONS.changeDevice, legacy: ['РР·РјРµРЅРёС‚СЊ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ', 'РЈСЃС‚СЂРѕР№СЃС‚РІРѕ'], handler: async (ctx) => {
    if (isLogist(ctx.from.id)) {
      await ctx.replyWithHTML('вќЊ Р­С‚Р° С„СѓРЅРєС†РёСЏ РґРѕСЃС‚СѓРїРЅР° С‚РѕР»СЊРєРѕ РєСѓСЂСЊРµСЂР°Рј.', getMenuForRole(ctx.from.id));
      return;
    }
    const fio = await requireFio(ctx);
    if (fio) await askForDevice(ctx, fio);
  }},
  { button: BUTTONS.switchUser, legacy: ['РџРѕРјРµРЅСЏС‚СЊ СЃРѕС‚СЂСѓРґРЅРёРєР°', 'РЎРјРµРЅРёС‚СЊ СЃРѕС‚СЂСѓРґРЅРёРєР°', 'РЎРѕС‚СЂСѓРґРЅРёРє'], handler: handleSwitchUser },

  // 6) РќР°СЃС‚СЂРѕР№РєРё (РўР°Р±Р»РёС†С‹, РњРѕР№ ID, РСЃС‚РѕСЂРёСЏ СЃР±РѕСЂРѕРІ)
  { button: BUTTONS.sheetInfo, legacy: ['РўР°Р±Р»РёС†С‹'], handler: handleSheetsInfo },
  { button: BUTTONS.myId, legacy: ['РњРѕР№ ID'], handler: handleMyId },
  { button: BUTTONS.cashHistory, handler: (ctx) => showCashHistory(ctx) }
];

function matchTextRoute(route, text, state) {
  if (typeof route.match === 'function' && route.match(text, state)) return true;
  if (route.state && state?.[route.state]) return true;
  if (route.button) {
    if (text === route.button) return true;
    if (Array.isArray(route.legacy) && route.legacy.includes(text)) return true;
  }
  return false;
}

bot.on('text', async (ctx) => {
  const telegramId = ctx.from.id;
  const text = ctx.message.text.trim();
  const state = getState(telegramId);

  for (const route of TEXT_ROUTES) {
    if (matchTextRoute(route, text, state)) {
      return route.handler(ctx, state, text, telegramId);
    }
  }

  // Fallback: С‚РµРєСЃС‚ РЅРµ РїРѕРґРѕС€С‘Р» РЅРё РїРѕРґ РѕРґРЅСѓ РІРµС‚РєСѓ
  await ctx.replyWithHTML('Р’С‹Р±РµСЂРёС‚Рµ РґРµР№СЃС‚РІРёРµ РІ РјРµРЅСЋ РёР»Рё РёСЃРїРѕР»СЊР·СѓР№С‚Рµ /help.', getMenuForRole(telegramId));
});

bot.catch((error, ctx) => {
  console.error('bot error', error.message);
});

process.on('uncaughtException', (error) => {
  console.error('uncaught exception:', error);
  shutdown('uncaughtException');
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('unhandled rejection:', reason);
  shutdown('unhandledRejection');
  process.exit(1);
});

const LAUNCH_RETRIES = LIMITS.LAUNCH_RETRIES;
const LAUNCH_BASE_DELAY = LIMITS.LAUNCH_BASE_DELAY_MS;
const LAUNCH_MAX_DELAY = LIMITS.LAUNCH_MAX_DELAY_MS;

// Р“Р»РѕР±Р°Р»СЊРЅС‹Рµ С‚Р°Р№РјРµСЂС‹ вЂ” С…СЂР°РЅРёРј, С‡С‚РѕР±С‹ РїСЂРё СЂРµС‚СЂР°Рµ РЅРµ РїР»РѕРґРёС‚СЊ РґСѓР±Р»РёРєР°С‚С‹
let _backupInitialTimer = null;
let _backupIntervalTimer = null;

async function setupBotCommands() {
  try {
    await bot.telegram.setMyCommands([
      { command: 'start', description: 'РќР°С‡Р°С‚СЊ СЂР°Р±РѕС‚Сѓ' },
      { command: 'help', description: 'РџРѕРјРѕС‰СЊ' },
      { command: 'car', description: 'РР·РјРµРЅРёС‚СЊ РЅРѕРјРµСЂ РјР°С€РёРЅС‹' },
      { command: 'workplace', description: 'РР·РјРµРЅРёС‚СЊ РјР°РіР°Р·РёРЅ' },
      { command: 'device', description: 'РР·РјРµРЅРёС‚СЊ СѓСЃС‚СЂРѕР№СЃС‚РІРѕ' },
      { command: 'cancel', description: 'РћС‚РјРµРЅР°' },
      { command: 'role', description: 'РЎРјРµРЅРёС‚СЊ СЂРѕР»СЊ (Р°РґРјРёРЅ)' }
    ], { scope: { type: 'all_private_chats' } });
  } catch (e) {
    console.error('setMyCommands private error', e.message);
  }

  // Р§РёСЃС‚РёРј РєРѕРјР°РЅРґС‹ РґР»СЏ РіСЂСѓРїРї/Р°РґРјРёРЅРѕРІ/РґРµС„РѕР»С‚Р° (Р±РѕС‚ РїСЂРµРґРЅР°Р·РЅР°С‡РµРЅ С‚РѕР»СЊРєРѕ РґР»СЏ РїСЂРёРІР°С‚РѕРІ)
  await Promise.all([
    bot.telegram.deleteMyCommands({ scope: { type: 'all_group_chats' } })
      .catch((e) => console.error('deleteMyCommands group error', e.message)),
    bot.telegram.deleteMyCommands({ scope: { type: 'all_chat_administrators' } })
      .catch((e) => console.error('deleteMyCommands admins error', e.message)),
    bot.telegram.deleteMyCommands()
      .catch((e) => console.error('deleteMyCommands default error', e.message))
  ]);
}

async function startBot(retry = 0) {
  if (process.env.BOT_DISABLED === 'true') {
    console.log('bot disabled вЂ” .env BOT_DISABLED=true');
    return;
  }
  try {
    const { version, changed, changedFiles, updates } = checkVersion();
    initGoogleSheets();
    const removedMonths = cleanupOldMonths();
    if (removedMonths > 0) {
      console.log(`cleaned up ${removedMonths} old month(s) from storage`);
    }

    // РђРІС‚РѕРјР°С‚РёС‡РµСЃРєР°СЏ РіРµРЅРµСЂР°С†РёСЏ С‡РµР»Р»РµРЅРґР¶РµР№ РґР»СЏ РІСЃРµС… РєСѓСЂСЊРµСЂРѕРІ
    try {
      const allIds = getAllUserIds();
      let generated = 0;
      for (const id of allIds) {
        const role = getUserRole(id);
        if (role !== 'courier') continue;
        const profile = getFullProfile(id);
        if (!profile.courierType) continue;
        generateWeeklyChallenges(id, profile.courierType);
        generated++;
      }
      if (generated > 0) {
        console.log(`weekly challenges generated for ${generated} couriers`);
      }
    } catch (e) {
      console.error('weekly challenges generation error', e.message);
    }

    // Р’РђР–РќРћ: РІ Telegraf 4 Сѓ bot.launch() РЅРµС‚ РєРѕР»Р»Р±СЌРєР° РїРѕСЃР»Рµ СЃС‚Р°СЂС‚Р° вЂ” РѕРЅ
    // РїСЂРёРЅРёРјР°РµС‚ options-РѕР±СЉРµРєС‚. Р Р°РЅСЊС€Рµ РєРѕРґ РІРЅСѓС‚СЂРё () => {...} РЅРёРєРѕРіРґР° РЅРµ
    // РІС‹РїРѕР»РЅСЏР»СЃСЏ, РїРѕСЌС‚РѕРјСѓ РЅР° РїСЂРѕРґРµ РЅРµ Р±С‹Р»Рѕ setMyCommands Рё Р°РІС‚Рѕ-Р±СЌРєР°РїРѕРІ.
    // РўРµРїРµСЂСЊ РІСЃС‘ СЌС‚Рѕ РІС‹РЅРµСЃРµРЅРѕ РЅР°СЂСѓР¶Сѓ.

    // РљРѕРјР°РЅРґС‹ Telegram Рё СЃС‚РёРєРµСЂРїР°РєРё вЂ” fire-and-forget РґРѕ launch
    setupBotCommands().catch((e) => console.error('setupBotCommands fatal', e.message));
    importConfiguredFunStickerSets({ telegram: bot.telegram }).catch((error) => {
      console.error('fun sticker import fatal', error.message || error);
    });

    // Р‘СЌРєР°РїС‹ вЂ” С‚РѕР»СЊРєРѕ РїСЂРё РїРµСЂРІРѕРј Р·Р°РїСѓСЃРєРµ, С‡С‚РѕР±С‹ СЂРµС‚СЂР°Рё РЅРµ РїР»РѕРґРёР»Рё С‚Р°Р№РјРµСЂС‹
    if (retry === 0) {
      if (_backupInitialTimer) clearTimeout(_backupInitialTimer);
      if (_backupIntervalTimer) clearInterval(_backupIntervalTimer);
      _backupInitialTimer = setTimeout(() => {
        runBackupCycle().catch((e) => console.error('initial backup error', e.message));
      }, 5000);
      _backupIntervalTimer = setInterval(() => {
        runBackupCycle().catch((e) => console.error('backup cycle error', e.message));
      }, BACKUP_INTERVAL_MS);
      _backupInitialTimer.unref?.();
      _backupIntervalTimer.unref?.();
    }

    // РЈРІРµРґРѕРјР»РµРЅРёРµ Р°РґРјРёРЅР°Рј РѕР± РѕР±РЅРѕРІР»РµРЅРёРё вЂ” С‚РѕР»СЊРєРѕ РїСЂРё changed && РїРµСЂРІРѕРј Р·Р°РїСѓСЃРєРµ
    if (changed && retry === 0) {
      setTimeout(() => {
        askAdminsAboutUpdate(version, changedFiles, updates).catch((error) => {
          console.error('admin update ask fatal', error.message || error);
        });
      }, 3000);
    }

    // bot.launch() РІРѕР·РІСЂР°С‰Р°РµС‚ Promise, РєРѕС‚РѕСЂС‹Р№ СЂРµР·РѕР»РІРёС‚СЃСЏ С‚РѕР»СЊРєРѕ РїСЂРё stop().
    // РќР• СЃС‚Р°РІРёРј await вЂ” РёРЅР°С‡Рµ РІСЃС‘, С‡С‚Рѕ РїРѕСЃР»Рµ, РЅРµ РІС‹РїРѕР»РЅРёС‚СЃСЏ.
    bot.launch();
    console.log(`bot started v${version}${changed ? ' (updated)' : ''}`);
  } catch (error) {
    const delay = Math.min(LAUNCH_BASE_DELAY * Math.pow(2, retry), LAUNCH_MAX_DELAY);
    console.error(`bot launch error (attempt ${retry + 1}/${LAUNCH_RETRIES}):`, error?.message || error);
    if (retry < LAUNCH_RETRIES) {
      console.error(`retrying in ${delay / 1000}s ...`);
      setTimeout(() => startBot(retry + 1), delay);
    } else {
      console.error('max launch retries reached, exiting');
      process.exit(1);
    }
  }
}

startBot();

let _shutdownInProgress = false;

function flushAllSync() {
  try { flushStateNow(); } catch (e) { console.error('flushStateNow failed', e.message); }
  try { flushStorageNow(); } catch (e) { console.error('flushStorageNow failed', e.message); }
  try { flushFunReactionsNow(); } catch (e) { console.error('flushFunReactionsNow failed', e.message); }
  try { flushLeaderboardNow(); } catch (e) { console.error('flushLeaderboardNow failed', e.message); }
}

function shutdown(signal) {
  if (_shutdownInProgress) return;
  _shutdownInProgress = true;

  console.log(`shutdown initiated by ${signal}`);
  try {
    checkpoint();
  } catch (_) {}
  flushAllSync();

  try {
    makeBackupSync('pre-shutdown');
  } catch (e) {
    console.error('pre-shutdown backup failed', e.message);
  }

  try {
    bot.stop(signal);
  } catch (e) {
    console.error('bot.stop failed', e.message);
  }
}

function makeBackupSync(reason = 'auto') {
  const now = new Date();
  const ts = now.toISOString().replace(/[.:]/g, '-');
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
  try {
    checkpoint();
  } catch (_) {}
  for (const filename of BACKUP_FILES) {
    const src = path.join(__dirname, filename);
    const dst = path.join(BACKUP_DIR, `${filename.replace('.json', '')}-${reason}-${ts}.json`);
    try {
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, dst);
      }
    } catch (_) {}
  }
}

process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));
// SIGUSR2 вЂ” pm2 graceful reload Рё nodemon restart. Р‘РµР· СЌС‚РѕРіРѕ С…СѓРєР° РїРµСЂРµР·Р°РїСѓСЃРєРё
// РІ dev/staging РјРѕРіР»Рё С‚РµСЂСЏС‚СЊ in-memory state Рё РЅРµРґРѕР·Р°РїРёСЃР°РЅРЅС‹Рµ РґР°РЅРЅС‹Рµ.
process.once('SIGUSR2', () => shutdown('SIGUSR2'));
// beforeExit вЂ” РїРѕСЃР»РµРґРЅРёР№ С€Р°РЅСЃ СЃРѕС…СЂР°РЅРёС‚СЊ РґР°РЅРЅС‹Рµ РїСЂРё С€С‚Р°С‚РЅРѕРј РІС‹С…РѕРґРµ.
process.on('beforeExit', () => {
  if (_shutdownInProgress) return;
  flushAllSync();
});

```

