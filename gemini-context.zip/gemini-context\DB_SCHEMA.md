# Схема базы данных (SQLite)

База данных: `database.sqlite`
Режим: WAL (Write-Ahead Logging)
Резервное копирование: автоматическое каждый час в папку `backups/`, хранение 7 дней.
При corruption: восстановление из последнего валидного бэкапа (integrity_check).

---

## Таблицы

### 1. `users` — профили пользователей

```sql
CREATE TABLE IF NOT EXISTS users (
  telegramId TEXT PRIMARY KEY,
  data TEXT
);
```

- **telegramId**: ID пользователя в Telegram (строка, PK).
- **data**: JSON-объект с полным профилем:
  ```json
  {
    "fio": "Иванов Иван Иванович",
    "carNumber": "А123БС77",
    "workplace": "ИМ Восток",
    "device": "Терминал",
    "role": "courier",
    "courierType": "auto",
    "sheetAccess": true,
    "notificationSettings": { "leaderboard": true, "overtake": true },
    "monthlySheets": {
      "east": { "2026-05": "sheetId1", "2026-06": "sheetId2" },
      "center": { "2026-05": "sheetId3" }
    }
  }
  ```

### 2. `states` — состояния диалога

```sql
CREATE TABLE IF NOT EXISTS states (
  telegramId TEXT PRIMARY KEY,
  data TEXT
);
```

- **data**: JSON с текущим шагом диалога. Примеры step:
  - `auth` — ожидание ФИО
  - `awaiting_car_number` — ожидание номера машины
  - `awaiting_workplace` — выбор магазина
  - `awaiting_device` — выбор устройства
  - `awaiting_mileage_photo` — ожидание фото одометра
  - `awaiting_route_photo` — ожидание фото маршрутного листа
  - `awaiting_recon_photo` — ожидание первого фото сверки
  - `awaiting_recon_photo2` — ожидание второго фото сверки (для Терминала)
  - `awaiting_manual_mileage` — ожидание ручного ввода пробега
  - `awaiting_manual_time` — ожидание ручного ввода времени
  - `awaiting_cash_amount` — ожидание суммы наличных
  - `awaiting_self_clearance` — ожидание подтверждения самостоятельной сдачи

### 3. `leaderboard` — рейтинговая таблица

```sql
CREATE TABLE IF NOT EXISTS leaderboard (
  telegramId TEXT PRIMARY KEY,
  data TEXT
);
```

- **data**: JSON:
  ```json
  {
    "fio": "Иванов И.И.",
    "workplace": "ИМ Восток",
    "courierType": "auto",
    "dailyOrders": {
      "2026-05-22": 42,
      "2026-05-21": 38
    }
  }
  ```

### 4. `cash_audit` — аудит операций с наличными

```sql
CREATE TABLE IF NOT EXISTS cash_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL,
  logistId TEXT,
  logistFio TEXT,
  courierId TEXT NOT NULL,
  courierFio TEXT NOT NULL,
  workplace TEXT NOT NULL,
  amount REAL NOT NULL,
  action TEXT NOT NULL
);
```

- **action**: `reminded`, `approved`, `self_cleared`, `declined`, `logist_approved`

### 5. `pending_cash` — наличные к сдаче

```sql
CREATE TABLE IF NOT EXISTS pending_cash (
  telegramId TEXT PRIMARY KEY,
  amount REAL NOT NULL DEFAULT 0,
  formatted TEXT,
  orders INTEGER,
  workplace TEXT,
  sourceLabel TEXT,
  confirmationStatus TEXT,
  updatedAt TEXT,
  fileId TEXT
);

CREATE INDEX IF NOT EXISTS idx_pending_cash_workplace ON pending_cash(workplace);
```

- **amount**: сумма в рублях (например, 12897.27)
- **formatted**: строковое представление (например, "12 897,27")
- **confirmationStatus**: `null` | `pending` | `confirmed` | `self_clearance`
- **sourceLabel**: откуда пришла сумма (например, "сверка" или "вручную")

### 6. `xp_log` — лог начисления XP

```sql
CREATE TABLE IF NOT EXISTS xp_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  telegramId TEXT,
  amount INTEGER,
  reason TEXT,
  createdAt TEXT
);
```

### 7. `user_achievements` — разблокированные достижения

```sql
CREATE TABLE IF NOT EXISTS user_achievements (
  telegramId TEXT,
  achievementId TEXT,
  unlockedAt TEXT,
  PRIMARY KEY (telegramId, achievementId)
);
```

### 8. `challenges` — еженедельные челленджи

```sql
CREATE TABLE IF NOT EXISTS challenges (
  weekId TEXT,
  telegramId TEXT,
  type TEXT,
  target INTEGER,
  current INTEGER DEFAULT 0,
  completed INTEGER DEFAULT 0,
  reward INTEGER,
  PRIMARY KEY (weekId, telegramId, type)
);
```

### 9. `streaks` — стрик смен

```sql
CREATE TABLE IF NOT EXISTS streaks (
  telegramId TEXT PRIMARY KEY,
  currentStreak INTEGER,
  maxStreak INTEGER,
  lastShiftDate TEXT
);
```

---

## Миграции

Все старые JSON-файлы (`users.json`, `states.json`, `leaderboard-cache.json`) автоматически мигрируются в SQLite при первом запуске и переименовываются в `*.migrated`.
Также `pendingCashToSubmit` из `users.data` мигрируется в отдельную таблицу `pending_cash`.
