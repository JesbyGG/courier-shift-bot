# Архитектура Courier Shift Bot

## Общая информация

- **Название**: courier-shift-bot
- **Версия**: 2.4.1 (автоинкремент patch по хэшу .js файлов)
- **Язык**: Node.js 18+, Telegraf 4.16
- **База данных**: better-sqlite3 (синхронный SQLite, WAL-режим)
- **Google Sheets API**: JWT (google-auth-library)
- **OCR**: RapidOCR (локальный Python HTTP сервер, порт 9527) + Gemini Vision fallback
- **Развёртывание**: PM2 на VPS Ubuntu
- **Текущая ветка Git**: main, последний коммит 9b24682

---

## Роли пользователей

| Роль | Описание | Ключевые функции |
|------|----------|------------------|
| `courier` | Курьер | Время смены, пробег, маршрутный лист, сверка, сдача наличных, рейтинг, XP |
| `logist` | Логист | Время смены, открытие магазина, приём наличных от курьеров, история сборов |
| `admin` | Администратор (из ADMIN_IDS) | /sheet, /sheet_access, /chatid, уведомления о новых пользователях и обновлениях |

---

## Магазины и устройства

### Магазины (WORKPLACES)
- **ИМ Восток** (`east`) — cashCollection: true, leaderboard: true
- **ИМ Центр** (`center`) — cashCollection: false, leaderboard: true

### Устройства (DEVICES)
- **Терминал** — сверка требует 2 фото (терминал + пин-панель)
- **Пин-Панель** — сверка требует 1 фото

### Типы курьеров (courierType)
- `auto` — обычный курьер на машине (видит пробег, вводит номер машины)
- `pedestrian` — пеший курьер (не видит пробег, не вводит номер машины)

---

## Структура проекта

```
├── bot.js                    # Точка входа (~5200 строк). Все обработчики Telegram,
│                             # сценарии диалогов, роутинг inline-кнопок.
│                             # Состояния диалога через SQLite (states).
│
├── config.js                 # ЕДИНАЯ ТОЧКА ИСТИНЫ. Константы:
│                             # WORKPLACES, DEVICES, ROLES, WORKPLACE_KEY_MAP,
│                             # WORKPLACE_FEATURES, LIMITS, SHEET_TEMPLATE, BUTTONS.
│
├── db.js                     # Инициализация SQLite database.sqlite,
│                             # WAL-режим, integrity_check, восстановление из backups/,
│                             # миграция из старых JSON (users.json, states.json,
│                             # leaderboard-cache.json → SQLite).
│                             # Таблицы: users, states, leaderboard, cash_audit,
│                             # pending_cash, xp_log, user_achievements, challenges, streaks.
│
├── utils.js                  # Чистые функции: normalizeFio, getColumnLetter,
│                             # getCourierColumnsByDay, getMileageColumnsByDay,
│                             # roundMinutesToHalfHour, getCurrentDateInfo,
│                             # isEmptyCell, isScheduleMarker.
│
├── sheetCommand.js           # Команда /sheet для админов: привязка Google-таблиц
│                             # по магазинам и месяцам (active/next/YYYY-MM).
│
├── logger.js                 # Простой логгер в файл.
│
├── ecosystem.config.js       # PM2 конфигурация.
│
├── services/
│   ├── googleSheets.js       # JWT-аутентификация, поиск курьера по ФИО,
│   │                         # запись времени/пробега/эффективности.
│   │                         # Retry-логика (429, 5xx). НЕ appendRow, только update.
│   ├── storage.js            # CRUD пользователей, pending_cash, reminders,
│   │                         # sheet-привязки по месяцам, cash audit, debtors,
│   │                         # logist-профили.
│   ├── mileageOcr.js         # Скачивание фото из Telegram, вызов RapidOCR,
│   │                         # fallback Gemini Vision, валидация результата.
│   ├── ocrDebug.js           # Сохранение debug-изображений OCR.
│   ├── leaderboard.js        # Рейтинг курьеров по заказам, TOP-3, обгон,
│   │                         # уведомления о достижениях.
│   ├── xp.js                 # XP-система: начисление XP за действия, ранги,
│   │                         # прогресс до следующего ранга.
│   ├── achievements.js       # Достижения (майлстоуны), проверка разблокировки.
│   ├── streak.js             # Стрик смен (последовательные рабочие дни).
│   ├── challenges.js         # Еженедельные челленджи (цели на неделю).
│   └── auth.js               # Проверка ADMIN_IDS, isAdminUser().
│
├── menus/
│   └── keyboards.js          # Все reply-клавиатуры (mainMenu, courierMainMenu,
│                             # logistMainMenu, profileMenu и т.д.) и inline-кнопки
│                             # (skipMileageKeyboard, mileageConfirmKeyboard,
│                             # replaceKeyboard, debtorListKeyboard и др.).
│
├── tests/
│   ├── utils.test.js
│   ├── normalizeTime.test.js
│   ├── parseMileage.test.js
│   ├── extractCash.test.js
│   └── run.js                # Кастомный раннер на чистом assert.
│
├── docs/
│   ├── generate.js           # Генерация документации.
│   └── Telegram-бот.docx     # Пользовательская инструкция.
│
├── scripts/                  # .bat и .sh скрипты для управления ботом.
├── debug/
│   └── ocr_debug.py          # Python-скрипт для дебага OCR.
├── rapidocr_server.py        # Отдельный Python HTTP-сервер RapidOCR (порт 9527).
├── backups/                  # Автобэкапы SQLite и JSON (7 дней).
├── database.sqlite           # Основная БД.
├── version.json              # Версия, хэши файлов, gitHash, changelog.
├── changelog.json            # Метаданные bump'ов.
├── .env                      # Переменные окружения (секреты).
├── .env.example              # Шаблон .env с описанием всех переменных.
├── package.json              # Зависимости.
├── README.md                 # Полная документация для человека.
└── fun-reactions.json        # Сохранённые file_id стикеров/GIF.
```

---

## Зависимости (package.json)

| Пакет | Версия | Назначение |
|-------|--------|------------|
| `telegraf` | ^4.16.3 | Telegram Bot API |
| `better-sqlite3` | ^12.10.0 | Синхронный SQLite |
| `google-auth-library` | ^9.15.1 | JWT для Google Sheets API |
| `axios` | ^1.7.9 | HTTP-запросы (OCR, Telegram files) |
| `dotenv` | ^16.4.7 | .env конфигурация |
| `https-proxy-agent` | ^7.0.6 | HTTP/HTTPS прокси для Telegram |
| `socks-proxy-agent` | ^8.0.5 | SOCKS5 прокси для Telegram |
| `docx` | ^9.6.1 | Генерация Word-документов |

---

## Система версий

- Версия хранится в `version.json`.
- При старте бот вычисляет SHA256-хэш всех `.js` файлов.
- Если хэш изменился → patch-версия увеличивается (`2.4.1 → 2.4.2`).
- Bump-тип определяется по `changelog.json` (`major`, `minor`, `patch`).
- Git-история используется для генерации release notes на русском (`feat → ✨ Добавлено`, `fix → 🔧 Исправлено` и т.д.).
- Новая версия рассылается всем пользователям с inline-кнопками (Отправить / Изменить / Пропустить).
