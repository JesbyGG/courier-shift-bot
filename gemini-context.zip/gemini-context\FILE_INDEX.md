# Индекс файлов проекта

> Полный список всех файлов исходного кода (без node_modules, venv, test_photos, backups).

## Корневые файлы

| Файл | Размер | Описание |
|------|--------|----------|
| `bot.js` | ~197 KB | **Точка входа**. Все обработчики Telegram (~5200 строк). Сценарии диалогов, inline-кнопки, роутинг, версионирование, OCR background processing, cash flow, геймификация. |
| `config.js` | ~4.4 KB | **Единая точка истины**. WORKPLACES, DEVICES, ROLES, WORKPLACE_KEY_MAP, WORKPLACE_FEATURES, LIMITS, SHEET_TEMPLATE, BUTTONS. |
| `db.js` | ~10 KB | Инициализация SQLite, WAL, integrity_check, восстановление из backups, миграции из JSON. |
| `utils.js` | ~4.2 KB | Чистые функции: normalizeFio, getColumnLetter, округление времени, isEmptyCell, isScheduleMarker. |
| `sheetCommand.js` | ~13.5 KB | Команда /sheet для админов: привязка Google-таблиц по магазинам и месяцам. |
| `logger.js` | ~1.1 KB | Простой логгер в файл с rotation. |
| `ecosystem.config.js` | ~0.8 KB | PM2 конфигурация. |
| `fix_db.js` | ~0.6 KB | Скрипт починки БД. |
| `check_tables.js` | ~0.6 KB | Диагностика таблиц SQLite. |
| `package.json` | ~0.6 KB | Зависимости. |
| `version.json` | ~3.5 KB | Версия 2.4.1, хэши файлов, gitHash, changelog. |
| `changelog.json` | ~0.02 KB | Метаданные bump'ов. |
| `README.md` | ~22 KB | Полная документация для человека. |
| `.env.example` | ~4.9 KB | Шаблон .env со всеми переменными. |

## services/

| Файл | Размер | Описание |
|------|--------|----------|
| `services/googleSheets.js` | ~20.3 KB | JWT-аутентификация, поиск курьера, запись времени/пробега/эффективности, retry. |
| `services/storage.js` | ~13.6 KB | CRUD пользователей, pending_cash, reminders, sheet-привязки, cash audit, debtors. |
| `services/mileageOcr.js` | ~11.7 KB | Скачивание фото, RapidOCR, Gemini Vision fallback, валидация, concurrency queue. |
| `services/ocrDebug.js` | ~5.5 KB | Сохранение debug-изображений OCR. |
| `services/leaderboard.js` | ~7.6 KB | Рейтинг, TOP-3, обгон, уведомления. |
| `services/xp.js` | ~3.7 KB | XP-система, ранги, прогресс. |
| `services/achievements.js` | ~7.5 KB | Достижения (майлстоуны). |
| `services/streak.js` | ~1.5 KB | Стрик смен. |
| `services/challenges.js` | ~4.2 KB | Еженедельные челленджи. |
| `services/auth.js` | ~0.5 KB | Проверка ADMIN_IDS. |

## menus/

| Файл | Размер | Описание |
|------|--------|----------|
| `menus/keyboards.js` | ~7.5 KB | Все reply и inline клавиатуры для курьеров и логистов. |

## tests/

| Файл | Размер | Описание |
|------|--------|----------|
| `tests/utils.test.js` | ~7.8 KB | Тесты utils.js (141 кейс). |
| `tests/normalizeTime.test.js` | ~3.2 KB | Тесты округления времени. |
| `tests/parseMileage.test.js` | ~4.1 KB | Тесты парсинга пробега. |
| `tests/extractCash.test.js` | ~4.5 KB | Тесты извлечения наличных из текста. |
| `tests/run.js` | ~5.2 KB | Кастомный раннер на чистом assert. |

## Python/OCR

| Файл | Размер | Описание |
|------|--------|----------|
| `rapidocr_server.py` | ~30.4 KB | Локальный HTTP-сервер RapidOCR на Python (порт 9527). |
| `ocr_debug.py` | ~4.7 KB | Скрипт дебага OCR. |
| `ocr_diagnose.py` | ~3.7 KB | Диагностика OCR. |
| `ocr_full_debug.py` | ~10.3 KB | Полный дебаг OCR с визуализацией. |

## Скрипты управления

| Файл | Описание |
|------|----------|
| `scripts/start.bat` | Запуск бота |
| `scripts/stop.bat` | Остановка бота |
| `scripts/restart.bat` | Перезапуск бота |
| `scripts/status.bat` | Проверка статуса |
| `scripts/backup-now.bat` | Ручной бэкап |
| `scripts/deploy.bat` | Деплой на VPS |
| `scripts/setup-vps.sh` | Настройка VPS |

## Прочее

| Файл/Папка | Описание |
|------------|----------|
| `docs/` | Документация и generate.js |
| `backups/` | Автобэкапы SQLite и JSON |
| `debug/` | Скрипты дебага |
| `database.sqlite` | Основная БД (84 KB) |
| `fun-reactions.json` | Сохранённые file_id стикеров/GIF |
| `pending_updates.json` | Ожидающие обновления версий |
