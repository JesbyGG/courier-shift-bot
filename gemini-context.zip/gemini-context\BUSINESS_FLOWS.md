# Бизнес-процессы и потоки данных

## 1. Регистрация пользователя (/start)

```
/start → бот проверяет, есть ли пользователь в БД
  ├── Новый пользователь:
  │     → inline-кнопки выбора роли (Курьер / Логист)
  │     → если Курьер: inline выбор courierType (Авто / Пешком)
  │     → state = "auth", запрос ФИО
  │     → пользователь вводит ФИО → normalizeFio() → поиск в Google Sheets
  │     → если найден: state = "awaiting_car_number" (или сразу "awaiting_workplace" для пешего)
  │     → номер машины → магазин (inline кнопки ИМ Восток/ИМ Центр) → устройство (Терминал/Пин-Панель)
  │     → профиль сохранён, показывается главное меню по роли
  │
  └── Существующий:
        → показывается главное меню по роли
```

### Нормализация ФИО
- `normalizeFio()`: trim, сжатие пробелов, ё→е, toLowerCase
- `normalizeFioWords()`: + сортировка слов (для поиска в любом порядке)

---

## 2. Время смены (⏱ Записать время)

```
Кнопка "Записать время" → bot.js punchTimeHandler()
  → getCurrentDateInfo() → текущий день месяца
  → prepareMileage() / prepareTime() в googleSheets.js
     → findCourierInAllSheets() — поиск по ФИО в листе "Курьеры"
     → SHEET_CONFIGS: "ИМ Восток" → лист "Курьеры", FIO колонка D
     → Определяем блоки колонок по дню:
        - Курьеры: start=6+3*(day-1), end=7+3*(day-1), hours=8+3*(day-1)
     → Читаем текущие значения ячеек
     → isEmptyCell() проверяет, пуста ли ячейка ('' / null / undefined)
     → isScheduleMarker("1") — маркер графика, пропускаем
  → Если старт пустой:
     → roundTimeToHalfHour() → записываем старт
     → XP + за старт смены
     → updateStreak() — проверка последовательных дней
     → updateChallengeProgress() — обновление челленджей
  → Если старт есть, конец пустой:
     → roundTimeToHalfHour() → записываем конец
     → XP + за конец смены
     → Если есть pending_cash → показываем напоминание "У вас X ₽ к сдаче"
  → Если оба заполнены:
     → inline-кнопки: "Изменить начало" / "Изменить конец"
```

### Округление времени
- `00-14` мин → `H` (для H≤1: `H,0`)
- `15-44` мин → `H,5`
- `45-59` мин → `H+1` (для H+1≤1: `H+1,0`)
- Примеры: `12:14→12`, `12:30→12,5`, `12:45→13`, `00:10→0,0`, `00:50→1,0`

---

## 3. Пробег (🚗 Фото пробега)

```
Кнопка "Фото пробега" → state = "awaiting_mileage_photo"
  → Пользователь отправляет фото одометра
  → bot.js mileagePhotoHandler()
     → Скачивание фото через Telegram API (downloadTelegramFile в mileageOcr.js)
     → Фото пересылается в WORK_CHAT_ID (или WORK_THREAD_ID) с подписью
     → Вызов recognizeMileage() с concurrency=2 (очередь ocrQueue)
        1. RapidOCR (если RAPIDOCR_ENABLED !== 'false'):
           → HTTP POST на RAPIDOCR_URL с base64 изображением
           → Возвращает массив текстовых блоков с confidence
           → Фильтрация: isOdometerNoiseText() отбрасывает km/h, rpm, temp и т.д.
           → Группировка по числам, подсчёт confidence
           → Кандидат должен пройти пороги:
              RAPIDOCR_MIN_COUNT (мин. совпадений)
              RAPIDOCR_MIN_AVG_CONF ≥ 0.40
              RAPIDOCR_MIN_MAX_CONF ≥ 0.50
        2. Если RapidOCR не уверен → fallback Gemini Vision
        3. Валидация:
           - 2-6 цифр
           - ≥ OCR_MIN_MILEAGE (по умолч. 1000)
           - Для конца: end ≥ start и delta ≤ OCR_MAX_SHIFT_DELTA (800)
     → Если распознано уверенно:
        → Сохранение в Google Sheets (лист "Пробег" / "Пробег Курьеры")
        → Колонки: start=4+3*(day-1), end=5+3*(day-1), total=6+3*(day-1)
        → XP + за пробег
        → Inline-кнопка "✏️ Изменить пробег"
     → Если НЕ распознано:
        → inline-кнопки:
           "📷 Загрузить фото повторно"
           "✏️ Ввести вручную"
           "⏭️ Пропустить"
           "🏠 В меню"
     → Background OCR: если пользователь нажал кнопку до завершения OCR,
       результат всё равно сохраняется и показывается при возврате в меню.
```

---

## 4. Маршрутный лист (📄 Отправить маршрутник)

```
Кнопка → state = "awaiting_route_photo"
  → Пользователь отправляет фото (можно несколько подряд)
  → Фото пересылается в ROUTE_SHEET_CHAT_ID (fallback WORK_CHAT_ID)
  → Бот нумерует маршрутный лист: {fio}_{YYYY-MM-DD}_{N}
  → XP + за маршрутный лист
  → Inline-кнопки: "✅ Завершить" / "🏠 В меню"
```

---

## 5. Сверка (📊 Отправить сверку)

```
Кнопка → state = "awaiting_recon_photo"
  → Если device === "Терминал":
     → Ждёт 1-е фото (терминал), сохраняет file_id
     → state = "awaiting_recon_photo2"
     → Ждёт 2-е фото (пин-панель)
  → Если device === "Пин-Панель":
     → Ждёт 1 фото
  → Фото пересылается в RECONCILIATION_CHAT_ID (fallback WORK_CHAT_ID)
  → OCR сверки: распознаёт текст, ищет "Наличные X / Y ₽"
  → Если Y ≥ 1,00 ₽:
     → Сохраняется в pending_cash (amount=Y, sourceLabel="сверка")
     → В подпись к пересланному фото добавляется: "💵 К сдаче в следующую смену: <code>Y</code> ₽"
  → XP + за сверку
```

---

## 6. Сдача наличных (💵 Сдать наличные)

### 6.1. Курьер нажимает "💵 Сдать наличные"
```
→ Проверка pending_cash
  → Если amount < 1: "Нечего сдавать"
  → Если amount ≥ 1:
     → Показывает: "У вас X ₽ к сдаче. Сдали?"
     → Inline-кнопки: "✅ Да, сдал" / "❌ Нет, не сдал" / "🏠 В меню"
     → "Да, сдал":
        → confirmationStatus = 'self_clearance' (ожидает подтверждения логиста)
        → Уведомление логистам этого магазина
     → "Нет, не сдал": оставляет pending_cash без изменений
```

### 6.2. Логист нажимает "💳 Принять наличные"
```
→ Только если WORKPLACE_FEATURES[workplace].cashCollection === true
→ cleanupStaleReminders() — очистка старых напоминаний
→ getDebtors(workplace) — все pending_cash.amount ≥ 1 для этого магазина
→ Показывает список должников с inline-кнопками
   → Если у курьера activeReminders: показывает 🔔(логист1, логист2)
   → Если у курьера selfClearance: показывает ⏳
→ Логист нажимает на курьера:
   → Если selfClearance:
      → Inline-кнопки: "✅ Подтвердить" / "❌ Отклонить"
   → Иначе:
      → pokeCourier() — отправка напоминания курьеру
      → Курьер получает сообщение с кнопками:
         "🏃 Уже бегу" (acknowledge) / "✅ Сдал" (self-clearance)
      → Логист получает подтверждение "Напоминание отправлено"
```

### 6.3. Курьер нажимает "✅ Сдал" на напоминание
```
→ confirmationStatus = 'self_clearance'
→ Уведомление логистам
→ Логист видит ⏳ и может подтвердить или отклонить
```

### 6.4. Подтверждение логистом
```
→ "✅ Подтвердить" (sc_appr_{id}):
   → logCashAction(action='approved')
   → deletePendingCash() — сумма списывается
   → XP + за сдачу наличных
   → updateChallengeProgress() — челленджи
→ "❌ Отклонить" (sc_decl_{id}):
   → confirmationStatus = null (курьер может попробовать снова)
```

---

## 7. Рейтинг и геймификация (🏆)

### 7.1. Leaderboard
- `recordOrders(telegramId, fio, workplace, ordersCount)` — запись заказов за день
- Подсчёт: сумма заказов за текущий день по рабочим дням
- TOP-3, daily leader, workplace record
- Уведомления при обгоне позиций

### 7.2. XP
- `getXpForAction(action)` — XP за действие:
  - start_shift, end_shift, mileage, route_sheet, reconciliation, cash_submit, challenge_complete
- `addXp()` — начисление + лог в xp_log
- `getTotalXp()` → `getRank()` → `getRankProgress()`

### 7.3. Достижения (Achievements)
- `checkMilestoneAchievements()` — проверка при каждом действии
- Майлстоуны: N смен, N км, стрик, сдача наличных и т.д.

### 7.4. Стрик (Streak)
- `updateStreak()` — +1 за каждый рабочий день подряд
- Бонус XP за стрик

### 7.5. Челленджи (Challenges)
- `generateWeeklyChallenges()` — генерируются по понедельникам
- Типы: заказы за неделю, смены за неделю, пробег за неделю и т.д.
- `updateChallengeProgress()` — инкремент current, проверка completion

---

## 8. Команда /sheet (админская)

```
/sheet — показать текущие привязки таблиц
/sheet list — то же
/sheet east active URL — привязать таблицу на активный месяц
/sheet east next URL — привязать на следующий месяц
/sheet east 2026-06 URL — привязать на конкретный месяц
/sheet center URL — автоопределение месяца по названию таблицы
/sheet reset east active — сбросить привязку
/sheet reset all — сбросить все
```

- Привязки хранятся в `users.data.monthlySheets`
- Резолвинг таблицы: monthlySheets → legacy → GOOGLE_SHEET_ID fallback
- Если таблица не привязана на текущий месяц → запись блокируется

---

## 9. Google Sheets: структура

### Лист "Курьеры" (время смен)
- Строка 1-2: заголовки
- Строка 3+: данные курьеров
- Колонка C/D: ФИО (разные магазины используют разные колонки)
- День 1: F=start, G=end, H=hours
- День N: F+3*(N-1)=start, G+3*(N-1)=end, H+3*(N-1)=hours

### Лист "Пробег" / "Пробег Курьеры"
- День 1: D=start, E=end, F=total
- День N: D+3*(N-1)=start, E+3*(N-1)=end, F+3*(N-1)=total

### Лист "Эффективность"
- Аналогичная структура блоков по 3 колонки

---

## 10. Обработка ошибок и retry

### Google Sheets
- `sheetsRequest()` — retry до 3 раз при 429, 5xx, 0
- Экспоненциальная задержка: min(1000 * 2^(attempt-1), 8000) мс

### Telegram
- `LAUNCH_RETRIES` = 10 при старте бота
- `LAUNCH_BASE_DELAY_MS` = 5000, `LAUNCH_MAX_DELAY_MS` = 120000
- Поддержка прокси: HTTP/HTTPS/SOCKS5

### SQLite
- WAL-режим, synchronous=FULL
- Автобэкап каждый час
- При corruption: восстановление из backups/
