require('dotenv').config();
require('./logger').initLogger();

const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { execSync } = require('child_process');

const crypto = require('crypto');

const { Telegraf, Markup } = require('telegraf');
const { HttpsProxyAgent } = require('https-proxy-agent');
const { SocksProxyAgent } = require('socks-proxy-agent');
const {
  initGoogleSheets,
  findCourierInAllSheets,
  punchTime,
  prepareMileage,
  replaceTime,
  updateCourierTime,
  updateMileage,
  readCell,
  getSheetConfig,
  updateEfficiencyOrders
} = require('./services/googleSheets');
const {
  getUserField,
  getFullProfile,
  setUserField,
  getUserRole,
  deleteUser,
  getPendingCash,
  setPendingCash,
  deletePendingCash,
  setCashConfirmationStatus,
  clearPendingCashAndReminders,
  getAllUserIds,
  resolveSheetInfo,
  flushNow: flushStorageNow,
  getSheetAccessUsers,
  addSheetAccessUser,
  removeSheetAccessUser,
  isSheetAccessUser,
  markUserSeen,
  cleanupOldMonths,
  getCurrentMonthKey,
  getNextMonthKey,
  getWorkplaceSheetIdByMonth,
  logCashAction,
  getCashHistory,
  getDebtors,
  findLogistsForWorkplace,
  setReminder,
  getReminder,
  updateReminder,
  deleteReminder,
  getActiveRemindersForCourier,
  getSelfClearanceRequest,
  cleanupStaleReminders
} = require('./services/storage');
const { recognizeMileage, downloadTelegramFile, isRapidOcrEnabled, recognizeTextWithRapidOcr, getMinMileageThreshold, checkRapidOcrHealth } = require('./services/mileageOcr');
const { saveOcrDebugImage, updateOcrDebugStatus } = require('./services/ocrDebug');
const { recordOrders: recordLeaderboardOrders, calculateLeaderboard, formatLeaderboard, checkNotifications: checkLeaderboardNotifications, flushNow: flushLeaderboardNow, getDayOrders: getLbDayOrders, getWorkplaceRecord, setWorkplaceRecord, getDailyTop3, findOvertakenCouriers, getTodayKey: getLbTodayKey } = require('./services/leaderboard');
const { addXp, getTotalXp, getRank, getRankProgress, formatRankInfo, getXpForAction } = require('./services/xp');
const { checkMilestoneAchievements, unlockAchievement, getUnlockedAchievements, getAllAchievements } = require('./services/achievements');
const { updateStreak, getStreak, getStreakBonus } = require('./services/streak');
const { updateChallengeProgress, generateWeeklyChallenges, getChallenges } = require('./services/challenges');
const { getCurrentDateInfo, getColumnLetter, getMileageColumnsByDay, roundMinutesToHalfHour } = require('./utils');
const { registerSheetCommand } = require('./sheetCommand');
const { WORKPLACES, DEVICES, ROLES, LIMITS, WORKPLACE_FEATURES, WORKPLACE_KEY_MAP, BUTTONS } = require('./config');
const { isAdminUser, getAdminIds } = require('./services/auth');
const {
  mainMenu,
  profileMenu,
  workplaceMenu,
  deviceMenu,
  logistMainMenu,
  logistSettingsMenu,
  logistProfileMenu,
  getMenuForRole,
  getSettingsMenuForRole,
  getProfileMenuForRole,
  roleChoiceKeyboard,
  skipMileageKeyboard,
  mileageConfirmKeyboard,
  mileageSavedKeyboard,
  routeSheetKeyboard,
  manualMileageKeyboard,
  replaceKeyboard,
  timeChangeKeyboard,
  mileageReplaceKeyboard,
  switchUserKeyboard,
  cashSubmitConfirmKeyboard,
  debtorListKeyboard
} = require('./menus/keyboards');

const db = require('./db');
const { checkpoint } = require('./db');

function getState(telegramId) {
  const row = db.prepare('SELECT data FROM states WHERE telegramId = ?').get(String(telegramId));
  if (!row) return null;
  try {
    return JSON.parse(row.data);
  } catch {
    return null;
  }
}

function setState(telegramId, state) {
  const stmt = db.prepare('INSERT OR REPLACE INTO states (telegramId, data) VALUES (?, ?)');
  stmt.run(String(telegramId), JSON.stringify(state));
}

function clearState(telegramId) {
  db.prepare('DELETE FROM states WHERE telegramId = ?').run(String(telegramId));
}

function flushStateNow() {
  // SQLite WAL is persistent.
}

const versionPath = path.join(__dirname, 'version.json');
const changelogPath = path.join(__dirname, 'changelog.json');
const _sourceDir = __dirname;

function _getCurrentVersion() {
  try {
    if (!fs.existsSync(versionPath)) {
      return null;
    }
    return JSON.parse(fs.readFileSync(versionPath, 'utf8'));
  } catch {
    return null;
  }
}

function _getSourceFiles() {
  return fs.readdirSync(_sourceDir)
    .filter((f) => f.endsWith('.js') && f !== 'version.js')
    .sort();
}

function _computeSourceSnapshot() {
  const jsFiles = _getSourceFiles();
  const fileHashes = {};
  const combinedHash = crypto.createHash('sha256');
  for (const file of jsFiles) {
    const filePath = path.join(_sourceDir, file);
    try {
      const content = fs.readFileSync(filePath, 'utf8');
      const fileHash = crypto.createHash('sha256').update(content).digest('hex');
      fileHashes[file] = fileHash;
      combinedHash.update(file);
      combinedHash.update(fileHash);
    } catch {
    }
  }
  return {
    hash: combinedHash.digest('hex'),
    files: fileHashes
  };
}

function _getChangedFiles(previousFiles, currentFiles) {
  const prev = previousFiles || {};
  const next = currentFiles || {};
  const allFiles = new Set([...Object.keys(prev), ...Object.keys(next)]);
  return [...allFiles]
    .filter((file) => prev[file] !== next[file])
    .sort();
}

function _getCurrentGitHash() {
  try {
    return execSync('git rev-parse HEAD', { encoding: 'utf8', cwd: __dirname }).trim();
  } catch {
    return null;
  }
}

const COMMIT_PREFIX_RU = {
  feat: '✨ Добавлено',
  fix: '🔧 Исправлено',
  refactor: '♻️ Переработано',
  chore: '🔧 Техническое',
  docs: '📝 Документация',
  style: '🎨 Оформление',
  perf: '⚡ Оптимизация',
  test: '🧪 Тесты',
  build: '📦 Сборка',
  ci: '⚙️ CI/CD',
  revert: '↩️ Откат'
};

function _getGitLogSince(fromHash) {
  if (!fromHash) return null;
  try {
    const log = execSync(`git log --oneline --no-merges ${fromHash}..HEAD`, { encoding: 'utf8', cwd: __dirname });
    return log.split('\n')
      .map(line => line.trim())
      .filter(Boolean)
      .map(line => {
        let msg = line.replace(/^[0-9a-f]+\s+/, '');
        const prefixMatch = msg.match(/^(feat|fix|refactor|chore|docs|style|perf|test|build|ci|revert):\s*/i);
        if (prefixMatch) {
          const prefix = prefixMatch[1].toLowerCase();
          const ruPrefix = COMMIT_PREFIX_RU[prefix] || prefix;
          msg = msg.slice(prefixMatch[0].length);
          msg = msg.charAt(0).toUpperCase() + msg.slice(1);
          return `${ruPrefix}: ${msg}`;
        }
        if (msg.match(/^(\p{Emoji_Presentation}|\p{Extended_Pictographic})\s*/u)) {
          return msg.charAt(0).toUpperCase() + msg.slice(1);
        }
        msg = msg.charAt(0).toUpperCase() + msg.slice(1);
        return msg;
      })
      .filter(msg => msg.length > 0);
  } catch {
    return null;
  }
}

function _bumpVersion(version, bumpType) {
  const parts = version.split('.').map(Number);
  if (bumpType === 'major') {
    parts[0] += 1;
    parts[1] = 0;
    parts[2] = 0;
  } else if (bumpType === 'minor') {
    parts[1] += 1;
    parts[2] = 0;
  } else {
    parts[2] = (parts[2] || 0) + 1;
  }
  return parts.join('.');
}

function checkVersion() {
  const snapshot = _computeSourceSnapshot();
  const currentHash = snapshot.hash;
  const currentFiles = snapshot.files;
  const stored = _getCurrentVersion();
  if (!stored) {
    const initialVersion = '2.0.0';
    const gitHash = _getCurrentGitHash();
    const data = {
      version: initialVersion,
      lastHash: currentHash,
      files: currentFiles,
      updatedAt: new Date().toISOString(),
      gitHash: gitHash || undefined,
      updates: []
    };
    fs.writeFileSync(versionPath, JSON.stringify(data, null, 2), 'utf8');
    return {
      version: initialVersion,
      changed: true,
      prevVersion: null,
      changedFiles: Object.keys(currentFiles).sort(),
      updates: []
    };
  }
  if (stored.lastHash === currentHash) {
    return { version: stored.version, changed: false, prevVersion: null, changedFiles: [], updates: stored.updates || [] };
  }
  const changedFiles = _getChangedFiles(stored.files, currentFiles);
  const bumpType = getChangelogBump();
  const newVersion = _bumpVersion(stored.version, bumpType);
  let updates = _getGitLogSince(stored.gitHash);
  if (!updates || updates.length === 0) {
    updates = null;
  }
  const gitHash = _getCurrentGitHash();
  const data = {
    version: newVersion,
    lastHash: currentHash,
    files: currentFiles,
    updatedAt: new Date().toISOString(),
    gitHash: gitHash || undefined,
    updates: updates || []
  };
  fs.writeFileSync(versionPath, JSON.stringify(data, null, 2), 'utf8');
  console.log(`version bumped: ${stored.version} → ${newVersion} (${bumpType})`);
  return { version: newVersion, changed: true, prevVersion: stored.version, changedFiles, updates: updates || [] };
}

function getVersion() {
  const stored = _getCurrentVersion();
  return stored ? stored.version : '2.0.0';
}



// WORKPLACES, DEVICES — теперь из config.js (см. импорт выше)

function isLogist(telegramId) {
  return getUserRole(telegramId) === 'logist';
}

function requireRole(ctx, requiredRole) {
  const role = getUserRole(ctx.from.id);
  if (requiredRole === 'courier' && role === 'logist') {
    ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return false;
  }
  if (requiredRole === 'logist' && role !== 'logist') {
    ctx.replyWithHTML('❌ Эта функция доступна только логистам.', getMenuForRole(ctx.from.id));
    return false;
  }
  return true;
}

async function showDebtorsList(ctx) {
  const telegramId = ctx.from.id;
  const role = getUserRole(telegramId);
  if (role !== 'logist') {
    await ctx.replyWithHTML('❌ Эта функция доступна только логистам.', getMenuForRole(telegramId));
    return;
  }

  const workplace = getUserField(telegramId, 'workplace');
  if (!workplace) {
    await ctx.replyWithHTML('⚠️ Сначала выберите магазин в настройках.', getSettingsMenuForRole(telegramId));
    return;
  }

  const features = WORKPLACE_FEATURES[workplace];
  if (!features || !features.cashCollection) {
    await ctx.replyWithHTML('❌ В этом магазине приём наличных не предусмотрен.', getMenuForRole(telegramId));
    return;
  }

  cleanupStaleReminders();

  const debtors = getDebtors(workplace);

  if (debtors.length === 0) {
    await ctx.replyWithHTML('✅ Все деньги сданы, долгов нет.', getMenuForRole(telegramId));
    return;
  }

  const totalAmount = debtors.reduce((sum, d) => sum + d.amount, 0);
  const formattedTotal = formatMoneyRu(totalAmount);

  await ctx.replyWithHTML(
    `💳 <b>Курьеры с долгами</b> (${esc(workplace)})\n` +
    `Всего к сдаче: <code>${formattedTotal}</code> ₽\n\n` +
    `Нажмите на курьера, чтобы отправить напоминание:`,
    debtorListKeyboard(debtors, workplace)
  );
}

async function pokeCourier(ctx, courierId) {
  const logistId = ctx.from.id;
  const logistFio = getUserField(logistId, 'fio') || 'Логист';
  const logistWorkplace = getUserField(logistId, 'workplace');
  const courierRecord = getUserField(courierId, 'fio') ? {
    fio: getUserField(courierId, 'fio'),
    workplace: getUserField(courierId, 'workplace')
  } : null;

  if (!courierRecord || !courierRecord.fio) {
    await ctx.answerCbQuery('⚠️ Курьер не найден.');
    return;
  }

  const selfClearance = getSelfClearanceRequest(courierId);
  if (selfClearance) {
    await ctx.answerCbQuery();
    await ctx.replyWithHTML(
      `⏳ ${esc(courierRecord.fio)} уже отметил сдачу.\n` +
      `Ожидает подтверждения: <code>${esc(selfClearance.formatted || String(selfClearance.amount))}</code> ₽`,
      Markup.inlineKeyboard([
        [Markup.button.callback('✅ Подтвердить', `sc_appr_${courierId}`)],
        [Markup.button.callback('❌ Отклонить', `sc_decl_${courierId}`)]
      ])
    );
    return;
  }

  const pendingCash = getPendingCash(courierId);
  const amount = Number(pendingCash?.amount || 0);
  if (!Number.isFinite(amount) || amount < 1) {
    await ctx.answerCbQuery('✅ Курьер уже сдал деньги.');
    if (ctx.callbackQuery) {
      try { await ctx.editMessageText('✅ Курьер уже сдал деньги.'); } catch (e) { /* ignore */ }
    }
    return;
  }

  const formatted = pendingCash?.formatted || formatMoneyRu(amount);
  const shortId = crypto.randomBytes(4).toString('hex');

  const reminderData = {
    logistId: String(logistId),
    logistChatId: String(logistId),
    logistFio: logistFio,
    courierId: String(courierId),
    courierFio: courierRecord.fio,
    amount: amount,
    formatted: formatted,
    workplace: courierRecord.workplace || logistWorkplace,
    status: 'reminded',
    createdAt: new Date().toISOString(),
    logistMsgId: null,
    courierMsgId: null
  };

  setReminder(shortId, reminderData);

  logCashAction({
    logistId: String(logistId),
    logistFio: logistFio,
    courierId: String(courierId),
    courierFio: courierRecord.fio,
    workplace: courierRecord.workplace || logistWorkplace,
    amount: amount,
    action: 'reminded'
  });

  const workpalceLabel = courierRecord.workplace || 'не указано';
  const courierMsg = `🔔 <b>Логист ${esc(logistFio)} напоминает:</b>\n\n` +
    `💵 У вас <code>${esc(formatted)}</code> ₽ к сдаче.\n` +
    `🏬 <b>${esc(workpalceLabel)}</b>\n\n` +
    `Сдали деньги?`;

  try {
    const sent = await bot.telegram.sendMessage(courierId, courierMsg, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [Markup.button.callback('🏃 Уже бегу', `ack_${shortId}`)],
          [Markup.button.callback('✅ Сдал', `c_${shortId}`)]
        ]
      }
    });

    const msgId = sent.message_id;
    updateReminder(shortId, { courierMsgId: msgId });

    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('✅ Напоминание отправлено');
      try {
        await ctx.editMessageText(`✅ Напоминание отправлено: <b>${esc(courierRecord.fio)}</b> — <code>${esc(formatted)}</code> ₽`, { parse_mode: 'HTML' });
      } catch (e) { /* ignore */ }
    } else {
      await ctx.replyWithHTML(`✅ Напоминание отправлено: <b>${esc(courierRecord.fio)}</b> — <code>${esc(formatted)}</code> ₽`);
    }
  } catch (e) {
    console.error('failed to send reminder to courier', e);
    deleteReminder(shortId);
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('⚠️ Не удалось отправить уведомление курьеру.');
    } else {
      await ctx.replyWithHTML('⚠️ Не удалось отправить уведомление курьеру. Возможно, он заблокировал бота.');
    }
  }
}

async function showCashHistory(ctx) {
  const telegramId = ctx.from.id;
  const role = getUserRole(telegramId);
  if (role !== 'logist') {
    await ctx.replyWithHTML('❌ Эта функция доступна только логистам.', getMenuForRole(telegramId));
    return;
  }

  const workplace = getUserField(telegramId, 'workplace');
  const features = WORKPLACE_FEATURES[workplace];
  if (!features || !features.cashCollection) {
    await ctx.replyWithHTML('❌ В этом магазине приём наличных не предусмотрен.', getMenuForRole(telegramId));
    return;
  }

  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  const buttons = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', timeZone: timezone });
    const prefix = i === 0 ? '📅 ' : '';
    buttons.push([Markup.button.callback(`${prefix}${dayLabel}`, `ch_${dateStr}`)]);
  }
  buttons.push([Markup.button.callback('🏠 В меню', 'back_to_menu')]);

  await ctx.replyWithHTML('📋 <b>История сборов</b>\n\nВыберите дату:', Markup.inlineKeyboard(buttons));
}

async function showCashHistoryForDate(ctx, dateStr) {
  const telegramId = ctx.from.id;
  const workplace = getUserField(telegramId, 'workplace');
  const rows = getCashHistory(dateStr, workplace);

  const approvedRows = rows.filter(r => r.action === 'approved' || r.action === 'self_cleared' || r.action === 'logist_approved');

  if (approvedRows.length === 0) {
    await ctx.answerCbQuery();
    await ctx.replyWithHTML(`📋 <b>История сборов за ${dateStr}</b>\n\nНет подтверждённых сдач за эту дату.`);
    return;
  }

  const total = approvedRows.reduce((sum, r) => sum + r.amount, 0);
  let msg = `📋 <b>История сборов за ${dateStr}</b>\n` +
    `Всего собрано: <code>${formatMoneyRu(total)}</code> ₽\n\n`;

  for (const row of approvedRows) {
    let icon = '✅';
    if (row.action === 'self_cleared') icon = '💵';
    else if (row.action === 'logist_approved') icon = '👍';
    let logistLabel;
    if (row.action === 'self_cleared') {
      logistLabel = ' (самостоятельно)';
    } else if (row.action === 'logist_approved') {
      logistLabel = row.logistFio ? ` (логист: ${esc(row.logistFio)})` : ' (логист)';
    } else {
      logistLabel = row.logistFio ? ` (логист: ${esc(row.logistFio)})` : '';
    }
    msg += `${icon} ${esc(row.courierFio)} — <code>${formatMoneyRu(row.amount)}</code> ₽${logistLabel}\n`;
  }

  await ctx.replyWithHTML(msg);
}

async function openShopNotify(ctx) {
  const telegramId = ctx.from.id;
  const role = getUserRole(telegramId);
  if (role !== 'logist') {
    await ctx.replyWithHTML('❌ Эта функция доступна только логистам.', getMenuForRole(telegramId));
    return;
  }

  const workplace = getUserField(telegramId, 'workplace');
  if (!workplace) {
    await ctx.replyWithHTML('⚠️ Сначала выберите магазин в настройках.', getMenuForRole(telegramId));
    return;
  }

  const fio = getUserField(telegramId, 'fio') || 'Логист';
  const chatId = process.env.SHOP_STATUS_CHAT_ID;
  if (chatId) {
    try {
      await bot.telegram.sendMessage(chatId,
        `🏪 <b>${esc(workplace)} — ОТКРЫТ</b> ✅\n\nЛогист: ${esc(fio)}`,
        { parse_mode: 'HTML' }
      );
    } catch (e) {
      console.error('shop open notify error', e.message || e);
    }
  }

  await ctx.replyWithHTML(`✅ Уведомление отправлено: <b>${esc(workplace)} — ОТКРЫТ</b> ✅`, getMenuForRole(telegramId));
}

async function notifyLogistsAboutSelfClearance(courierId, courierFio, amount, formatted, workplace) {
  const logists = findLogistsForWorkplace(workplace);

  const allRecipientIds = new Set();
  for (const logist of logists) {
    allRecipientIds.add(String(logist.telegramId));
  }

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback('✅ Подтвердить', `sc_appr_${courierId}`)],
    [Markup.button.callback('❌ Отклонить', `sc_decl_${courierId}`)]
  ]);

  for (const recipientId of allRecipientIds) {
    try {
      await bot.telegram.sendMessage(recipientId,
        `💰 <b>Курьер отметил сдачу</b>\n\n` +
        `👤 ${esc(courierFio)}\n` +
        `💵 <code>${esc(formatted)}</code> ₽\n` +
        `🏬 ${esc(workplace)}\n\n` +
        `Подтвердите сдачу:`,
        { parse_mode: 'HTML', ...keyboard }
      );
    } catch (e) {
      console.error('failed to notify logist about self-clearance', recipientId, e.message);
    }
  }
}

if (!process.env.BOT_TOKEN) {
  throw new Error('BOT_TOKEN is not set');
}

function normalizeProxyUrl(value) {
  const text = String(value || '').trim();
  return text || null;
}

function createTelegramAgent() {
  const proxyUrl = normalizeProxyUrl(process.env.TELEGRAM_PROXY_URL)
    || normalizeProxyUrl(process.env.HTTPS_PROXY)
    || normalizeProxyUrl(process.env.HTTP_PROXY);

  if (!proxyUrl) return null;

  let parsed;
  try {
    parsed = new URL(proxyUrl);
  } catch (_) {
    console.error('Invalid TELEGRAM_PROXY_URL, proxy disabled');
    return null;
  }

  const protocol = String(parsed.protocol || '').toLowerCase();

  if (protocol.startsWith('socks')) {
    console.log('Telegram proxy enabled (SOCKS)');
    return new SocksProxyAgent(proxyUrl);
  }

  if (protocol === 'http:' || protocol === 'https:') {
    console.log('Telegram proxy enabled (HTTP/HTTPS)');
    return new HttpsProxyAgent(proxyUrl);
  }

  console.error(`Unsupported TELEGRAM_PROXY_URL protocol: ${protocol}`);
  return null;
}

const telegramAgent = createTelegramAgent();
const bot = new Telegraf(process.env.BOT_TOKEN, telegramAgent ? {
  telegram: { agent: telegramAgent }
} : undefined);
const photoLogPath = path.join(__dirname, 'photo-log.jsonl');
const routeSheetLogPath = path.join(__dirname, 'route-sheet-log.jsonl');
const reconciliationLogPath = path.join(__dirname, 'reconciliation-log.jsonl');
const funReactionsPath = path.join(__dirname, 'fun-reactions.json');
const lastFunReactionAt = new Map();
const FUN_REACTION_CLEANUP_INTERVAL = LIMITS.FUN_REACTION_CLEANUP_INTERVAL_MS;
let funReactionCleanupTimer = null;

function cleanupFunReactionCooldowns() {
  const now = Date.now();
  for (const [key, ts] of lastFunReactionAt) {
    if (now - ts > FUN_REACTION_CLEANUP_INTERVAL) {
      lastFunReactionAt.delete(key);
    }
  }
}

function startFunReactionCleanup() {
  if (!funReactionCleanupTimer) {
    funReactionCleanupTimer = setInterval(cleanupFunReactionCooldowns, FUN_REACTION_CLEANUP_INTERVAL);
    funReactionCleanupTimer.unref();
  }
}

startFunReactionCleanup();

let funReactionsCache = null;
let funReactionsWriteScheduled = false;

const SUCCESS_STICKER_EMOJIS = new Set(['😀', '😁', '😄', '😎', '🥳', '🎉', '✨', '🔥', '💪', '👍', '👏', '✅']);
const ERROR_STICKER_EMOJIS = new Set(['😢', '😭', '😿', '😞', '😣', '😫', '🤦', '🙈', '😡', '😤', '🚫', '❌', '⚠️']);

function esc(text) {
  return String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function isButton(text, button, legacyText) {
  return text === button || text === legacyText;
}

function formatStage(stage) {
  return stage === 'start' ? 'начало смены' : 'конец смены';
}

function getTimeGreeting(timezone = process.env.APP_TIMEZONE || 'Europe/Moscow') {
  const hour = parseInt(new Date().toLocaleString('en-GB', { timeZone: timezone, hour: 'numeric', hour12: false }));
  if (hour >= 5 && hour < 12) return 'Доброе утро';
  if (hour >= 12 && hour < 18) return 'Добрый день';
  if (hour >= 18 && hour < 23) return 'Добрый вечер';
  return 'Доброй ночи';
}

function formatPhotoStatus(stage) {
  return stage === 'start' ? '🟢 Старт' : '🔴 Конец';
}

function getEmployeeDisplayName(fio) {
  const parts = String(fio || '').trim().split(/\s+/);
  if (parts.length >= 2) {
    return parts[1] + ' ' + parts[0];
  }
  return fio || '';
}

// Telegram ограничивает caption до 1024 символов (НЕ 4096 как для текста).
// Длинное ФИО + магазин могут превысить лимит, тогда API вернёт ошибку.
const TELEGRAM_CAPTION_LIMIT = LIMITS.TELEGRAM_CAPTION_LIMIT;

function truncateCaption(text, limit = TELEGRAM_CAPTION_LIMIT) {
  if (text.length <= limit) return text;
  return text.slice(0, limit - 1) + '…';
}

function buildPhotoCaption(state) {
  // Caption уходит без HTML-парсинга в sendPhotoToWorkChat — escape не нужен,
  // но если в ФИО окажутся <, > — пусть будут как есть, без поломки рендера.
  return truncateCaption([
    formatPhotoStatus(state.stage),
    `👤 ${getEmployeeDisplayName(state.fio)}`,
    `🚙 ${state.auto || 'не указано'}`,
    `🏬 ${state.workplace || 'не указано'}`
  ].join('\n'));
}

function buildRouteSheetCaption(state, routeSheetNumber) {
  return truncateCaption([
    `📄 Маршрутный лист №${routeSheetNumber}`,
    `👤 ${getEmployeeDisplayName(state.fio)}`,
    `🏬 ${state.workplace || 'не указано'}`
  ].join('\n'));
}

function getTodayText() {
  const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
  return getCurrentDateInfo(timezone).dateText;
}

const MAX_LOG_SIZE = LIMITS.MAX_LOG_SIZE_BYTES;

async function trimLogIfNeeded(filePath) {
  try {
    const stat = await fs.promises.stat(filePath).catch(() => null);
    if (!stat || stat.size < MAX_LOG_SIZE) return;
    const content = await fs.promises.readFile(filePath, 'utf8');
    const lines = content.split('\n');
    const half = Math.ceil(lines.length / 2);
    const trimmed = lines.slice(-half).join('\n');
    const tmp = filePath + '.tmp';
    await fs.promises.writeFile(tmp, trimmed, 'utf8');
    await fs.promises.rename(tmp, filePath);
  } catch (_) {}
}

async function appendLog(filePath, entry) {
  const line = `${JSON.stringify(entry)}\n`;
  try {
    await fs.promises.appendFile(filePath, line, 'utf8');
  } catch (error) {
    console.error('log write error', filePath, error.message);
  }
  await trimLogIfNeeded(filePath);
}

const BACKUP_DIR = path.join(__dirname, 'backups');
const BACKUP_FILES = ['database.sqlite', 'fun-reactions.json'];
const BACKUP_INTERVAL_MS = LIMITS.BACKUP_INTERVAL_MS;
const BACKUP_RETENTION_MS = LIMITS.BACKUP_RETENTION_MS;

async function ensureBackupDir() {
  try {
    await fs.promises.mkdir(BACKUP_DIR, { recursive: true });
  } catch (_) {}
}

async function makeBackup(reason = 'auto') {
  await ensureBackupDir();
  const now = new Date();
  const ts = now.toISOString().replace(/[.:]/g, '-');
  try {
    checkpoint();
  } catch (_) {}
  for (const filename of BACKUP_FILES) {
    const src = path.join(__dirname, filename);
    try {
      await fs.promises.access(src);
      const dst = path.join(BACKUP_DIR, `${filename.replace('.json', '')}-${reason}-${ts}.json`);
      await fs.promises.copyFile(src, dst);
    } catch (_) {}
  }
}

async function cleanOldBackups() {
  const cutoff = Date.now() - BACKUP_RETENTION_MS;
  let entries;
  try {
    entries = await fs.promises.readdir(BACKUP_DIR);
  } catch (_) {
    return;
  }
  for (const entry of entries) {
    const fullPath = path.join(BACKUP_DIR, entry);
    try {
      const stat = await fs.promises.stat(fullPath);
      if (stat.mtimeMs < cutoff) {
        await fs.promises.unlink(fullPath);
      }
    } catch (_) {}
  }
}

async function runBackupCycle() {
  try {
    checkpoint();
  } catch (_) {}
  await makeBackup('auto');
  await cleanOldBackups();
}

function withTimeout(promise, timeoutMs, label) {
  let timer;

  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label} timeout after ${timeoutMs}ms`)), timeoutMs);
    })
  ]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}

function parseEnvList(value) {
  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

function pickRandom(items) {
  if (!items || items.length === 0) return null;
  return items[Math.floor(Math.random() * items.length)];
}

function mergeUniqueItems(...lists) {
  const result = [];
  const seen = new Set();

  for (const list of lists) {
    for (const item of list || []) {
      const value = String(item || '').trim();
      if (!value || seen.has(value)) continue;
      seen.add(value);
      result.push(value);
    }
  }

  return result;
}

function normalizeFunList(value, limit = 800) {
  return mergeUniqueItems(value).slice(0, limit);
}

function normalizeImportedStickerSets(value) {
  const source = value && typeof value === 'object' ? value : {};
  const result = {};

  for (const [name, meta] of Object.entries(source)) {
    const setName = String(name || '').trim();
    if (!setName) continue;
    result[setName] = {
      importedAt: String(meta?.importedAt || ''),
      total: Number(meta?.total || 0)
    };
  }

  return result;
}

function getEmptyFunReactions() {
  return {
    successStickers: [],
    errorStickers: [],
    neutralStickers: [],
    successGifs: [],
    errorGifs: [],
    neutralGifs: [],
    importedStickerSets: {}
  };
}

function normalizeFunReactionsData(value) {
  const source = value && typeof value === 'object' ? value : {};
  return {
    successStickers: normalizeFunList(source.successStickers),
    errorStickers: normalizeFunList(source.errorStickers),
    neutralStickers: normalizeFunList(source.neutralStickers),
    successGifs: normalizeFunList(source.successGifs, 300),
    errorGifs: normalizeFunList(source.errorGifs, 300),
    neutralGifs: normalizeFunList(source.neutralGifs, 300),
    importedStickerSets: normalizeImportedStickerSets(source.importedStickerSets)
  };
}

function loadFunReactions() {
  if (funReactionsCache) return funReactionsCache;

  try {
    if (!fs.existsSync(funReactionsPath)) {
      funReactionsCache = getEmptyFunReactions();
      return funReactionsCache;
    }

    const data = JSON.parse(fs.readFileSync(funReactionsPath, 'utf8'));
    funReactionsCache = normalizeFunReactionsData(data);
    return funReactionsCache;
  } catch (error) {
    console.error('fun reactions load error', error.message);
    funReactionsCache = getEmptyFunReactions();
    return funReactionsCache;
  }
}

function scheduleFunReactionsWrite() {
  if (funReactionsWriteScheduled) return;
  funReactionsWriteScheduled = true;

  setImmediate(() => {
    funReactionsWriteScheduled = false;
    fs.promises.writeFile(funReactionsPath, JSON.stringify(funReactionsCache || getEmptyFunReactions(), null, 2), 'utf8').catch((error) => {
      console.error('fun reactions write error', error.message);
    });
  });
}

function flushFunReactionsNow() {
  funReactionsWriteScheduled = false;

  try {
    fs.writeFileSync(funReactionsPath, JSON.stringify(funReactionsCache || getEmptyFunReactions(), null, 2), 'utf8');
  } catch (error) {
    console.error('fun reactions flush error', error.message);
  }
}

function addUniqueLimited(list, value, limit = 800) {
  const text = String(value || '').trim();
  if (!text) return false;
  if (list.includes(text)) return false;

  list.push(text);
  if (list.length > limit) {
    list.splice(0, list.length - limit);
  }

  return true;
}

function getStickerReactionTypeByEmoji(emoji) {
  const value = String(emoji || '').trim();
  if (!value) return 'neutral';
  if (ERROR_STICKER_EMOJIS.has(value)) return 'error';
  if (SUCCESS_STICKER_EMOJIS.has(value)) return 'success';
  return 'neutral';
}

function getStickerBucketByType(reactionType) {
  if (reactionType === 'error') return 'errorStickers';
  if (reactionType === 'success') return 'successStickers';
  return 'neutralStickers';
}

function getGifBucketByType(reactionType) {
  if (reactionType === 'error') return 'errorGifs';
  if (reactionType === 'success') return 'successGifs';
  return 'neutralGifs';
}

function saveFunSticker(fileId, reactionType = 'neutral') {
  const data = loadFunReactions();
  const bucket = getStickerBucketByType(reactionType);
  const changed = addUniqueLimited(data[bucket], fileId, 1000);

  if (changed) {
    scheduleFunReactionsWrite();
  }

  return changed;
}

function saveFunGif(fileId, reactionType = 'neutral') {
  const data = loadFunReactions();
  const bucket = getGifBucketByType(reactionType);
  const changed = addUniqueLimited(data[bucket], fileId, 400);

  if (changed) {
    scheduleFunReactionsWrite();
  }

  return changed;
}

function extractStickerSetName(input) {
  const value = String(input || '').trim();
  if (!value) return null;

  const match = value.match(/(?:https?:\/\/)?t\.me\/addstickers\/([a-zA-Z0-9_]+)/i);
  if (match) return match[1];

  if (/^[a-zA-Z0-9_]+$/.test(value)) return value;
  return null;
}

function isFunStickerSetImportEnabled() {
  return String(process.env.FUN_IMPORT_STICKER_SETS || 'true').toLowerCase() !== 'false';
}

function getConfiguredFunStickerSetNames() {
  const envItems = parseEnvList(process.env.FUN_STICKER_SETS);
  const defaults = [
    'https://t.me/addstickers/TikTok_cats_animals',
    'https://t.me/addstickers/babylka_mem'
  ];
  const sources = envItems.length > 0 ? envItems : defaults;

  return mergeUniqueItems(sources.map((item) => extractStickerSetName(item)).filter(Boolean));
}

async function importStickerSetForFunReactions(ctx, stickerSetName) {
  const setName = extractStickerSetName(stickerSetName);
  if (!setName || !isFunStickerSetImportEnabled()) {
    return { setName, imported: false, added: 0, total: 0 };
  }

  const data = loadFunReactions();
  if (data.importedStickerSets[setName]) {
    return { setName, imported: false, added: 0, total: data.importedStickerSets[setName].total || 0 };
  }

  try {
    const stickerSet = await ctx.telegram.getStickerSet(setName);
    const stickers = Array.isArray(stickerSet?.stickers) ? stickerSet.stickers : [];
    let added = 0;

    for (const sticker of stickers) {
      if (!sticker?.file_id) continue;
      const reactionType = getStickerReactionTypeByEmoji(sticker.emoji);
      if (saveFunSticker(sticker.file_id, reactionType)) {
        added++;
      }
    }

    data.importedStickerSets[setName] = {
      importedAt: new Date().toISOString(),
      total: stickers.length
    };
    scheduleFunReactionsWrite();
    console.log(`fun stickers imported: ${setName}, total=${stickers.length}, added=${added}`);

    return { setName, imported: true, added, total: stickers.length };
  } catch (error) {
    console.error('fun sticker set import error', setName, error.message);
    return { setName, imported: false, added: 0, total: 0, error: error.message };
  }
}

async function importConfiguredFunStickerSets(ctx) {
  if (!isFunStickerSetImportEnabled()) return;

  const setNames = getConfiguredFunStickerSetNames();
  for (const setName of setNames) {
    await importStickerSetForFunReactions(ctx, setName);
  }
}

function hasAnyFunReactionContent() {
  const envContent = [
    ...parseEnvList(process.env.FUN_ERROR_STICKERS),
    ...parseEnvList(process.env.FUN_SUCCESS_STICKERS),
    ...parseEnvList(process.env.FUN_ERROR_GIFS),
    ...parseEnvList(process.env.FUN_SUCCESS_GIFS)
  ];

  if (envContent.length > 0) return true;

  const stored = loadFunReactions();
  return (
    stored.successStickers.length > 0 ||
    stored.errorStickers.length > 0 ||
    stored.neutralStickers.length > 0 ||
    stored.successGifs.length > 0 ||
    stored.errorGifs.length > 0 ||
    stored.neutralGifs.length > 0
  );
}

function isFunReactionsEnabled() {
  const flag = String(process.env.FUN_REACTIONS_ENABLED || '').trim().toLowerCase();
  if (flag === 'true' || flag === '1' || flag === 'yes') return true;
  if (flag === 'false' || flag === '0' || flag === 'no') return false;
  return hasAnyFunReactionContent();
}

function getFunReactionTypeFromMessage(htmlText) {
  const plainText = String(htmlText || '')
    .replace(/<[^>]*>/g, '')
    .trim();

  if (plainText.startsWith('❌') || plainText.startsWith('⚠️')) return 'error';
  if (plainText.startsWith('✅')) return 'success';
  return null;
}

function getFunReactionCooldownMs() {
  const value = Number(process.env.FUN_REACTION_COOLDOWN_MS || 30000);
  return Number.isFinite(value) && value >= 0 ? value : 30000;
}

function canSendFunReaction(chatId) {
  const cooldown = getFunReactionCooldownMs();
  if (cooldown === 0) return true;

  const now = Date.now();
  const last = lastFunReactionAt.get(chatId) || 0;
  if (now - last < cooldown) return false;

  lastFunReactionAt.set(chatId, now);
  return true;
}

async function sendFunReaction(ctx, reactionType) {
  if (!isFunReactionsEnabled()) return;
  const chatId = ctx?.chat?.id;
  if (!chatId) return;
  if (!canSendFunReaction(chatId)) return;

  const envStickerList = reactionType === 'error'
    ? parseEnvList(process.env.FUN_ERROR_STICKERS)
    : parseEnvList(process.env.FUN_SUCCESS_STICKERS);
  const envGifList = reactionType === 'error'
    ? parseEnvList(process.env.FUN_ERROR_GIFS)
    : parseEnvList(process.env.FUN_SUCCESS_GIFS);

  const stored = loadFunReactions();
  const storedStickerList = reactionType === 'error'
    ? mergeUniqueItems(stored.errorStickers, stored.neutralStickers)
    : mergeUniqueItems(stored.successStickers, stored.neutralStickers);
  const storedGifList = reactionType === 'error'
    ? mergeUniqueItems(stored.errorGifs, stored.neutralGifs)
    : mergeUniqueItems(stored.successGifs, stored.neutralGifs);

  const stickerList = mergeUniqueItems(envStickerList, storedStickerList);
  const gifList = mergeUniqueItems(envGifList, storedGifList);

  const sticker = pickRandom(stickerList);
  const gif = pickRandom(gifList);

  try {
    if (sticker) {
      await ctx.replyWithSticker(sticker);
      return;
    }

    if (gif) {
      await ctx.replyWithAnimation(gif);
    }
  } catch (error) {
    console.error('fun reaction error', error.message);
  }
}

async function maybeSendFunReaction(ctx, htmlText) {
  const reactionType = getFunReactionTypeFromMessage(htmlText);
  if (!reactionType) return;
  await sendFunReaction(ctx, reactionType);
}

bot.use(async (ctx, next) => {
  if (ctx.chat?.type !== 'private') {
    if (ctx.message?.text?.startsWith('/chatid')) {
      return next();
    }
    return;
  }

  const originalReplyWithHTML = ctx.replyWithHTML.bind(ctx);
  ctx.replyWithHTML = async (htmlText, extra) => {
    const response = await originalReplyWithHTML(htmlText, extra);
    await maybeSendFunReaction(ctx, htmlText);
    return response;
  };

  await next();
});

bot.on('sticker', async (ctx) => {
  const sticker = ctx.message?.sticker;
  if (!sticker?.file_id) return;

  const reactionType = getStickerReactionTypeByEmoji(sticker.emoji);
  const saved = saveFunSticker(sticker.file_id, reactionType);

  if (saved) {
    console.log('fun sticker saved', reactionType, sticker.file_id);
  }

  if (sticker.set_name) {
    await importStickerSetForFunReactions(ctx, sticker.set_name);
  }
});

bot.on('animation', async (ctx) => {
  const animation = ctx.message?.animation;
  if (!animation?.file_id) return;

  const saved = saveFunGif(animation.file_id, 'neutral');
  if (saved) {
    console.log('fun gif saved', animation.file_id);
  }
});

function logMileagePhoto(telegramId, fileId, state) {
  appendLog(photoLogPath, {
    at: new Date().toISOString(),
    telegramId,
    fileId,
    fio: state?.fio || null,
    date: state?.date || null,
    stage: state?.stage || null,
    auto: state?.auto || null,
    workplace: state?.workplace || null
  });
}

function getNextRouteSheetNumber(state, date) {
  try {
    if (!fs.existsSync(routeSheetLogPath)) {
      return 1;
    }

    const lines = fs.readFileSync(routeSheetLogPath, 'utf8').split('\n').filter(Boolean);
    const count = lines.reduce((total, line) => {
      try {
        const entry = JSON.parse(line);
        return entry.date === date && entry.fio === state?.fio ? total + 1 : total;
      } catch (_) {
        return total;
      }
    }, 0);

    return count + 1;
  } catch (error) {
    console.error('route sheet count error', error);
    return 1;
  }
}

function logRouteSheetPhoto(telegramId, fileId, state, date, routeSheetNumber) {
  appendLog(routeSheetLogPath, {
    at: new Date().toISOString(),
    date,
    routeSheetNumber,
    telegramId,
    fileId,
    fio: state?.fio || null,
    carNumber: state?.carNumber || null,
    workplace: state?.workplace || null
  });
}

function logReconciliationPhoto(telegramId, fileId, state, label) {
  appendLog(reconciliationLogPath, {
    at: new Date().toISOString(),
    telegramId,
    fileId,
    fio: state?.fio || null,
    carNumber: state?.carNumber || null,
    workplace: state?.workplace || null,
    device: state?.device || null,
    label
  });
}

function parseMoneyRu(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const cleaned = raw.replace(/[\s\u00A0]/g, '').replace(/₽/g, '').replace(/,/g, '.').replace(/[^0-9.]/g, '');
  if (!cleaned) return null;
  const number = Number(cleaned);
  if (!Number.isFinite(number) || number < 0) return null;
  return number;
}

function formatMoneyRu(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number) || number < 0) return null;
  const formatted = new Intl.NumberFormat('ru-RU', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(number);
  return `${formatted} ₽`;
}

function formatMoneyRuNumber(value) {
  const withCurrency = formatMoneyRu(value);
  if (!withCurrency) return null;
  return withCurrency.replace(/\s*₽$/, '');
}

function extractOrdersCountFromOcrText(text) {
  const raw = String(text || '')
    .replace(/\u00A0/g, ' ')
    .trim();

  if (!raw) {
    return { totalOrders: null, reason: 'empty_text' };
  }

  const normalized = raw.replace(/\s+/g, ' ');

  const strictPatterns = [
    /заказо[кв]\s+за\s*(?:сегодня|сутки)\s*:?\s*(\d{1,5})/i,
    /за\s*(?:сегодня|сутки)\s*:?\s*(\d{1,5})/i,
  ];

  for (const pattern of strictPatterns) {
    const match = normalized.match(pattern);
    if (match && Number.isFinite(Number(match[1])) && Number(match[1]) > 0) {
      return { totalOrders: Number(match[1]), reason: 'ok' };
    }
  }

  const lines = raw.split(/\n/);
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i].trim();
    if (/заказо[кв]/i.test(line)) {
      for (let j = i + 1; j < Math.min(lines.length, i + 5); j += 1) {
        const candidate = lines[j].trim();
        const numMatch = candidate.match(/^(\d{1,5})$/);
        if (numMatch && Number.isFinite(Number(numMatch[1])) && Number(numMatch[1]) > 0) {
          return { totalOrders: Number(numMatch[1]), reason: 'ok' };
        }
      }
    }
  }

  const fallbackPatterns = [
    /заказо[кв]\s*:?\s*(\d{1,5})(?:\s|$)/i,
    /(\d{1,5})\s*заказо[кв]/i,
  ];

  for (const pattern of fallbackPatterns) {
    const match = normalized.match(pattern);
    if (match && Number.isFinite(Number(match[1])) && Number(match[1]) > 0) {
      return { totalOrders: Number(match[1]), reason: 'ok' };
    }
  }

  return { totalOrders: null, reason: 'no_orders_line' };
}

function extractCashFromOcrText(text) {
  const normalized = String(text || '')
    .replace(/\u00A0/g, ' ')
    .replace(/[|¦]/g, '/')
    .replace(/₽/g, ' ₽')
    .replace(/\s+/g, ' ')
    .trim();

  if (!normalized) {
    return { orders: null, amount: null, valid: false, reason: 'empty_text' };
  }

  const cashWordSource = 'налич[а-яa-z]*|[Hh]a[нn][лnM][иiч4][нn][ыb][еe]|[Hh]a[лn][иiч][нh][bл][еe]';
  const cashLineRegex = new RegExp(`(?:${cashWordSource})\\s*([0-9]{1,3})?\\s*/\\s*([0-9\\s.,]{1,20})?[P₽]?`, 'i');
  const cashMatch = normalized.match(cashLineRegex);

  if (cashMatch) {
    const ordersRaw = cashMatch[1] || '';
    const amountRaw = cashMatch[2] || '';
    const orders = Number(String(ordersRaw).replace(/\D/g, ''));
    const amount = parseMoneyRu(amountRaw);
    const hasOrders = Number.isFinite(orders) && orders > 0;
    const hasAmount = Number.isFinite(amount) && amount >= 1;

    return {
      orders: Number.isFinite(orders) ? orders : 0,
      amount: Number.isFinite(amount) ? amount : null,
      valid: hasOrders && hasAmount,
      reason: hasOrders && hasAmount ? 'ok' : 'insufficient'
    };
  }

  const hasCashWord = new RegExp(`(?:${cashWordSource})`, 'i').test(normalized);
  if (hasCashWord) {
    return { orders: 0, amount: null, valid: false, reason: 'cash_line_empty' };
  }

  return { orders: null, amount: null, valid: false, reason: 'no_cash_line' };
}

function getReconciliationOcrTimeoutMs() {
  const value = Number(process.env.RECONCILIATION_OCR_TIMEOUT_MS || 30000);
  return Number.isFinite(value) && value >= 5000 ? value : 30000;
}

const MAX_REASONABLE_CASH_AMOUNT = 500000;

function roundMoney(value) {
  return Math.round(Number(value || 0) * 100) / 100;
}



function emptyReconciliationCash(reason, source = 'none') {
  return { orders: null, amount: null, totalOrders: null, valid: false, reason, source };
}

async function recognizeReconciliationCashSafe(ctx, fileId, label) {
  try {
    return await withTimeout(
      recognizeReconciliationCash(ctx, fileId),
      getReconciliationOcrTimeoutMs(),
      `reconciliation OCR ${label || ''}`.trim()
    );
  } catch (error) {
    console.error('reconciliation OCR safe fallback', label || '', error.message || error);
    return emptyReconciliationCash('ocr_timeout', 'none');
  }
}

function shouldWarnAboutReconciliationOcr(cashInfo) {
  if (!cashInfo) return true;
  if (cashInfo.valid) return false;
  if (cashInfo.totalOrders && cashInfo.totalOrders > 0) return false;
  return ['ocr_timeout', 'error', 'local_ocr_error', 'local_ocr_timeout', 'no_ocr_result'].includes(cashInfo.reason);
}

async function recognizeReconciliationCash(ctx, fileId) {
  try {
    const link = await ctx.telegram.getFileLink(fileId);
    const response = await axios.get(link.href, { responseType: 'arraybuffer', timeout: 30000 });
    const imageBuffer = Buffer.from(response.data);

    let totalOrdersFromRapid = null;

    if (isRapidOcrEnabled()) {
      const rapidText = await recognizeTextWithRapidOcr(imageBuffer);
      if (rapidText) {
        const parsed = extractCashFromOcrText(rapidText);
        const ordersParsed = extractOrdersCountFromOcrText(rapidText);
        totalOrdersFromRapid = ordersParsed.totalOrders;
        console.log('сверка OCR:', JSON.stringify({ cashValid: parsed.valid, cashReason: parsed.reason, cashOrders: parsed.orders, cashAmount: parsed.amount, totalOrders: ordersParsed.totalOrders, ordersReason: ordersParsed.reason, source: 'rapidocr' }));

        if (parsed.valid) {
          return { ...parsed, totalOrders: ordersParsed.totalOrders, source: 'rapidocr' };
        }

        if (parsed.reason === 'cash_line_empty') {
          return { ...parsed, totalOrders: ordersParsed.totalOrders, source: 'rapidocr' };
        }
      } else {
        console.log('сверка OCR: RapidOCR вернул пустой текст');
      }
    }

    console.log('сверка OCR: RapidOCR не дал результата, fallback-OCR не подключён');
    return { orders: null, amount: null, totalOrders: totalOrdersFromRapid, valid: false, reason: 'no_ocr_result', source: 'none' };
  } catch (error) {
    console.error('reconciliation cash recognition error', error.message || error);
    return { orders: null, amount: null, totalOrders: null, valid: false, reason: 'error', source: 'none' };
  }
}

function makeMileageState(telegramId, baseState, extra = {}) {
  return {
    telegramId,
    ...baseState,
    awaitingMileagePhoto: true,
    awaitingManualMileage: false,
    photoReceived: false,
    ...extra
  };
}

function normalizeCarNumber(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').toUpperCase();
}

function isValidCarNumber(value) {
  const normalized = normalizeCarNumber(value);
  if (!normalized) return false;
  if (normalized.length < 4 || normalized.length > 12) return false;
  return /[А-ЯЁA-Z]/.test(normalized) && /\d/.test(normalized);
}

function normalizeTimeValue(value) {
  const text = String(value || '').trim();

  // 1) Двоеточие — всегда время (пробелы вокруг ":" игнорируем)
  const noSpaces = text.replace(/\s+/g, '');
  const colonMatch = noSpaces.match(/^(\d{1,2}):(\d{1,2})$/);
  if (colonMatch) {
    const minutes = Number(colonMatch[2]);
    if (minutes > 59) return null;
    return roundMinutesToHalfHour(Number(colonMatch[1]), minutes);
  }

  // 2) Точка / пробел + ДВЕ цифры → время (8.46, 8 14, 8.05, 07.30)
  const dotTimeMatch = text.match(/^(\d{1,2})[.\s]+(\d{2})$/);
  if (dotTimeMatch) {
    const minutes = Number(dotTimeMatch[2]);
    if (minutes > 59) return null;
    return roundMinutesToHalfHour(Number(dotTimeMatch[1]), minutes);
  }

  // 3) Точка / пробел + ОДНА цифра → десятичная дробь (8.5, 8 5, 7.3)
  const dotDecimalMatch = text.match(/^(\d{1,2})[.\s]+(\d)$/);
  if (dotDecimalMatch) {
    const minutes = Math.round(Number(dotDecimalMatch[2]) * 6); // 0.X * 60
    return roundMinutesToHalfHour(Number(dotDecimalMatch[1]), minutes);
  }

  // 4) Запятая или целое — десятичная дробь
  const decimalMatch = noSpaces.match(/^(\d{1,2})(?:,(\d{1,2}))?$/);
  if (decimalMatch) {
    const hours = Number(decimalMatch[1]);
    const fraction = decimalMatch[2] ? Number(`0.${decimalMatch[2]}`) : 0;
    const minutes = Math.round(fraction * 60);
    return roundMinutesToHalfHour(hours, minutes);
  }

  return null;
}

function isMenuText(text) {
  return [
    BUTTONS.punchTime,
    BUTTONS.mileage,
    BUTTONS.routeSheet,
    BUTTONS.reconciliation,
    BUTTONS.cashCheck,
    BUTTONS.issues,
    BUTTONS.leaderBoard,
    BUTTONS.settings,
    BUTTONS.help,
    BUTTONS.profile,
    BUTTONS.changeCar,
    BUTTONS.changeWorkplace,
    BUTTONS.changeDevice,
    BUTTONS.switchUser,
    BUTTONS.sheetInfo,
    BUTTONS.myId,
    'Время смены',
    'Внести время смены',
    'Время',
    'Внести пробег',
    'Пробег',
    'Маршрутный лист',
    'Маршрутник',
    'Сверки',
    'Деньги к сдаче',
    'Наличные',
    'Проблема с заказом',
    'Проблема',
    'Лидерборд',
    'Настройки',
    'Помощь',
    'Профиль',
    'Изменить номер машины',
    'Номер машины',
    'Поменять магазин',
    'Изменить интернет-магазин',
    'Магазин',
    'Изменить устройство',
    'Устройство',
    'Поменять сотрудника',
    'Сменить сотрудника',
    'Сотрудник',
    'Таблицы',
    'Мой ID',
    'Управление'
  ].includes(text) || WORKPLACES.includes(text) || DEVICES.includes(text);
}

async function askForCarNumber(ctx, fio = getUserField(ctx.from.id, 'fio')) {
  setState(ctx.from.id, { awaitingCarNumber: true, fio });
  await ctx.replyWithHTML(
    `🚗 <b>Номер машины</b>\n\nВведите гос. номер автомобиля.\nНапример: <code>А123ВС777</code>`,
    getMenuForRole(ctx.from.id)
  );
}

async function askForWorkplace(ctx, fio = getUserField(ctx.from.id, 'fio')) {
  setState(ctx.from.id, { awaitingWorkplace: true, fio });
  await ctx.replyWithHTML(
    '🏬 <b>Интернет-магазин</b>\n\nВыберите ваш магазин:',
    workplaceMenu()
  );
}

async function askForDevice(ctx, fio = getUserField(ctx.from.id, 'fio')) {
  setState(ctx.from.id, { awaitingDevice: true, fio });
  await ctx.replyWithHTML(
    '💻 <b>Рабочее устройство</b>\n\nВыберите устройство:',
    deviceMenu()
  );
}

async function saveCarNumber(ctx, value) {
  const carNumber = normalizeCarNumber(value);

  if (!carNumber || isMenuText(value)) {
    await ctx.replyWithHTML('❌ Введите номер машины текстом.\nНапример: <code>А123ВС777</code>');
    return;
  }

  if (!isValidCarNumber(carNumber)) {
    await ctx.replyWithHTML('❌ Неверный формат номера.\nНомер должен содержать буквы и цифры.\nНапример: <code>А123ВС777</code>');
    return;
  }

  setUserField(ctx.from.id, 'carNumber', carNumber);
  console.log('номер машины сохранён');

  if (!getUserField(ctx.from.id, 'workplace')) {
    await ctx.replyWithHTML(`✅ Номер машины сохранён: <code>${esc(carNumber)}</code>`);
    await askForWorkplace(ctx);
    return;
  }

  if (!getUserField(ctx.from.id, 'device')) {
    await ctx.replyWithHTML(`✅ Номер машины сохранён: <code>${esc(carNumber)}</code>`);
    await askForDevice(ctx);
    return;
  }

  clearState(ctx.from.id);
  await ctx.replyWithHTML(`✅ Номер машины сохранён: <code>${esc(carNumber)}</code>`, getMenuForRole(ctx.from.id));
}

async function saveWorkplace(ctx, value) {
  const workplace = WORKPLACES.find((item) => item.toLowerCase() === String(value || '').trim().toLowerCase());

  if (!workplace) {
    await ctx.replyWithHTML('❌ Выберите магазин кнопкой ниже.', workplaceMenu());
    return;
  }

  setUserField(ctx.from.id, 'workplace', workplace);
  console.log('интернет-магазин сохранён');
  const role = getUserRole(ctx.from.id);

  if (role === 'logist') {
    clearState(ctx.from.id);
    await ctx.replyWithHTML(`✅ Магазин сохранён: <b>${esc(workplace)}</b>`, logistMainMenu(ctx.from.id));
    return;
  }

  if (!getUserField(ctx.from.id, 'device')) {
    await ctx.replyWithHTML(`✅ Магазин сохранён: <b>${esc(workplace)}</b>`);
    await askForDevice(ctx);
    return;
  }

  clearState(ctx.from.id);
  await ctx.replyWithHTML(`✅ Магазин сохранён: <b>${esc(workplace)}</b>`, getMenuForRole(ctx.from.id));
}

async function saveDevice(ctx, value) {
  const device = DEVICES.find((item) => item.toLowerCase() === String(value || '').trim().toLowerCase());

  if (!device) {
    await ctx.replyWithHTML('❌ Выберите устройство кнопкой ниже.', deviceMenu());
    return;
  }

  setUserField(ctx.from.id, 'device', device);
  clearState(ctx.from.id);
  console.log('устройство сохранено');
  await ctx.replyWithHTML(`✅ Устройство сохранено: <b>${esc(device)}</b>`, getMenuForRole(ctx.from.id));
}

async function ensureProfile(ctx) {
  const profile = getFullProfile(ctx.from.id);
  const role = getUserRole(ctx.from.id);

  if (!profile.fio) {
    await askForFio(ctx);
    return null;
  }

  if (role !== 'logist') {
    if (profile.courierType !== 'pedestrian' && !profile.carNumber) {
      await askForCarNumber(ctx, profile.fio);
      return null;
    }
  }

  if (!profile.workplace) {
    await askForWorkplace(ctx, profile.fio);
    return null;
  }

  if (role !== 'logist') {
    if (!profile.device) {
      await askForDevice(ctx, profile.fio);
      return null;
    }
  }

  return profile;
}

function applyCarNumber(result, carNumber) {
  return { ...result, auto: carNumber || result.auto };
}

function applyProfile(result, profile) {
  return { ...applyCarNumber(result, profile.carNumber), workplace: profile.workplace, device: profile.device };
}

async function askForFio(ctx) {
  const telegramId = ctx.from.id;
  setState(telegramId, { awaitingFio: true });
  await ctx.replyWithHTML(
    '👤 <b>Авторизация</b>\n\nВведите имя и фамилию как в таблице.',
    Markup.keyboard([[BUTTONS.back]]).resize()
  );
}

async function authorizeFio(ctx, fio) {
  const telegramId = ctx.from.id;

  try {
    console.log('авторизация ФИО');
    const employee = await findCourierInAllSheets(fio);

    if (!employee) {
      console.log('сотрудник не найден');
      await ctx.replyWithHTML('❌ Сотрудник не найден в таблице.\nПроверьте имя и фамилию и попробуйте ещё раз.');
      return;
    }

    setUserField(telegramId, 'fio', employee.fio);
    console.log('сотрудник найден');
    await ctx.replyWithHTML(`✅ Сотрудник найден: <b>${esc(employee.fio)}</b>`);

    const auto = String(employee.auto || '').trim().toLowerCase();
    const workplace = employee.workplace;

    if (workplace === 'ИМ Центр') {
      if (auto === 'пеший') {
        setUserField(telegramId, 'courierType', 'pedestrian');
        setUserField(telegramId, 'role', 'courier');
        setUserField(telegramId, 'workplace', 'ИМ Центр');
        await ctx.replyWithHTML('🚶 <b>Пеший курьер</b>, магазин <b>ИМ Центр</b>.');
        await askForDevice(ctx, employee.fio);
        return;
      }
      if (auto === 'логист') {
        setUserField(telegramId, 'role', 'logist');
        await ctx.replyWithHTML('📦 <b>Логист</b>.\n\nТеперь выберите ваш магазин.', logistMainMenu(telegramId));
        await askForWorkplace(ctx, employee.fio);
        return;
      }
      setUserField(telegramId, 'courierType', 'auto');
      setUserField(telegramId, 'role', 'courier');
      await ctx.replyWithHTML('🚗 <b>Авто-курьер</b>.\n\nТеперь введите номер машины.');
      await askForCarNumber(ctx, employee.fio);
      return;
    }

    if (workplace === 'ИМ Восток') {
      if (auto === 'логист') {
        setUserField(telegramId, 'role', 'logist');
        await ctx.replyWithHTML('📦 <b>Логист</b>.\n\nТеперь выберите ваш магазин.', logistMainMenu(telegramId));
        await askForWorkplace(ctx, employee.fio);
        return;
      }
      setState(telegramId, { awaitingRoleChoice: true, fio: employee.fio, workplace: employee.workplace });
      await ctx.replyWithHTML(
        '👤 <b>Выберите вашу роль:</b>\n\n' +
        '▫️ <b>Курьер</b> — доставка заказов, пробег, маршрутник, сверка, наличные\n' +
        '▫️ <b>Логист</b> — учёт времени, сбор наличных с курьеров, таблицы',
        roleChoiceKeyboard()
      );
      return;
    }

    setState(telegramId, { awaitingRoleChoice: true, fio: employee.fio, workplace: employee.workplace });
    await ctx.replyWithHTML(
      '👤 <b>Выберите вашу роль:</b>\n\n' +
      '▫️ <b>Курьер</b> — доставка заказов, пробег, маршрутник, сверка, наличные\n' +
      '▫️ <b>Логист</b> — учёт времени, сбор наличных с курьеров, таблицы',
      roleChoiceKeyboard()
    );
  } catch (error) {
    console.error('ошибка Google Sheets', error);
    await ctx.replyWithHTML('⚠️ Ошибка Google Таблицы.\nПопробуйте ещё раз или обратитесь к администратору.');
  }
}

async function punchTimeFlow(ctx, explicitStage = null) {
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  try {
    const isPedestrian = profile.courierType === 'pedestrian';
    const result = explicitStage
      ? await replaceTime(profile.fio, profile.workplace, explicitStage, isPedestrian)
      : await punchTime(profile.fio, profile.workplace, isPedestrian);

    if (result.notFound) {
      const msg = formatNoSheetMessage(result, profile.workplace);
      await ctx.replyWithHTML(msg);
      return;
    }

    if (result.needsReplaceChoice) {
      console.log('нужна замена');
      setState(telegramId, { awaitingReplaceChoice: true, fio: profile.fio });
      await ctx.replyWithHTML(
        `⚠️ За сегодня уже внесены начало и конец смены.\n\n` +
        `🟢 Старт: <code>${esc(result.from)}</code>\n` +
        `🔴 Конец: <code>${esc(result.to)}</code>\n\n` +
        `Выберите, что заменить:`,
        replaceKeyboard()
      );
      return;
    }

    console.log('время записано', result.stage);

    const xpKey = result.stage === 'start' ? 'punchStart' : 'punchEnd';
    const xpLabel = result.stage === 'start' ? 'Старт' : 'Конец';
    addXp(telegramId, getXpForAction(xpKey), `${xpLabel} смены`);
    const todayIso = new Date().toISOString().split('T')[0];
    const streak = updateStreak(telegramId, todayIso);
    const streakBonus = getStreakBonus(streak.currentStreak);
    if (streakBonus > 0) {
      addXp(telegramId, streakBonus, `Бонус за стрик ${streak.currentStreak} смен`);
    }

    const icon = result.stage === 'start' ? '🟢' : '🔴';
    const label = result.stage === 'start' ? 'Старт' : 'Конец';

    setState(telegramId, {
      awaitingTimeChange: true,
      awaitingManualTime: false,
      fio: result.fio,
      courierRow: result.courierRow,
      day: result.day,
      stage: result.stage,
      timeValue: result.timeValue,
      workplace: profile.workplace
    });

    await ctx.replyWithHTML(
      `${icon} <b>${label} смены</b>: <code>${esc(result.timeValue)}</code>\n\n` +
      `<i>Если время неверное — нажмите «Изменить время».</i>`,
      timeChangeKeyboard()
    );

    if (result.stage === 'start') {
      const pendingCash = getPendingCash(telegramId);
      const pendingAmount = Number(pendingCash?.amount || 0);

      if (Number.isFinite(pendingAmount) && pendingAmount >= 1) {
        const formattedAmount = pendingCash?.formatted || formatMoneyRu(pendingAmount);
        const numberOnly = formatMoneyRuNumber(pendingAmount) || String(formattedAmount || '').replace(/\s*₽$/, '');
        await ctx.replyWithHTML(
          `⚠️ <b>Не забудьте сдать деньги</b>: <code>${esc(numberOnly)}</code> ₽\n` +
          `🏬 <b>${esc(pendingCash?.workplace || profile.workplace || 'не указано')}</b>`,
          cashSubmitConfirmKeyboard()
        );
      }
    }
  } catch (error) {
    console.error('ошибка Google Sheets', error);
    await ctx.replyWithHTML('⚠️ Не удалось записать время.\nПопробуйте ещё раз или обратитесь к администратору.');
  }
}

async function mileageFlow(ctx, explicitStage = null) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  if (profile.courierType === 'pedestrian') {
    await ctx.replyWithHTML('🚶 Пешим курьерам пробег не требуется.', getMenuForRole(telegramId));
    return;
  }

  try {
    const result = await prepareMileage(profile.fio, profile.workplace, explicitStage);

    if (result.notFound) {
      const msg = formatNoSheetMessage(result, profile.workplace);
      await ctx.replyWithHTML(msg);
      return;
    }

    if (result.needsReplaceChoice) {
      console.log('нужна замена пробега');
      setState(telegramId, { awaitingMileageReplaceChoice: true, fio: profile.fio });
      await ctx.replyWithHTML(
        `⚠️ За сегодня уже внесён пробег.\n\n` +
        `🟢 Старт: <code>${esc(result.startMileage)}</code>\n` +
        `🔴 Конец: <code>${esc(result.endMileage)}</code>\n\n` +
        `Выберите, что заменить:`,
        mileageReplaceKeyboard()
      );
      return;
    }

    setState(telegramId, makeMileageState(telegramId, applyProfile(result, profile), { source: 'mileage' }));
    console.log('ожидание пробега', result.stage);
    await ctx.replyWithHTML(
      `📷 <b>Отправьте фото одометра</b>\n\n` +
      `Этап: <b>${esc(formatStage(result.stage))}</b>\n\n` +
      `📎 <i>Нажмите на скрепку → Камера или Галерея</i>`,
      skipMileageKeyboard()
    );
  } catch (error) {
    console.error('ошибка Google Sheets', error);
    await ctx.replyWithHTML('⚠️ Не удалось подготовить запись пробега.\nПопробуйте ещё раз или обратитесь к администратору.');
  }
}

async function routeSheetFlow(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  setState(telegramId, {
    awaitingRouteSheetPhoto: true,
    fio: profile.fio,
    carNumber: profile.carNumber,
    workplace: profile.workplace
  });

  await ctx.replyWithHTML(
    `📄 <b>Маршрутный лист</b>\n\n` +
    `Отправьте фото. Можно отправить несколько фото подряд.\n\n` +
    `📎 <i>Нажмите на скрепку → Камера или Галерея</i>`,
    routeSheetKeyboard()
  );
}

async function reconciliationFlow(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  const isTerminal = profile.device === 'Терминал';
  const totalPhotos = isTerminal ? 2 : 1;

  setState(telegramId, {
    awaitingReconciliationPhoto: true,
    reconciliationPhotosSent: 0,
    reconciliationTotal: totalPhotos,
    fio: profile.fio,
    carNumber: profile.carNumber,
    workplace: profile.workplace,
    device: profile.device
  });

  const firstLabel = isTerminal ? '📊 Статистика' : 'Пин-Панель';
  const orderHint = isTerminal
    ? '<b>Порядок:</b> сначала скриншот статистики, потом чек.'
    : '';

  const lines = [
    `📸 <b>Сверки</b>`,
    '',
    `📷 Фото <b>1 из ${totalPhotos}</b>: <b>${firstLabel}</b>`,
  ];
  if (orderHint) {
    lines.push('');
    lines.push(orderHint);
  }
  lines.push('');
  lines.push('📎 <i>Нажмите на скрепку → Камера или Галерея</i>');

  await ctx.replyWithHTML(lines.join('\n'), routeSheetKeyboard());
}

async function showPendingCashStatus(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const profile = await ensureProfile(ctx);
  if (!profile) return;

  const pendingCash = getPendingCash(ctx.from.id);
  const amount = Number(pendingCash?.amount || 0);

  if (!Number.isFinite(amount) || amount < 1) {
    await ctx.replyWithHTML('✅ Долгов нет — все деньги сданы.', getMenuForRole(ctx.from.id));
    return;
  }

  if (pendingCash?.confirmationStatus === 'awaiting') {
    await ctx.replyWithHTML('⏳ Вы уже отметили сдачу. Ожидайте подтверждения логиста.', getMenuForRole(ctx.from.id));
    return;
  }

  const formatted = pendingCash?.formatted || formatMoneyRu(amount);
  const numberOnly = formatMoneyRuNumber(amount) || String(formatted || '').replace(/\s*₽$/, '');
  const workplace = pendingCash?.workplace || profile.workplace || 'не указано';
  const fun = String(process.env.FUN_TONE || '').toLowerCase() === 'true';
  const lines = [
    `💵 <b>Деньги к сдаче</b>: <code>${esc(numberOnly)}</code> ₽`,
    `🏬 <b>${esc(workplace)}</b>`,
    ''
  ];
  if (fun) lines.push('😼 Ай-ай, денюжки надо сдать!', '');
  lines.push('Сдали деньги в кассу?');
  await ctx.replyWithHTML(lines.join('\n'), cashSubmitConfirmKeyboard());
}

async function sendHelp(ctx) {
  const role = getUserRole(ctx.from.id);

  if (role === 'logist') {
    const workplace = getUserField(ctx.from.id, 'workplace');
    const features = WORKPLACE_FEATURES[workplace] || {};
    const hasCash = features.cashCollection;
    let logistHelp = '❓ <b>Помощь</b>\n' +
      '━━━━━━━━━━━━━━━\n\n' +
      `1️⃣ <b>Записать время</b> — «${BUTTONS.punchTime}» отметить начало или конец смены.\n` +
      `2️⃣ <b>Открыть ИМ</b> — «${BUTTONS.openShop}» отправить уведомление об открытии магазина в группу.\n`;
    if (hasCash) {
      logistHelp += `3️⃣ <b>Принять наличные</b> — «${BUTTONS.cashCollect}» посмотреть должников и отправить напоминание.\n`;
      logistHelp += `4️⃣ <b>История сборов</b> — «${BUTTONS.cashHistory}» просмотр истории по датам.\n`;
    }
    logistHelp += `${hasCash ? '5️⃣' : '3️⃣'} <b>Таблицы</b> — «${BUTTONS.sheetInfo}» информация о привязке таблиц.\n`;
    logistHelp += `${hasCash ? '6️⃣' : '4️⃣'} <b>Настройки</b> — «${BUTTONS.settings}» магазин, смена сотрудника.\n\n`;
    logistHelp += '📋 Команды:';
    await ctx.replyWithHTML(
      logistHelp,
      Markup.inlineKeyboard([
        [Markup.button.callback('📋 Команды', 'help_commands')]
      ])
    );
    return;
  }

  await ctx.replyWithHTML(
    '❓ <b>Помощь</b>\n' +
    '━━━━━━━━━━━━━━━\n\n' +
    '1️⃣ <b>Первый вход</b> — введите ФИО, номер машины, магазин и устройство.\n' +
    `2️⃣ <b>Записать время</b> — «${BUTTONS.punchTime}» отметить начало или конец смены.\n` +
    `3️⃣ <b>Фото пробега</b> — «${BUTTONS.mileage}» отправьте фото одометра или введите вручную.\n` +
    '   • «📷 Загрузить фото повторно» или «✏️ Ввести вручную» если не распозналось.\n' +
    `4️⃣ <b>Отправить маршрутник</b> — «${BUTTONS.routeSheet}» отправить фото маршрутного листа.\n` +
    `5️⃣ <b>Отправить сверку</b> — «${BUTTONS.reconciliation}» Терминал — 2 фото, Пин-Панель — 1 фото.\n` +
    `6️⃣ <b>Сдать наличные</b> — «${BUTTONS.cashCheck}» показать сумму к сдаче и подтвердить.\n` +
    `7️⃣ <b>Проблема с заказом</b> — «${BUTTONS.issues}» ссылки для решения проблем с заказами.\n` +
    `8️⃣ <b>Рейтинг</b> — «${BUTTONS.leaderBoard}» рейтинг курьеров по заказам.\n` +
    `9️⃣ <b>Настройки</b> — «${BUTTONS.settings}» номер машины, магазин, устройство, сотрудник.\n\n` +
    '📋 Команды:',
    Markup.inlineKeyboard([
      [Markup.button.callback('📋 Команды', 'help_commands')]
    ])
  );
}

async function sendCommandsList(ctx) {
  const isAdmin = isAdminUser(ctx.from.id);
  const role = getUserRole(ctx.from.id);
  let msg = '📋 <b>Команды</b>\n' +
    '━━━━━━━━━━━━━━━\n\n' +
    '<b>Основные:</b>\n' +
    '/help — помощь\n' +
    '/cancel — отмена текущего действия\n\n';

  if (role !== 'logist') {
    msg += '<b>Настройки:</b>\n' +
      '/car — сменить номер машины\n' +
      '/workplace — сменить магазин\n' +
      '/device — сменить устройство\n\n';
  } else {
    msg += '<b>Настройки:</b>\n' +
      '/workplace — сменить магазин\n\n';
  }

  if (isAdmin) {
    msg += '<b>Администратору:</b>\n' +
      '/chatid — информация о чате\n' +
      '/sheet — привязка таблиц\n' +
      '/sheet_access — доступ к «📋 Таблицы»\n' +
      '  <code>/sheet_access</code> — показать список\n' +
      '  <code>/sheet_access 123456789</code> — дать доступ\n' +
      '  <code>/sheet_access - 123456789</code> — убрать доступ\n' +
      '/role — сменить роль пользователя\n\n';
  }

  if (role === 'logist') {
    msg += '<b>Кнопки меню:</b>\n' +
      `⏱ <b>Время</b> — записать старт/конец\n` +
      `💳 <b>Наличные</b> — посмотреть должников, отправить напоминание\n` +
      `📋 <b>Таблицы</b> — информация о привязке таблиц\n` +
      `⚙️ <b>Настройки</b> — магазин, сотрудник`;
  } else {
    msg += '<b>Кнопки меню:</b>\n' +
      `⏱ <b>Время</b> — записать старт/конец\n` +
      `🚗 <b>Пробег</b> — фото одометра → распознавание\n` +
      `📄 <b>Маршрутник</b> — отправить фото\n` +
      `📊 <b>Сверки</b> — фото терминала/пин-панели\n` +
      `💵 <b>Наличные</b> — сумма к сдаче\n` +
      `⚠️ <b>Проблема</b> — решить проблему с заказом\n` +
      `🏆 <b>Лидерборд</b> — рейтинг курьеров\n` +
      `⚙️ <b>Настройки</b> — машина, магазин, устройство, сотрудник`;
  }

  await ctx.replyWithHTML(msg);
}

function parseUpdateNotesFromEnv() {
  const raw = String(process.env.UPDATE_NOTES || '').trim();
  if (!raw) return [];

  return raw
    .split('|')
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 4);
}

function loadChangelog() {
  try {
    if (!fs.existsSync(changelogPath)) return null;
    return JSON.parse(fs.readFileSync(changelogPath, 'utf8'));
  } catch {
    return null;
  }
}

function getLatestChangelogNotes() {
  const changelog = loadChangelog();
  if (!changelog || !Array.isArray(changelog.updates) || changelog.updates.length === 0) return null;

  const latest = changelog.updates[changelog.updates.length - 1];
  if (!latest || !Array.isArray(latest.notes) || latest.notes.length === 0) return null;

  return latest.notes.slice(0, 4);
}

function getChangelogBump() {
  const changelog = loadChangelog();
  if (!changelog || !Array.isArray(changelog.updates) || changelog.updates.length === 0) return 'patch';

  const latest = changelog.updates[changelog.updates.length - 1];
  const bump = String(latest.bump || '').toLowerCase().trim();
  if (bump === 'major' || bump === 'minor') return bump;
  return 'patch';
}

function buildUpdateHighlights(changedFiles = [], version, updates = []) {
  if (Array.isArray(updates) && updates.length > 0) {
    return updates;
  }

  const changelogNotes = getLatestChangelogNotes();
  if (changelogNotes && changelogNotes.length > 0) {
    return changelogNotes;
  }

  const envNotes = parseUpdateNotesFromEnv();
  if (envNotes.length > 0) {
    return envNotes;
  }

  const files = new Set((changedFiles || []).map((file) => String(file || '').toLowerCase()));
  const includesAny = (targets) => targets.some((target) => files.has(target.toLowerCase()));
  const highlights = [];

  if (includesAny(['bot.js'])) {
    highlights.push('🤖 Подправили сценарии работы и стабильность.');
  }

  if (includesAny(['sheetcommand.js', 'googlesheets.js', 'storage.js'])) {
    highlights.push('🗂 Улучшили работу с таблицами и привязками.');
  }

  if (includesAny(['mileageocr.js'])) {
    highlights.push('📸 Улучшили распознавание пробега по фото.');
  }

  if (includesAny(['utils.js'])) {
    highlights.push('🧮 Обновили вспомогательные функции.');
  }

  if (highlights.length === 0) {
    highlights.push('✨ Небольшие улучшения стабильности и удобства.');
  }

  return highlights.slice(0, 4);
}

function formatUpdateMessage(version, changedFiles = [], updates = []) {
  const highlights = buildUpdateHighlights(changedFiles, version, updates);
  const lines = highlights.map((item) => `• ${esc(item)}`).join('\n');

  return (
    `🆕 <b><i>Обновление бота v${esc(version)}</i></b>\n\n` +
    '<b>Коротко, что изменили:</b>\n' +
    `${lines}\n\n` +
    '💙 Хорошей смены!'
  );
}

async function notifyUsersAboutUpdate(version, changedFiles = [], updates = []) {
  const currentVersion = version || getVersion();
  const userIds = getAllUserIds();
  let notified = 0;
  let skipped = 0;
  let failed = 0;

  const message = formatUpdateMessage(currentVersion, changedFiles, updates);

  for (const telegramId of userIds) {
    const lastVersion = getUserField(telegramId, 'version');
    if (lastVersion === currentVersion) {
      skipped++;
      continue;
    }

    try {
      await withTimeout(
        bot.telegram.sendMessage(Number(telegramId), message, {
          parse_mode: 'HTML',
          disable_notification: true
        }),
        10000,
        'update notify'
      );
      setUserField(telegramId, 'version', currentVersion);
      notified++;
    } catch (error) {
      console.error('update notify error', error.message);
      failed++;
    }

    await new Promise((r) => setTimeout(r, 50));
  }

  console.log(`update v${currentVersion} notify summary: total=${userIds.length}, sent=${notified}, skipped=${skipped}, failed=${failed}`);
}

const _pendingUpdates = {};
const PENDING_UPDATES_FILE = path.join(__dirname, 'pending_updates.json');

function loadPendingUpdates() {
  try {
    if (fs.existsSync(PENDING_UPDATES_FILE)) {
      const data = JSON.parse(fs.readFileSync(PENDING_UPDATES_FILE, 'utf8'));
      Object.assign(_pendingUpdates, data);
      console.log('loaded pending updates', Object.keys(data));
    }
  } catch (e) {
    console.error('failed to load pending updates', e.message);
  }
}

function savePendingUpdates() {
  try {
    fs.writeFileSync(PENDING_UPDATES_FILE, JSON.stringify(_pendingUpdates, null, 2));
  } catch (e) {
    console.error('failed to save pending updates', e.message);
  }
}

loadPendingUpdates();

async function askAdminsAboutUpdate(version, changedFiles = [], updates = []) {
  const adminIds = getAdminIds();
  if (adminIds.length === 0) {
    console.log('no admin IDs configured, skipping update approval');
    return;
  }

  const message = formatUpdateMessage(version, changedFiles, updates);
  const previewText = (
    `🔔 <b>Обнаружено обновление v${esc(version)}</b>\n\n` +
    '<b>Предпросмотр сообщения:</b>\n\n' +
    `${message}\n\n` +
    'Отправить уведомление всем пользователям?'
  );

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ Отправить', `upd_send:${version}`),
      Markup.button.callback('✏️ Изменить текст', `upd_edit:${version}`)
    ],
    [Markup.button.callback('⏭️ Пропустить', `upd_skip:${version}`)]
  ]);

  _pendingUpdates[version] = { changedFiles, updates, message };
  savePendingUpdates();

  for (const adminId of adminIds) {
    try {
      await bot.telegram.sendMessage(adminId, previewText, {
        parse_mode: 'HTML',
        ...keyboard
      });
    } catch (error) {
      console.error('admin update ask error', adminId, error.message);
    }
  }
}

bot.action(/^upd_send:(.+)$/, async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    await ctx.answerCbQuery();
    return;
  }
  const version = ctx.match[1];
  const pending = _pendingUpdates[version];
  if (!pending) {
    await ctx.answerCbQuery('⚠️ Обновление уже обработано');
    return;
  }
  delete _pendingUpdates[version];
  savePendingUpdates();
  await ctx.editMessageText('✅ Уведомление отправляется...', { parse_mode: 'HTML' });
  await notifyUsersAboutUpdate(version, pending.changedFiles, pending.updates || []);
  try {
    await ctx.editMessageText(`✅ Уведомление v${esc(version)} отправлено всем пользователям.`, { parse_mode: 'HTML' });
  } catch {}
});

bot.action(/^upd_edit:(.+)$/, async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    await ctx.answerCbQuery();
    return;
  }
  const version = ctx.match[1];
  const pending = _pendingUpdates[version];
  if (!pending) {
    await ctx.answerCbQuery('⚠️ Обновление уже обработано');
    return;
  }
  setState(ctx.from.id, { awaitingUpdateEdit: true, editVersion: version });
  await ctx.replyWithHTML('✏️ <b>Редактирование уведомления</b>\n\nОтправьте новый текст сообщения (без заголовка «Обновление бота v...» и «Хорошей смены» — они добавятся автоматически):');
  await ctx.answerCbQuery();
});

bot.action(/^upd_skip:(.+)$/, async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    await ctx.answerCbQuery();
    return;
  }
  const version = ctx.match[1];
  delete _pendingUpdates[version];
  savePendingUpdates();
  try {
    await ctx.editMessageText(`⏭️ Уведомление v${esc(version)} пропущено.`, { parse_mode: 'HTML' });
  } catch {}
  await ctx.answerCbQuery('Пропущено');
});

async function saveMileageFromState(ctx, mileage, options = {}) {
  const { sourceBuffer, telegram, chatId, fallbackState } = options;
  const replyFn = telegram
    ? (html, extra) => telegram.sendMessage(chatId, html, { parse_mode: 'HTML', ...(extra || {}) })
    : (html, extra) => ctx.replyWithHTML(html, extra);

  const telegramId = ctx.from.id;
  let state = getState(telegramId);
  const mileageValue = parseMileageNumber(mileage);

  // Если состояние очищено (пользователь ушёл в меню) — используем fallback.
  // Если пользователь начал новое фото (fileId изменился) — не пишем старый результат.
  if (!state || !state.mileageRow || !state.day) {
    if (!fallbackState) {
      await replyFn('⚠️ Не удалось записать пробег.\nПопробуйте ещё раз или обратитесь к администратору.');
      return;
    }
    const live = getState(telegramId);
    if (live && live.fileId && live.fileId !== fallbackState.fileId) {
      console.log('mileage: user started new photo, skipping old save');
      return;
    }
    state = fallbackState;
  } else if (state.fileId && fallbackState && state.fileId !== fallbackState.fileId) {
    // Живое состояние есть, но fileId разный — пользователь начал новый пробег
    console.log('mileage: live state has different fileId, skipping old save');
    await replyFn('⚠️ <b>Пробег распознан, но вы начали новое действие.</b>\nЕсли нужно, отправьте фото повторно.', mileageConfirmKeyboard());
    return;
  }

  if (!state || !state.mileageRow || !state.day || !state.stage) {
    await replyFn('⚠️ Не удалось записать пробег.\nПопробуйте ещё раз или обратитесь к администратору.');
    return;
  }

  if (!mileageValue) {
    await replyFn('❌ Неверный пробег. Допустимы только 2-6 цифр.\nНапример: <code>25408</code>');
    return;
  }

  try {
    if (state.stage === 'end') {
      const startCell = getMileageStageCell(state, 'start');

      if (startCell) {
        const sheetContext = resolveSheetInfo(startCell.workplace);
        if (!sheetContext.sheetId) {
          await replyFn(formatNoSheetMessage({
            noSheet: true,
            noSheetForMonth: sheetContext.noSheetForMonth,
            monthKey: sheetContext.monthKey
          }, startCell.workplace));
          return;
        }

        const startRaw = await readCell(startCell.sheetName, startCell.cell, sheetContext.sheetId);
        const startValue = parseMileageNumber(startRaw);
        const maxDelta = getMaxShiftMileageDelta();

        if (startValue && mileageValue < startValue) {
          await replyFn(
            `❌ Пробег конца смены не может быть меньше старта.\n` +
            `Старт: <code>${startValue}</code> км\n` +
            `Введено: <code>${mileageValue}</code> км`
          );
          return;
        }

        if (startValue && (mileageValue - startValue) > maxDelta) {
          await replyFn(
            `❌ Слишком большой прирост пробега за смену.\n` +
            `Старт: <code>${startValue}</code> км\n` +
            `Введено: <code>${mileageValue}</code> км\n` +
            `Максимум за смену: <code>${maxDelta}</code> км`
          );
          return;
        }
      }
    }

    await updateMileage(state.mileageRow, state.day, state.stage, mileageValue, state.workplace);
    console.log('пробег записан');
    addXp(telegramId, getXpForAction('mileage'), 'Запись пробега');
    updateChallengeProgress(telegramId, 'mileages');
    logOcrFeedback(telegramId, state.ocrValue || null, mileageValue, sourceBuffer, {
      stage: state.stage,
      workplace: state.workplace,
      fio: state.fio,
      fileId: state.fileId
    });
    setState(telegramId, {
      ...state,
      awaitingMileagePhoto: false,
      awaitingManualMileage: false,
      photoReceived: true,
      savedMileage: mileageValue,
      mileageProcessing: false
    });
    await replyFn(
      `✅ <b>Пробег сохранён</b>: <code>${mileageValue}</code> км\n\nЕсли неверно — нажмите «Изменить пробег».`,
      mileageSavedKeyboard()
    );
  } catch (error) {
    console.error('ошибка Google Sheets', error);
    await replyFn('⚠️ Не удалось записать пробег.\nПопробуйте ещё раз или обратитесь к администратору.');
  } finally {
    if (telegram) {
      const finalState = getState(telegramId);
      if (finalState) {
        setState(telegramId, { ...finalState, mileageProcessing: false });
      }
    }
  }
}

async function sendPhotoToChat(ctx, fileId, caption, { envChatId, envThreadId, parseMode, fallbackChatId } = {}) {
  let chatId = envChatId ? process.env[envChatId] : null;

  if (!chatId && fallbackChatId) {
    chatId = fallbackChatId;
  }

  if (!chatId) {
    console.log(`${envChatId || 'chatId'} is empty, photo is not forwarded`);
    return false;
  }

  const options = { caption };

  if (parseMode) {
    options.parse_mode = parseMode;
  }

  const threadId = envThreadId ? process.env[envThreadId] : null;
  if (threadId) {
    options.message_thread_id = Number(threadId);
  }

  try {
    await ctx.telegram.sendPhoto(chatId, fileId, options);
    return true;
  } catch (error) {
    console.error('telegram sendPhoto error', error?.message || error);
    return false;
  }
}

async function sendMediaGroupToChat(ctx, items, { envChatId, envThreadId, parseMode, fallbackChatId } = {}) {
  let chatId = envChatId ? process.env[envChatId] : null;

  if (!chatId && fallbackChatId) {
    chatId = fallbackChatId;
  }

  if (!chatId) {
    console.log(`${envChatId || 'chatId'} is empty, media group is not forwarded`);
    return false;
  }

  const media = items.map((item, index) => {
    const entry = {
      type: 'photo',
      media: item.fileId
    };
    if (index === 0 && item.caption) {
      entry.caption = item.caption;
      if (parseMode) {
        entry.parse_mode = parseMode;
      }
    }
    return entry;
  });

  const options = {};
  const threadId = envThreadId ? process.env[envThreadId] : null;
  if (threadId) {
    options.message_thread_id = Number(threadId);
  }

  try {
    await ctx.telegram.sendMediaGroup(chatId, media, options);
    return true;
  } catch (error) {
    console.error('telegram sendMediaGroup error', error?.message || error);
    return false;
  }
}

// Конфиг назначений фото — единая таблица. Если появится новый чат
// (например, для штрафов), добавить запись и одну функцию-обёртку.
const PHOTO_DESTINATIONS = {
  work: {
    envChatId: 'WORK_CHAT_ID',
    envThreadId: 'WORK_THREAD_ID'
  },
  routeSheet: {
    envChatId: 'ROUTE_SHEET_CHAT_ID',
    envThreadId: 'ROUTE_SHEET_THREAD_ID',
    fallbackEnvChatId: 'WORK_CHAT_ID'
  },
  reconciliation: {
    envChatId: 'RECONCILIATION_CHAT_ID',
    envThreadId: 'RECONCILIATION_THREAD_ID',
    fallbackEnvChatId: 'WORK_CHAT_ID',
    parseMode: 'HTML'
  }
};

function forwardPhoto(ctx, fileId, caption, destinationKey) {
  const dest = PHOTO_DESTINATIONS[destinationKey];
  if (!dest) {
    console.error('forwardPhoto: unknown destination', destinationKey);
    return Promise.resolve(false);
  }
  return sendPhotoToChat(ctx, fileId, caption, {
    envChatId: dest.envChatId,
    envThreadId: dest.envThreadId,
    parseMode: dest.parseMode,
    fallbackChatId: dest.fallbackEnvChatId ? process.env[dest.fallbackEnvChatId] : undefined
  });
}

// Обёртки оставлены для читаемости в местах вызова.
const sendPhotoToWorkChat = (ctx, fileId, caption) => forwardPhoto(ctx, fileId, caption, 'work');
const sendPhotoToRouteSheetChat = (ctx, fileId, caption) => forwardPhoto(ctx, fileId, caption, 'routeSheet');
const sendPhotoToReconciliationChat = (ctx, fileId, caption) => forwardPhoto(ctx, fileId, caption, 'reconciliation');

function forwardMediaGroup(ctx, items, destinationKey) {
  const dest = PHOTO_DESTINATIONS[destinationKey];
  if (!dest) {
    console.error('forwardMediaGroup: unknown destination', destinationKey);
    return Promise.resolve(false);
  }
  return sendMediaGroupToChat(ctx, items, {
    envChatId: dest.envChatId,
    envThreadId: dest.envThreadId,
    parseMode: dest.parseMode,
    fallbackChatId: dest.fallbackEnvChatId ? process.env[dest.fallbackEnvChatId] : undefined
  });
}

const sendMediaGroupToReconciliationChat = (ctx, items) => forwardMediaGroup(ctx, items, 'reconciliation');

async function backToMainMenu(ctx) {
  const state = getState(ctx.from.id);

  if (state?.mileageProcessing) {
    await ctx.replyWithHTML('📸 Обработка фото пробега продолжается... результат придёт в новый чат.', getMenuForRole(ctx.from.id));
    return;
  }

  clearState(ctx.from.id);

  const message = state?.savedMileage
    ? '⬅️ Возвращаю в меню.'
    : state?.mileageRow
      ? '⬅️ Возвращаю в меню. Пробег не сохранён.'
      : '⬅️ Возвращаю в меню.';

  await ctx.replyWithHTML(message, getMenuForRole(ctx.from.id));
}

async function showLeaderboardMenu(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  setState(ctx.from.id, { lb_step: 'menu' });
  const settings = getNotificationSettings(ctx.from.id);
  const notifStatus = Object.values(settings).some(v => v) ? 'ВКЛ ✅' : 'ВЫКЛ ❌';
  await ctx.replyWithHTML(
    '🏆 <b>Рейтинг и достижения</b>\n\nВыберите раздел:',
    Markup.inlineKeyboard([
      [Markup.button.callback('📊 Таблица рейтинга', 'lb_table')],
      [Markup.button.callback('🔥 Челленджи недели', 'lb_challenges')],
      [Markup.button.callback('🏆 Мои достижения', 'lb_achievements')],
      [Markup.button.callback('📈 Мой прогресс', 'lb_progress')],
      [Markup.button.callback('❓ Как работает XP', 'lb_xp_info')],
      [Markup.button.callback(`🔔 Уведомления рейтинга: ${notifStatus}`, 'lb_notifications')],
      [Markup.button.callback('🏠 В меню', 'back_to_menu')]
    ])
  );
}

async function showLeaderboardFilter(ctx) {
  setState(ctx.from.id, { lb_step: 'filter' });
  await ctx.replyWithHTML(
    '🏆 <b>Лидерборд 2.0</b>\n\nВыберите тип курьеров:',
    Markup.inlineKeyboard([
      [Markup.button.callback('🚗 Авто', 'lb_filter_auto'), Markup.button.callback('🚶 Пешие', 'lb_filter_pedestrian')],
      [Markup.button.callback('🏁 Все', 'lb_filter_all')],
      [Markup.button.callback('⬅️ Назад', 'lb_back_menu')]
    ])
  );
}

async function showMyAchievements(ctx) {
  const telegramId = ctx.from.id;
  const profile = getFullProfile(telegramId);
  const unlocked = getUnlockedAchievements(telegramId);
  const allAchievements = getAllAchievements();

  let text = '🏆 <b>Мои достижения</b>\n\n';
  if (unlocked.length === 0) {
    text += 'Пока нет разблокированных достижений.\nПродолжайте работать — они появятся!\n\n';
  } else {
    text += `<b>Разблокировано: ${unlocked.length} / ${allAchievements.length}</b>\n\n`;
    for (const ach of unlocked.slice(0, 15)) {
      text += `✅ ${ach.name} — ${ach.desc} (+${ach.reward} XP)\n`;
    }
    if (unlocked.length > 15) {
      text += `\n... и ещё ${unlocked.length - 15} достижений.`;
    }
    text += '\n';
  }

  text += '\n<i>Достижения разблокируются автоматически при выполнении условий.</i>';

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Назад', 'lb_back_menu')]
  ]));
}

async function showMyProgress(ctx) {
  const telegramId = ctx.from.id;
  const profile = getFullProfile(telegramId);
  const xp = getTotalXp(telegramId);
  const rankInfo = formatRankInfo(telegramId, profile.courierType);
  const streak = getStreak(telegramId);

  let text = '📈 <b>Мой прогресс</b>\n\n';
  text += `👤 <b>${esc(profile.fio || 'Курьер')}</b>\n`;
  text += `🚗 Тип: ${profile.courierType === 'pedestrian' ? '🚶 Пеший' : '🚗 Авто'}\n\n`;
  text += `⭐ ${rankInfo}\n\n`;
  text += `🔥 Стрик: ${streak.currentStreak} смен (рекорд: ${streak.maxStreak})\n`;
  text += `💰 Всего XP: ${xp.toLocaleString('ru-RU')}\n`;

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Назад', 'lb_back_menu')]
  ]));
}

async function showXpInfo(ctx) {
  const text =
    '❓ <b>Как работает XP</b>\n\n' +
    'За каждое действие вы получаете очки опыта (XP):\n\n' +
    '⏱ Начало/конец смены — <b>15 XP</b>\n' +
    '📄 Маршрутник — <b>30 XP</b>\n' +
    '📊 Сверка — <b>50 XP</b>\n' +
    '💵 Сдача наличных — <b>80 XP</b>\n' +
    '🚗 Пробег — <b>30 XP</b>\n\n' +
    '🏆 <b>Бонусы:</b>\n' +
    'Топ-10 дня — <b>150 XP</b>\n' +
    'Топ-3 дня — <b>300 XP</b>\n' +
    '🥇 1-е место — <b>800 XP</b>\n\n' +
    '🔥 <b>Стрик:</b> каждые 5 смен подряд — <b>+50 XP</b>\n\n' +
    'С накоплением XP растёт ваш ранг — от Новичка до Короля рейтинга! 👑';

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Назад', 'lb_back_menu')]
  ]));
}

async function showNotificationSettings(ctx) {
  const telegramId = ctx.from.id;
  const settings = getNotificationSettings(telegramId);

  const toggle = (key, label, emoji) => {
    const isOn = settings[key];
    return Markup.button.callback(`${isOn ? '✅' : '❌'} ${label}`, `notif_${key}`);
  };

  await ctx.replyWithHTML(
    '🔔 <b>Настройки уведомлений рейтинга</b>\n\n' +
    'Нажмите, чтобы включить или выключить:\n\n' +
    '✅ — включено\n' +
    '❌ — выключено',
    Markup.inlineKeyboard([
      [toggle('personalRecord', 'Личный рекорд')],
      [toggle('overtake', 'Обгоны в рейтинге')],
      [toggle('workplaceRecord', 'Рекорд точки')],
      [toggle('dailyLeader', 'Лидер дня / сброс')],
      [toggle('top3Change', 'Изменение топ-3')],
      [Markup.button.callback('⬅️ Назад к рейтингу', 'lb_back_menu')]
    ])
  );
}

async function showWeeklyChallenges(ctx) {
  const telegramId = ctx.from.id;
  const profile = getFullProfile(telegramId);
  generateWeeklyChallenges(telegramId, profile.courierType);
  const challenges = getChallenges(telegramId);

  let text = '🔥 <b>Челленджи недели</b>\n\n';
  if (challenges.length === 0) {
    text += 'Пока нет активных челленджей. Приходите в понедельник!\n';
  } else {
    for (const ch of challenges) {
      const status = ch.completed ? '✅ Выполнено' : `⏳ ${ch.current} / ${ch.target}`;
      text += `• <b>${ch.name}</b>\n  ${ch.desc}\n  Награда: <b>${ch.reward} XP</b> — ${status}\n\n`;
    }
  }
  text += '<i>Челленджи обновляются каждый понедельник.</i>';

  await ctx.replyWithHTML(text, Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Назад', 'lb_back_menu')]
  ]));
}

async function showLeaderboardWorkplace(ctx, filter) {
  setState(ctx.from.id, { lb_step: 'workplace', lb_filter: filter });
  const wpButtons = WORKPLACES.map((wp) => {
    const key = WORKPLACE_KEY_MAP[wp] || wp;
    return Markup.button.callback(`🏬 ${wp}`, `lb_wp_${key}`);
  });
  await ctx.replyWithHTML(
    '🏆 <b>Лидерборд</b>\n\nВыберите магазин:',
    Markup.inlineKeyboard([
      wpButtons,
      [Markup.button.callback('🏁 Все магазины', 'lb_wp_all')],
      [Markup.button.callback('⬅️ Назад', 'lb_back_filter')]
    ])
  );
}

async function showLeaderboardPeriod(ctx, filter, workplace) {
  setState(ctx.from.id, { lb_step: 'period', lb_filter: filter, lb_workplace: workplace });
  await ctx.replyWithHTML(
    '🏆 <b>Лидерборд</b>\n\nВыберите период:',
    Markup.inlineKeyboard([
      [
        Markup.button.callback('📅 Неделя', `lb_p_7`),
        Markup.button.callback('📅 Месяц', `lb_p_30`)
      ],
      [
        Markup.button.callback('📅 Год', `lb_p_365`),
        Markup.button.callback('📅 Всё время', `lb_p_0`)
      ],
      [Markup.button.callback('⬅️ Назад', 'lb_back_workplace')]
    ])
  );
}

async function showLeaderboardMode(ctx, filter, workplace, periodDays) {
  setState(ctx.from.id, { lb_step: 'mode', lb_filter: filter, lb_workplace: workplace, lb_period: periodDays });
  const periodLabel = periodDays === 0 ? 'за всё время' : periodDays === 7 ? 'за неделю' : periodDays === 30 ? 'за месяц' : periodDays === 365 ? 'за год' : `за ${periodDays} дней`;
  await ctx.replyWithHTML(
    `🏆 <b>Лидерборд</b>\n${esc(periodLabel)}\n\nВыберите режим:`,
    Markup.inlineKeyboard([
      [Markup.button.callback('📊 По сумме заказов', 'lb_mode_sum')],
      [Markup.button.callback('🔥 Лучший день', 'lb_mode_max')],
      [Markup.button.callback('⬅️ Назад', 'lb_back_period')]
    ])
  );
}

async function showLeaderboardResultV2(ctx) {
  const telegramId = ctx.from.id;
  const state = getState(telegramId);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  const periodDays = state?.lb_period ?? 0;
  const mode = state?.lb_mode || 'sum';

  const showWorkplace = workplace === 'all';
  const entries = calculateLeaderboard(mode, periodDays, workplace, filter);

  const wpLabels = { east: 'ИМ Восток', center: 'ИМ Центр', all: 'Все магазины' };
  const wpLabel = wpLabels[workplace] || workplace;
  const filterLabel = filter === 'auto' ? '🚗 Авто' : filter === 'pedestrian' ? '🚶 Пешие' : '🏁 Все';
  const periodLabel = periodDays === 0 ? 'всё время' : periodDays === 7 ? 'неделя' : periodDays === 30 ? 'месяц' : periodDays === 365 ? 'год' : `${periodDays} дней`;
  const modeLabel = mode === 'max' ? '🔥 Лучший день' : '📊 По сумме';

  const lines = [`🏆 <b>Рейтинг</b>\n${filterLabel} | ${esc(wpLabel)} | ${esc(periodLabel)} | ${modeLabel}\n`];
  lines.push(formatLeaderboard(entries, telegramId, showWorkplace));
  lines.push(`\n⬅️ <i>Нажмите «Назад» или «В меню».</i>`);

  await ctx.replyWithHTML(lines.join('\n'), Markup.inlineKeyboard([
    [Markup.button.callback('⬅️ Назад', 'lb_back_mode')],
    [Markup.button.callback('🏠 В меню', 'back_to_menu')]
  ]));
}

async function handleLeaderboardNotifications(ctx, telegramId, fio, workplace, ordersCount, oldOrders = 0) {
  try {
    // Защита от спама: уведомления только при увеличении счёта
    if (ordersCount <= oldOrders) return;

    const settings = getNotificationSettings(telegramId);
    const dayKey = getLbTodayKey();

    // 1. Личный рекорд
    if (settings.personalRecord) {
      const notifications = checkLeaderboardNotifications(telegramId, fio, workplace, ordersCount);
      for (const notif of notifications) {
        if (notif.type === 'personal_record') {
          await ctx.replyWithHTML(
            `🎉 <b>Новый личный рекорд!</b>\n\nВы доставили <b>${notif.value}</b> заказов за день!` +
            (notif.previous > 0 ? `\nПредыдущий рекорд: ${notif.previous} заказов.` : '')
          );
        }
      }
    }

    // 2. Обгоны в рейтинге
    if (settings.overtake && workplace) {
      const overtaken = findOvertakenCouriers(telegramId, workplace, oldOrders, ordersCount, dayKey)
        .filter(v => getUserRole(v.telegramId) !== 'logist');

      for (const victim of overtaken) {
        const victimSettings = getNotificationSettings(victim.telegramId);
        if (!victimSettings.overtake) continue;
        try {
          await bot.telegram.sendMessage(victim.telegramId,
            `⚠️ <b>Вас обогнали в рейтинге!</b>\n\n` +
            `${esc(fio)} доставил <b>${ordersCount}</b> заказов и обогнал вас.\n` +
            `У вас сейчас <b>${victim.orders}</b> заказов.\n` +
            `🏬 ${esc(workplace)}`,
            { parse_mode: 'HTML' }
          );
        } catch (e) {
          console.error('overtaken notify error', victim.telegramId, e.message || e);
        }
      }

      if (overtaken.length > 0) {
        const names = overtaken.map(v => `${esc(v.fio)} (${v.orders})`).join(', ');
        try {
          await ctx.replyWithHTML(
            `🎉 <b>Вы обогнали в рейтинге!</b>\n\n${names}\n\nТеперь у вас <b>${ordersCount}</b> заказов.`
          );
        } catch (e) {
          console.error('overtaken self notify error', e.message || e);
        }
      }
    }

    // 3. Рекорд точки + лидер дня + топ-3
    if (workplace) {
      const currentTop3 = getDailyTop3(workplace, dayKey);
      const previousTop3 = [];

      // Получаем предыдущий рекорд точки для проверки
      const previousRecord = getWorkplaceRecord(workplace, dayKey);
      const wasRecord = !previousRecord || ordersCount > previousRecord.orders;

      if (wasRecord && settings.workplaceRecord) {
        setWorkplaceRecord(workplace, dayKey, ordersCount, fio);
        await sendWorkplaceRecordNotifications(workplace, dayKey, { fio, orders: ordersCount }, telegramId);
      }

      // Лидер дня
      if (currentTop3[0] && currentTop3[0].telegramId === String(telegramId)) {
        await sendDailyLeaderNotification(workplace, dayKey, currentTop3[0]);
      }

      // Проверка сброса с 1-го места
      const prevLeader = previousRecord ? { telegramId: previousRecord.fio } : null;
      if (previousRecord && previousRecord.fio !== fio && currentTop3[0] && currentTop3[0].telegramId === String(telegramId)) {
        // Найти бывшего лидера по workplace records
        const allIds = getAllUserIds();
        for (const id of allIds) {
          if (id === String(telegramId)) continue;
          const userFio = getUserField(id, 'fio');
          if (userFio === previousRecord.fio) {
            const victimSettings = getNotificationSettings(id);
            if (victimSettings.dailyLeader) {
              try {
                await bot.telegram.sendMessage(id,
                  `📉 <b>Вас сбросили с 1-го места!</b>\n\n` +
                  `${esc(fio)} обогнал вас с <b>${ordersCount}</b> заказами.\n` +
                  `У вас сейчас — посмотрите свою сверку.`,
                  { parse_mode: 'HTML' }
                );
              } catch (e) {
                console.error('leader dethroned notify error', id, e.message || e);
              }
            }
            break;
          }
        }
      }

      // Топ-3 изменился
      if (settings.top3Change) {
        await sendTop3ChangeNotifications(workplace, dayKey, previousTop3, currentTop3, telegramId);
      }
    }
  } catch (err) {
    console.error('leaderboard notification error', err.message || err);
  }
}

function getNotificationSettings(telegramId) {
  const defaults = {
    personalRecord: true,
    overtake: true,
    workplaceRecord: true,
    dailyLeader: true,
    top3Change: true
  };
  const record = getUserField(telegramId, 'notificationSettings');
  if (!record) return defaults;
  try {
    const parsed = typeof record === 'string' ? JSON.parse(record) : record;
    return { ...defaults, ...parsed };
  } catch (e) {
    return defaults;
  }
}

async function sendWorkplaceRecordNotifications(workplace, dayKey, recordInfo, senderId) {
  const settings = getNotificationSettings(senderId);
  if (!settings.workplaceRecord) return;

  const records = getDailyTop3(workplace, dayKey);
  if (records.length === 0) return;

  const record = getWorkplaceRecord(workplace, dayKey);
  if (!record) return;

  let text = `🏆 <b>Новый рекорд точки ${esc(workplace)}!</b>\n\n`;
  text += `🥇 <b>${esc(record.fio)}</b> — <b>${record.orders}</b> заказов (новый рекорд!)\n`;
  if (records[1]) text += `🥈 ${esc(records[1].fio)} — ${records[1].orders} заказов\n`;
  if (records[2]) text += `🥉 ${esc(records[2].fio)} — ${records[2].orders} заказов\n`;
  text += `\n🔥 Рекорд растёт! Продолжайте в том же духе!`;

  const all = getAllUserIds();
  for (const id of all) {
    if (id === String(senderId)) continue;
    const role = getUserRole(id);
    if (role === 'logist') continue;
    const wp = getUserField(id, 'workplace');
    if (wp !== workplace) continue;
    const userSettings = getNotificationSettings(id);
    if (!userSettings.workplaceRecord) continue;
    try {
      await bot.telegram.sendMessage(id, text, { parse_mode: 'HTML' });
    } catch (e) {
      console.error('workplace record notify error', id, e.message || e);
    }
  }
}

async function sendDailyLeaderNotification(workplace, dayKey, leader) {
  const settings = getNotificationSettings(leader.telegramId);
  if (!settings.dailyLeader) return;

  try {
    await bot.telegram.sendMessage(leader.telegramId,
      `🥇 <b>Вы лидер дня в ${esc(workplace)}!</b>\n\n` +
      `<b>${leader.orders}</b> заказов. Так держать!`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('daily leader notify error', leader.telegramId, e.message || e);
  }
}

async function sendTop3ChangeNotifications(workplace, dayKey, previousTop3, currentTop3, senderId) {
  const changed = JSON.stringify(previousTop3.map(x => x.telegramId).sort()) !== JSON.stringify(currentTop3.map(x => x.telegramId).sort());
  if (!changed) return;

  let text = `🔔 <b>Топ-3 ${esc(workplace)} изменился!</b>\n\n`;
  if (currentTop3[0]) text += `🥇 ${esc(currentTop3[0].fio)} — ${currentTop3[0].orders}\n`;
  if (currentTop3[1]) text += `🥈 ${esc(currentTop3[1].fio)} — ${currentTop3[1].orders}\n`;
  if (currentTop3[2]) text += `🥉 ${esc(currentTop3[2].fio)} — ${currentTop3[2].orders}\n`;

  const all = getAllUserIds();
  for (const id of all) {
    if (id === String(senderId)) continue;
    const role = getUserRole(id);
    if (role === 'logist') continue;
    const wp = getUserField(id, 'workplace');
    if (wp !== workplace) continue;
    const settings = getNotificationSettings(id);
    if (!settings.top3Change) continue;

    // Найти позицию получателя
    const recipientEntry = currentTop3.find(x => x.telegramId === id);
    if (recipientEntry) {
      text += `\n🏅 Вы на ${recipientEntry.rank || '?'} месте!`;
    } else {
      const allRecords = [];
      for (const [tid, r] of Object.entries(_getAllRecords())) {
        if (r.workplace === workplace && r.dailyOrders && r.dailyOrders[dayKey]) {
          allRecords.push({ telegramId: tid, orders: r.dailyOrders[dayKey] });
        }
      }
      allRecords.sort((a, b) => b.orders - a.orders);
      const idx = allRecords.findIndex(x => x.telegramId === id);
      if (idx >= 0) text += `\n📊 Вы на ${idx + 1} месте (${allRecords[idx].orders} заказов).`;
    }

    try {
      await bot.telegram.sendMessage(id, text, { parse_mode: 'HTML' });
    } catch (e) {
      console.error('top3 change notify error', id, e.message || e);
    }
  }
}

async function showIssuesMenu(ctx) {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const deliveryUrl = process.env.ISSUE_DELIVERY_URL;
  const flowwowUrl = process.env.ISSUE_FLOWWOW_URL;
  const techsupportUrl = process.env.ISSUE_TECHSUPPORT_URL;

  const buttons = [];

  if (deliveryUrl) {
    buttons.push([Markup.button.url('📦 Доставка — проблемы с нашими заказами', deliveryUrl)]);
  }
  if (flowwowUrl) {
    buttons.push([Markup.button.url('🌸 Flowwow — заказы Flowwow', flowwowUrl)]);
  }
  if (techsupportUrl) {
    buttons.push([Markup.button.url('🔧 Техподдержка — технические проблемы', techsupportUrl)]);
  }

  if (buttons.length === 0) {
    await ctx.replyWithHTML('⚠️ Раздел «Проблема с заказом» временно недоступен.', getMenuForRole(ctx.from.id));
    return;
  }

  buttons.push([Markup.button.callback('⬅️ Назад', 'issues_back')]);

  await ctx.replyWithHTML(
    '⚠️ <b>Проблема с заказом</b>\n\nВыберите чат для обращения:',
    Markup.inlineKeyboard(buttons)
  );
}

bot.start(async (ctx) => {
  console.log('/start');

  if (!getUserField(ctx.from.id, 'fio')) {
    setUserField(ctx.from.id, 'version', getVersion());
    const isNew = markUserSeen(ctx.from.id);
    if (isNew) {
      const firstName = ctx.from.first_name || '';
      const lastName = ctx.from.last_name || '';
      const username = ctx.from.username ? `@${ctx.from.username}` : '';
      const displayName = [firstName, lastName].filter(Boolean).join(' ') || 'Без имени';
      const adminIds = getAdminIds();
      for (const adminId of adminIds) {
        try {
          await ctx.telegram.sendMessage(adminId,
            `🆕 <b>Новый пользователь</b>\n\n` +
            `👤 ${esc(displayName)} ${esc(username)}\n` +
            `🆔 <code>${ctx.from.id}</code>`,
            { parse_mode: 'HTML' }
          );
        } catch (e) { /* ignore */ }
      }
    }
    await ctx.replyWithHTML(`${getTimeGreeting()}! 👋 <b>Привет!</b>\n\nЭто бот для учёта смены, времени и пробега автомобиля.`);
    await askForFio(ctx);
    return;
  }

  setUserField(ctx.from.id, 'version', getVersion());

  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  const role = getUserRole(ctx.from.id);

  if (role === 'logist') {
    await ctx.replyWithHTML(
      `${getTimeGreeting()}, <b>${esc(getEmployeeDisplayName(profile.fio))}</b>! 👋\n\n` +
      `⏱ <b>Записать время</b> — отметить начало или конец смены.\n` +
      `🔓 <b>Открыть ИМ</b> — отправить уведомление об открытии магазина в группу.\n` +
      `💳 <b>Принять наличные</b> — посмотреть курьеров с долгами и отправить напоминание.\n` +
      `📋 <b>Таблицы</b> — информация о привязке таблиц.\n` +
      `⚙️ <b>Настройки</b> — профиль, магазин, смена сотрудника.`,
      logistMainMenu(ctx.from.id)
    );
  } else {
    await ctx.replyWithHTML(
      `${getTimeGreeting()}, <b>${esc(getEmployeeDisplayName(profile.fio))}</b>! 👋\n\n` +
      `⏱ <b>Записать время</b> — отметить начало или конец смены, автоматически выбирается время старта и вносится в таблицу ботом.\n` +
      `🚗 <b>Фото пробега</b> — отправить фото одометра и бот автоматически скинет фото в нужный чат и запишет пробег в таблицу.\n` +
      `📄 <b>Отправить маршрутник</b> — прикрепить маршрутный лист, бот отправит фото в нужный чат.\n` +
      `📊 <b>Отправить сверку</b> — отправить фото сверки, бот отправит фото в нужный чат.\n` +
      `💵 <b>Сдать наличные</b> — отметить сдачу наличных, также укажет сумму нужную сдать и подтверждение сдал/не сдал.\n` +
      `⚠️ <b>Проблема с заказом</b> — сообщить о проблеме, бот предлагает варианты ссылками на нужный чат/бота поддержки.\n` +
      `🏆 <b>Рейтинг</b> — посмотреть рейтинг курьеров.\n` +
      `⚙️ <b>Настройки</b> — профиль, машина, магазин, также смена сотрудника и тд.`,
      getMenuForRole(ctx.from.id)
    );
  }
});

bot.help(sendHelp);

bot.command('car', async (ctx) => {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта команда доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) { await askForFio(ctx); return; }
  await askForCarNumber(ctx, fio);
});

bot.command('workplace', async (ctx) => {
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) { await askForFio(ctx); return; }
  await askForWorkplace(ctx, fio);
});

bot.command('device', async (ctx) => {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта команда доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) { await askForFio(ctx); return; }
  await askForDevice(ctx, fio);
});

// Парсим ADMIN_IDS из .env. Кэшируем результат в _adminIdsCache, чтобы
// не разбирать строку на каждом сообщении (раньше это происходило в
// 5+ местах кода).


async function notifyAdmins(html, options = {}) {
  // Уведомить всех админов. Заблокированный админ пропускается без шума.
  for (const adminId of getAdminIds()) {
    try {
      await bot.telegram.sendMessage(adminId, html, { parse_mode: 'HTML', ...options });
    } catch (e) {
      console.error('admin notify failed', adminId, e.message);
    }
  }
}

bot.command('chatid', async (ctx) => {
  await ctx.replyWithHTML(
    `📍 <b>Chat info</b>\n\nchat_id: <code>${ctx.chat.id}</code>\nmessage_thread_id: <code>${ctx.message.message_thread_id || 'нет'}</code>`
  );
});

bot.command('sheet_access', async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    return;
  }

  const args = (ctx.message.text || '').replace(/^\/sheet_access\s*/, '').trim().split(/\s+/);

  if (args.length === 1 && args[0] === '') {
    const users = getSheetAccessUsers();
    const adminIds = getAdminIds();
    let msg = '📋 <b>Доступ к Таблицам</b>\n\n';
    msg += '🔑 <b>Администраторы:</b>\n';
    for (const id of adminIds) {
      msg += `   • <code>${id}</code>\n`;
    }
    msg += '\n👥 <b>Допущенные пользователи:</b>\n';
    if (users.length === 0) {
      msg += '   (пусто)\n';
    } else {
      for (const id of users) {
        msg += `   • <code>${id}</code>\n`;
      }
    }
    msg += '\n<b>Команды:</b>\n';
    msg += '<code>/sheet_access 123456789</code> — дать доступ\n';
    msg += '<code>/sheet_access - 123456789</code> — убрать доступ';
    await ctx.replyWithHTML(msg);
    return;
  }

  if (args[0] === '-' || args[0] === 'del' || args[0] === 'remove') {
    const targetId = Number(args[1]);
    if (!Number.isFinite(targetId) || targetId <= 0) {
      await ctx.replyWithHTML('❌ Неверный Telegram ID.');
      return;
    }
    const removed = removeSheetAccessUser(targetId);
    if (removed) {
      await ctx.replyWithHTML(`✅ Доступ к Таблицам убран для <code>${targetId}</code>`);
    } else {
      await ctx.replyWithHTML(`ℹ️ Пользователь <code>${targetId}</code> не имел доступа.`);
    }
    return;
  }

  const targetId = Number(args[0]);
  if (!Number.isFinite(targetId) || targetId <= 0) {
    await ctx.replyWithHTML('❌ Неверный Telegram ID. Используйте: <code>/sheet_access 123456789</code>');
    return;
  }

  const added = addSheetAccessUser(targetId);
  if (added) {
    await ctx.replyWithHTML(`✅ Доступ к Таблицам предоставлен для <code>${targetId}</code>\n\nПользователь увидит кнопку «📋 Таблицы» в Настройках.`);
  } else {
    await ctx.replyWithHTML(`ℹ️ Пользователь <code>${targetId}</code> уже имеет доступ.`);
  }
});

bot.command('role', async (ctx) => {
  if (!isAdminUser(ctx.from.id)) {
    return;
  }

  const args = (ctx.message.text || '').replace(/^\/role\s*/, '').trim().split(/\s+/);

  if (args.length < 2) {
    await ctx.replyWithHTML(
      '🔑 <b>Смена роли</b>\n\n' +
      'Использование: <code>/role &lt;telegram_id&gt; &lt;courier|logist&gt;</code>\n\n' +
      'Примеры:\n' +
      '<code>/role 123456789 courier</code> — сделать курьером\n' +
      '<code>/role 123456789 logist</code> — сделать логистом'
    );
    return;
  }

  const targetId = args[0];
  const newRole = args[1].toLowerCase();

  if (newRole !== 'courier' && newRole !== 'logist') {
    await ctx.replyWithHTML('❌ Роль должна быть <code>courier</code> или <code>logist</code>.');
    return;
  }

  const currentFio = getUserField(targetId, 'fio');
  if (!currentFio) {
    await ctx.replyWithHTML(`❌ Пользователь <code>${targetId}</code> не найден.`);
    return;
  }

  const oldRole = getUserRole(targetId);
  const displayRole = newRole === 'logist' ? 'Логист' : 'Курьер';
  const oldDisplayRole = oldRole === 'logist' ? 'Логист' : 'Курьер';

  setUserField(targetId, 'role', newRole);

  if (newRole === 'logist') {
    const carNumber = getUserField(targetId, 'carNumber');
    const device = getUserField(targetId, 'device');
    if (carNumber) setUserField(targetId, 'carNumber', null);
    if (device) setUserField(targetId, 'device', null);
  }

  await ctx.replyWithHTML(
    `✅ Роль изменена: <b>${esc(currentFio)}</b> (<code>${targetId}</code>)\n\n` +
    `${oldDisplayRole} → ${displayRole}`
  );
});

function formatNoSheetMessage(result, workplace) {
  if (result?.noSheetForMonth && result?.monthKey) {
    return `❌ Для магазина <b>${esc(workplace)}</b> не привязана таблица на месяц <code>${esc(result.monthKey)}</code>.\nОбратитесь к администратору.`;
  }

  if (result?.noSheet) {
    return '❌ Таблица не привязана для вашего магазина.\nОбратитесь к администратору.';
  }

  return '❌ Не удалось найти сотрудника в таблице.';
}

const ocrFeedbackPath = path.join(__dirname, 'ocr_feedback.json');
const MAX_OCR_FEEDBACK = LIMITS.MAX_OCR_FEEDBACK;

function logOcrFeedback(telegramId, ocrMileage, confirmedMileage, sourceBuffer, meta = {}) {
  if (!Number.isFinite(confirmedMileage) || confirmedMileage <= 0) return;

  const isMismatch = ocrMileage !== confirmedMileage;

  if (isMismatch) {
    try {
      let feedback = [];
      try {
        if (fs.existsSync(ocrFeedbackPath)) {
          feedback = JSON.parse(fs.readFileSync(ocrFeedbackPath, 'utf8'));
        }
      } catch (e) { /* ignore */ }

      feedback.push({
        ocr: ocrMileage,
        confirmed: confirmedMileage,
        diff: confirmedMileage - (ocrMileage || 0),
        date: new Date().toISOString(),
        userId: telegramId
      });

      if (feedback.length > MAX_OCR_FEEDBACK) {
        feedback = feedback.slice(-MAX_OCR_FEEDBACK);
      }

      fs.writeFileSync(ocrFeedbackPath, JSON.stringify(feedback, null, 2), 'utf8');
    } catch (error) {
      console.error('OCR feedback log error', error.message);
    }

    if (sourceBuffer) {
      saveOcrDebugImage(sourceBuffer, {
        status: 'ocr_mismatch',
        ocrResult: ocrMileage,
        userCorrectedValue: confirmedMileage,
        telegramId,
        stage: meta.stage || null,
        workplace: meta.workplace || null,
        fio: meta.fio || null,
        fileId: meta.fileId || null
      });
    }
  } else if (ocrMileage === confirmedMileage && ocrMileage !== null) {
    updateOcrDebugStatus(meta.fileId, 'confirmed_ok');
  }
}

function parseMileageNumber(value) {
  const text = String(value || '').replace(/\D/g, '');
  if (!text) return null;

  const number = Number(text);
  if (!Number.isInteger(number)) return null;
  if (text.length < 2 || text.length > 6) return null;

  return number;
}

function getMaxShiftMileageDelta() {
  const value = Number(process.env.OCR_MAX_SHIFT_DELTA || 800);
  if (!Number.isFinite(value) || value < 0) return 800;
  return value;
}

async function buildMileageRecognitionOptions(state) {
  const options = {
    minMileage: getMinMileageThreshold(),
    maxMileage: null,
    stage: state?.stage || null
  };

  if (state?.stage === 'end') {
    try {
      const startCell = getMileageStageCell(state, 'start');
      if (startCell) {
        const sheetContext = resolveSheetInfo(startCell.workplace);
        if (sheetContext.sheetId) {
          const startRaw = await readCell(startCell.sheetName, startCell.cell, sheetContext.sheetId);
          const startMileage = parseMileageNumber(startRaw);
          if (startMileage) {
            options.maxMileage = startMileage + getMaxShiftMileageDelta();
            options.startMileage = startMileage;
            options.minMileage = Math.max(options.minMileage, startMileage);
          }
        }
      }
    } catch (error) {
      console.error('mileage recognition options error (stage=end)', error.message || error);
    }
  } else if (state?.stage === 'start') {
    try {
      const endCell = getMileageStageCell(state, 'end');
      if (endCell) {
        const sheetContext = resolveSheetInfo(endCell.workplace);
        if (sheetContext.sheetId) {
          const endRaw = await readCell(endCell.sheetName, endCell.cell, sheetContext.sheetId);
          const prevEndMileage = parseMileageNumber(endRaw);
          if (prevEndMileage) {
            const prevMinMileage = Math.max(prevEndMileage - getMaxShiftMileageDelta(), getMinMileageThreshold());
            options.minMileage = prevMinMileage;
            options.prevEndMileage = prevEndMileage;
          }
        }
      }
    } catch (error) {
      console.error('mileage recognition options error (stage=start)', error.message || error);
    }
  }

  return options;
}

function getMileageColumnsForState(workplace, day) {
  const base = getMileageColumnsByDay(day);
  const offset = getSheetConfig(workplace)?.mileageDayOffset || 0;

  return {
    startColumn: base.startColumn + offset,
    endColumn: base.endColumn + offset,
    totalColumn: base.totalColumn + offset
  };
}

function getMileageStageCell(state, stage = state?.stage) {
  if (!state?.mileageRow || !state?.day) return null;

  const workplace = state.workplace || getUserField(state.telegramId, 'workplace');
  if (!workplace) return null;

  const config = getSheetConfig(workplace);
  const columns = getMileageColumnsForState(workplace, state.day);
  const column = stage === 'start' ? columns.startColumn : columns.endColumn;

  return {
    workplace,
    sheetName: config.mileageSheet,
    cell: `${getColumnLetter(column)}${state.mileageRow}`
  };
}

registerSheetCommand(bot, { esc, workplaces: WORKPLACES, isAdminUser });

bot.command('cancel', async (ctx) => {
  await backToMainMenu(ctx);
});

bot.action('back_to_menu', async (ctx) => {
  await ctx.answerCbQuery();
  await backToMainMenu(ctx);
});

bot.action('show_my_id', async (ctx) => {
  await ctx.answerCbQuery();
  const userId = ctx.from.id;
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  const username = ctx.from.username ? `@${ctx.from.username}` : '';
  const displayName = [firstName, lastName].filter(Boolean).join(' ') || 'Без имени';

  await ctx.replyWithHTML(
    `🆔 <b>Ваш Telegram ID:</b> <code>${userId}</code>\n\n` +
    'Отправьте этот ID администратору для получения доступа.'
  );

  // Параллельно уведомляем админов
  for (const adminId of getAdminIds()) {
    try {
      await ctx.telegram.sendMessage(adminId,
        `🆔 <b>Запрос доступа к Таблицам</b>\n\n` +
        `👤 ${esc(displayName)} ${esc(username)}\n` +
        `🆔 <code>${userId}</code>\n\n` +
        `Дать доступ: <code>/sheet_access ${userId}</code>`,
        { parse_mode: 'HTML' }
      );
    } catch (e) { /* админ заблокирован — пропускаем */ }
  }
});

bot.action('issues_back', async (ctx) => {
  await ctx.answerCbQuery();
  try {
    await ctx.deleteMessage();
  } catch (e) { /* сообщение уже удалено */ }
  await backToMainMenu(ctx);
});

const _workplaceKeys = Object.values(WORKPLACE_KEY_MAP).concat(['all']).join('|');

bot.action('lb_table', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardFilter(ctx);
});

bot.action('lb_challenges', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showWeeklyChallenges(ctx);
});

bot.action('lb_achievements', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showMyAchievements(ctx);
});

bot.action('lb_progress', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showMyProgress(ctx);
});

bot.action('lb_xp_info', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showXpInfo(ctx);
});

bot.action('lb_back_menu', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMenu(ctx);
});

bot.action('lb_notifications', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showNotificationSettings(ctx);
});

const NOTIFICATION_KEYS = ['personalRecord', 'overtake', 'workplaceRecord', 'dailyLeader', 'top3Change'];
for (const key of NOTIFICATION_KEYS) {
  bot.action(`notif_${key}`, async (ctx) => {
    await ctx.answerCbQuery();
    const telegramId = ctx.from.id;
    const current = getNotificationSettings(telegramId);
    current[key] = !current[key];
    setUserField(telegramId, 'notificationSettings', JSON.stringify(current));
    try { await ctx.deleteMessage(); } catch {}
    await showNotificationSettings(ctx);
  });
}

bot.action('lb_filter_auto', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, 'auto');
});

bot.action('lb_filter_pedestrian', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, 'pedestrian');
});

bot.action('lb_filter_all', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, 'all');
});

bot.action(new RegExp(`^lb_wp_(${_workplaceKeys})$`), async (ctx) => {
  await ctx.answerCbQuery();
  const workplace = ctx.match[1];
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardPeriod(ctx, filter, workplace);
});

bot.action('lb_wp_all', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardPeriod(ctx, filter, 'all');
});

bot.action(/^lb_p_(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery();
  const days = Number(ctx.match[1]);
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMode(ctx, filter, workplace, days);
});

bot.action('lb_mode_sum', async (ctx) => {
  await ctx.answerCbQuery();
  setState(ctx.from.id, { ...getState(ctx.from.id), lb_mode: 'sum' });
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardResultV2(ctx);
});

bot.action('lb_mode_max', async (ctx) => {
  await ctx.answerCbQuery();
  setState(ctx.from.id, { ...getState(ctx.from.id), lb_mode: 'max' });
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardResultV2(ctx);
});

bot.action('lb_back_filter', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMenu(ctx);
});

bot.action('lb_back_workplace', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardWorkplace(ctx, filter);
});

bot.action('lb_back_period', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardPeriod(ctx, filter, workplace);
});

bot.action('lb_back_mode', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const filter = state?.lb_filter || 'all';
  const workplace = state?.lb_workplace || 'all';
  const periodDays = state?.lb_period ?? 0;
  try { await ctx.deleteMessage(); } catch {}
  await showLeaderboardMode(ctx, filter, workplace, periodDays);
});

bot.action('route_sheet_done', async (ctx) => {
  await ctx.answerCbQuery('Готово');
  const state = getState(ctx.from.id);
  // Отчётом завершения может быть и «маршрутный лист», и «сверки»
  // (обе используют routeSheetKeyboard). Сообщение нейтрально — просто
  // финализируем и возвращаем в меню.
  clearState(ctx.from.id);
  if (state?.awaitingReconciliationPhoto) {
    const sent = state.reconciliationPhotosSent || 0;
    await ctx.replyWithHTML(
      sent > 0
        ? `✅ Завершено. Отправлено фото: <b>${sent}</b>.`
        : '✅ Завершено. Фото не отправлены.',
      courierMainMenu(ctx.from.id)
    );
    return;
  }
  // Маршрутник завершён — начисляем XP
  addXp(ctx.from.id, getXpForAction('routeSheet'), 'Маршрутник');
  updateChallengeProgress(ctx.from.id, 'routeSheets');
  await ctx.replyWithHTML('✅ Завершено. Спасибо.', courierMainMenu(ctx.from.id));
});

bot.action('help_commands', async (ctx) => {
  await ctx.answerCbQuery();
  await sendCommandsList(ctx);
});

bot.action('confirm_switch_user', async (ctx) => {
  await ctx.answerCbQuery();
  deleteUser(ctx.from.id);
  setState(ctx.from.id, { awaitingFio: true });
  await ctx.replyWithHTML('👤 <b>Смена сотрудника</b>\n\nПредыдущие данные удалены.\nВведите имя и фамилию как в таблице.');
});

bot.action('role_courier', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const state = getState(telegramId);
  if (!state?.awaitingRoleChoice) {
    await ctx.replyWithHTML('⚠️ Выбор роли устарел. Нажмите /start.', getMenuForRole(telegramId));
    return;
  }
  setUserField(telegramId, 'role', 'courier');
  setUserField(telegramId, 'courierType', 'auto');
  if (state?.workplace) {
    setUserField(telegramId, 'workplace', state.workplace);
  }
  clearState(telegramId);
  await ctx.replyWithHTML('✅ Роль: <b>Курьер</b> (авто).\n\nТеперь введите номер машины.');
  await askForCarNumber(ctx, state.fio);
});

bot.action('role_logist', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const state = getState(telegramId);
  if (!state?.awaitingRoleChoice) {
    await ctx.replyWithHTML('⚠️ Выбор роли устарел. Нажмите /start.', getMenuForRole(telegramId));
    return;
  }
  setUserField(telegramId, 'role', 'logist');
  clearState(telegramId);
  await ctx.replyWithHTML('✅ Роль: <b>Логист</b>\n\nТеперь выберите ваш магазин.', logistMainMenu(ctx.from.id));
  await askForWorkplace(ctx, state.fio);
});

bot.action('cash_submit_yes', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const pendingCash = getPendingCash(telegramId);
  const amount = Number(pendingCash?.amount || 0);

  if (!Number.isFinite(amount) || amount < 1) {
    await ctx.replyWithHTML('✅ Долгов нет — все деньги сданы.', getMenuForRole(telegramId));
    return;
  }

  const formatted = pendingCash?.formatted || formatMoneyRu(amount);
  const courierFio = getUserField(telegramId, 'fio') || 'Неизвестный';
  const workplace = pendingCash?.workplace || getUserField(telegramId, 'workplace') || 'не указано';

  const wpFeatures = WORKPLACE_FEATURES[workplace];
  if (!wpFeatures || !wpFeatures.cashCollection) {
    clearPendingCashAndReminders(telegramId);
    logCashAction({
      logistId: null,
      logistFio: null,
      courierId: String(telegramId),
      courierFio: courierFio,
      workplace: workplace,
      amount: amount,
      action: 'self_cleared'
    });
    addXp(telegramId, getXpForAction('cashSubmit'), 'Сдача наличных');
    updateChallengeProgress(telegramId, 'cashSubmits');
    try {
      await ctx.editMessageText(`✅ <b>${esc(courierFio)}</b>, сдача <code>${esc(formatted)}</code> ₽ подтверждена.`);
    } catch (e) { /* ignore */ }
    await ctx.replyWithHTML(
      `✅ <b>Сдача подтверждена</b>\n\n` +
      `Вы сдали <code>${esc(formatted)}</code> ₽.\n` +
      `Спасибо!`,
      getMenuForRole(telegramId)
    );
    return;
  }

  setCashConfirmationStatus(telegramId, 'awaiting');

  logCashAction({
    logistId: null,
    logistFio: null,
    courierId: String(telegramId),
    courierFio: courierFio,
    workplace: workplace,
    amount: amount,
    action: 'self_cleared_requested'
  });

  await notifyLogistsAboutSelfClearance(telegramId, courierFio, amount, formatted, workplace);

  try {
    await ctx.editMessageText('⏳ Запрос отправлен. Ожидайте подтверждения логиста.');
  } catch (e) { /* ignore */ }

  await ctx.replyWithHTML(
    `⏳ <b>Запрос отправлен</b>\n\n` +
    `Вы отметили сдачу <code>${esc(formatted)}</code> ₽.\n` +
    `Ожидайте подтверждения от логиста.`,
    getMenuForRole(telegramId)
  );
});

bot.action('cash_submit_no', async (ctx) => {
  await ctx.answerCbQuery('❌ Отложено');
  const fun = String(process.env.FUN_TONE || '').toLowerCase() === 'true';
  const message = fun
    ? '😼 Тогда бегом сдавать деньги! Котоконтроль не дремлет 🐾\n\nКогда сдадите — нажмите «💵 Деньги к сдаче» и подтвердите.'
    : '⚠️ Не забудьте сдать деньги.\n\nКогда сдадите — нажмите «💵 Деньги к сдаче» и подтвердите.';
  await ctx.replyWithHTML(message, getMenuForRole(ctx.from.id));
});

bot.action(/^d_(\d+)$/, async (ctx) => {
  const courierId = ctx.match[1];
  await pokeCourier(ctx, courierId);
});

bot.action(/^ack_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('⚠️ Напоминание устарело или уже обработано.'); } catch (e) { /* ignore */ }
    return;
  }

  if (reminder.status !== 'reminded' && reminder.status !== 'acknowledged') {
    try { await ctx.editMessageText('⚠️ Напоминание уже обработано.'); } catch (e) { /* ignore */ }
    return;
  }

  updateReminder(shortId, { status: 'acknowledged' });

  const courierFio = reminder.courierFio;
  const formatted = reminder.formatted;
  const logistId = reminder.logistId;

  logCashAction({
    logistId: logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'acknowledged'
  });

  try {
    await ctx.editMessageText(
      `✅ Отметка получена. Когда сдадите — нажмите «Сдал».\n\n` +
      `💶 К сдаче: <code>${esc(formatted)}</code> ₽`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('✅ Сдал', `c_${shortId}`)]
          ]
        }
      }
    );
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(logistId,
      `🏃 <b>${esc(courierFio)}</b> уже бежит сдавать <code>${esc(formatted)}</code> ₽`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify logist about acknowledgement', e.message);
  }
});

bot.action(/^c_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('⚠️ Напоминание устарело или уже обработано.'); } catch (e) { /* ignore */ }
    return;
  }

  if (reminder.status === 'approved' || reminder.status === 'declined') {
    try { await ctx.editMessageText('✅ Наличные уже обработаны.'); } catch (e) { /* ignore */ }
    return;
  }

  updateReminder(shortId, { status: 'confirmed' });

  logCashAction({
    logistId: reminder.logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: reminder.courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'confirmed'
  });

  try {
    await ctx.editMessageText('⏳ Логист проверяет...', { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    const sent = await bot.telegram.sendMessage(reminder.logistId,
      `✅ <b>${esc(reminder.courierFio)}</b> сдал <code>${esc(reminder.formatted)}</code> ₽\n\nПодтвердите сдачу:`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('✅ Подтвердить', `appr_${shortId}`)],
            [Markup.button.callback('❌ Отклонить', `decl_${shortId}`)]
          ]
        }
      }
    );
    updateReminder(shortId, { logistMsgId: sent.message_id });
  } catch (e) {
    console.error('failed to notify logist about confirmation', e.message);
  }
});

bot.action(/^appr_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('⚠️ Напоминание устарело.'); } catch (e) { /* ignore */ }
    return;
  }

  clearPendingCashAndReminders(reminder.courierId);

  logCashAction({
    logistId: reminder.logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: reminder.courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'approved'
  });

  addXp(reminder.courierId, getXpForAction('cashSubmit'), 'Сдача наличных (подтверждено)');
  updateChallengeProgress(reminder.courierId, 'cashSubmits');

  deleteReminder(shortId);

  try {
    await ctx.editMessageText(`✅ Подтверждено: <b>${esc(reminder.courierFio)}</b> сдал <code>${esc(reminder.formatted)}</code> ₽`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(reminder.courierId,
      `✅ <b>${esc(reminder.logistFio)}</b> подтвердил сдачу <code>${esc(reminder.formatted)}</code> ₽\n\nСпасибо!`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify courier about approval', e.message);
  }

  await sendFunReaction(ctx, 'success');
});

bot.action(/^decl_([0-9a-f]+)$/, async (ctx) => {
  const shortId = ctx.match[1];
  await ctx.answerCbQuery();

  const reminder = getReminder(shortId);
  if (!reminder) {
    try { await ctx.editMessageText('⚠️ Напоминание устарело.'); } catch (e) { /* ignore */ }
    return;
  }

  logCashAction({
    logistId: reminder.logistId,
    logistFio: reminder.logistFio,
    courierId: reminder.courierId,
    courierFio: reminder.courierFio,
    workplace: reminder.workplace,
    amount: reminder.amount,
    action: 'declined'
  });

  updateReminder(shortId, { status: 'declined' });

  try {
    await ctx.editMessageText(`❌ Отклонено: <b>${esc(reminder.courierFio)}</b>`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(reminder.courierId,
      `❌ <b>${esc(reminder.logistFio)}</b> отклонил сдачу.\n\nПроверьте сумму и нажмите «Сдал» снова.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [Markup.button.callback('✅ Сдал', `c_${shortId}`)]
          ]
        }
      }
    );
  } catch (e) {
    console.error('failed to notify courier about decline', e.message);
  }
});

bot.action(/^sc_appr_(\d+)$/, async (ctx) => {
  const courierId = ctx.match[1];
  await ctx.answerCbQuery('✅ Сдача подтверждена');

  const pendingCash = getPendingCash(courierId);
  if (!pendingCash || pendingCash.confirmationStatus !== 'awaiting') {
    try { await ctx.editMessageText('✅ Уже подтверждено другим логистом.'); } catch (e) { /* ignore */ }
    return;
  }

  const approverId = String(ctx.from.id);

  if (approverId === courierId) {
    await ctx.answerCbQuery('⛔ Вы не можете подтвердить свою сдачу.');
    return;
  }
  if (getUserRole(approverId) !== 'logist') {
    await ctx.answerCbQuery('⛔ Только логист может подтверждать сдачу.');
    return;
  }
  const approverWorkplace = getUserField(approverId, 'workplace');
  const cashWorkplace = pendingCash.workplace || getUserField(courierId, 'workplace') || '';
  if (approverWorkplace !== cashWorkplace) {
    await ctx.answerCbQuery('⛔ Вы не привязаны к этому магазину.');
    return;
  }

  const courierFio = getUserField(courierId, 'fio') || 'Неизвестный';
  const amount = Number(pendingCash.amount || 0);
  const formatted = pendingCash.formatted || formatMoneyRu(amount);
  const workplace = pendingCash.workplace || getUserField(courierId, 'workplace') || 'не указано';
  const logistId = approverId;
  const logistFio = getUserField(logistId, 'fio') || 'Логист';

  clearPendingCashAndReminders(courierId);

  addXp(courierId, getXpForAction('cashSubmit'), 'Сдача наличных (self-clearance)');
  updateChallengeProgress(courierId, 'cashSubmits');

  logCashAction({
    logistId: logistId,
    logistFio: logistFio,
    courierId: courierId,
    courierFio: courierFio,
    workplace: workplace,
    amount: amount,
    action: 'logist_approved'
  });

  try {
    await ctx.editMessageText(`✅ Подтверждено: <b>${esc(courierFio)}</b> сдал <code>${esc(formatted)}</code> ₽`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(courierId,
      `✅ <b>${esc(logistFio)}</b> подтвердил сдачу <code>${esc(formatted)}</code> ₽\n\nСпасибо!`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify courier about sc approval', e.message);
  }
});

bot.action(/^sc_decl_(\d+)$/, async (ctx) => {
  const courierId = ctx.match[1];
  await ctx.answerCbQuery('❌ Сдача отклонена');

  const pendingCash = getPendingCash(courierId);
  if (!pendingCash || pendingCash.confirmationStatus !== 'awaiting') {
    try { await ctx.editMessageText('⚠️ Запрос уже обработан.'); } catch (e) { /* ignore */ }
    return;
  }

  const declinerId = String(ctx.from.id);

  if (declinerId === courierId) {
    await ctx.answerCbQuery('⛔ Вы не можете отклонить свою сдачу.');
    return;
  }
  if (getUserRole(declinerId) !== 'logist') {
    await ctx.answerCbQuery('⛔ Только логист может отклонять сдачу.');
    return;
  }
  const declinerWorkplace = getUserField(declinerId, 'workplace');
  if (declinerWorkplace !== (pendingCash.workplace || '')) {
    await ctx.answerCbQuery('⛔ Вы не привязаны к этому магазину.');
    return;
  }

  setCashConfirmationStatus(courierId, null);

  const courierFio = getUserField(courierId, 'fio') || 'Неизвестный';
  const logistId = declinerId;
  const logistFio = getUserField(logistId, 'fio') || 'Логист';

  logCashAction({
    logistId: logistId,
    logistFio: logistFio,
    courierId: courierId,
    courierFio: courierFio,
    workplace: pendingCash.workplace || 'не указано',
    amount: Number(pendingCash.amount || 0),
    action: 'declined'
  });

  try {
    await ctx.editMessageText(`❌ Отклонено: <b>${esc(courierFio)}</b>`, { parse_mode: 'HTML' });
  } catch (e) { /* ignore */ }

  try {
    await bot.telegram.sendMessage(courierId,
      `❌ <b>${esc(logistFio)}</b> отклонил сдачу.\n\nПроверьте сумму и попробуйте снова.`,
      { parse_mode: 'HTML' }
    );
  } catch (e) {
    console.error('failed to notify courier about sc decline', e.message);
  }
});

bot.action(/^ch_(\d{4}-\d{2}-\d{2})$/, async (ctx) => {
  const dateStr = ctx.match[1];
  await ctx.answerCbQuery();
  await showCashHistoryForDate(ctx, dateStr);
});

bot.action('edit_time', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);

  if (!state?.awaitingTimeChange || !state?.courierRow || !state?.day || !state?.stage) {
    await ctx.replyWithHTML(`⚠️ Сначала нажмите «${BUTTONS.punchTime}».`, getMenuForRole(ctx.from.id));
    return;
  }

  setState(ctx.from.id, {
    ...state,
    awaitingTimeChange: false,
    awaitingManualTime: true
  });

  await ctx.replyWithHTML(
    `✏️ <b>Изменение времени</b>\n\n` +
    `Этап: <b>${esc(formatStage(state.stage))}</b>\n\n` +
    `Введите время в любом формате:\n` +
    `• целое число — <code>7</code>\n` +
    `• с половиной — <code>7,5</code> или <code>7.5</code>\n` +
    `• часы:минуты — <code>07:30</code>, <code>07:44</code>, <code>08.46</code>, <code>8 14</code>\n\n` +
    `Минуты округлятся до ближайших 30 (08:14 → 8, 08:46 → 9).`,
    getMenuForRole(ctx.from.id)
  );
});

bot.action('retry_mileage_photo', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);

  if (!state?.mileageRow || !state?.day || !state?.stage) {
    await ctx.replyWithHTML(`⚠️ Сначала нажмите «${BUTTONS.mileage}».`, getMenuForRole(ctx.from.id));
    return;
  }

  setState(ctx.from.id, {
    ...state,
    mileageProcessing: false,
    awaitingMileagePhoto: true,
    awaitingManualMileage: false,
    recognizedMileage: null,
    ocrValue: null
  });

  await ctx.replyWithHTML('📷 Отправьте новое фото пробега крупным планом или нажмите «⏭️ Пропустить».', skipMileageKeyboard());
});

async function replaceMileageFlow(ctx, stage) {
  const profile = await ensureProfile(ctx);

  if (!profile) {
    return;
  }

  try {
    const result = await prepareMileage(profile.fio, profile.workplace, stage);

    if (result.notFound) {
      const msg = formatNoSheetMessage(result, profile.workplace);
      await ctx.replyWithHTML(msg);
      return;
    }

    setState(ctx.from.id, makeMileageState(ctx.from.id, applyProfile(result, profile), { source: 'mileage' }));
    console.log('ожидание замены пробега', stage);
    await ctx.replyWithHTML(`📷 <b>Замена пробега</b>\n\nОтправьте фото для: <b>${esc(formatStage(stage))}</b>`, skipMileageKeyboard());
  } catch (error) {
    console.error('ошибка Google Sheets', error);
    await ctx.replyWithHTML('⚠️ Не удалось подготовить замену пробега.\nПопробуйте ещё раз или обратитесь к администратору.');
  }
}

bot.action('replace_mileage_start', async (ctx) => {
  await ctx.answerCbQuery();
  await replaceMileageFlow(ctx, 'start');
});

bot.action('replace_mileage_end', async (ctx) => {
  await ctx.answerCbQuery();
  await replaceMileageFlow(ctx, 'end');
});

// Фабрика обработчиков для replace_start / replace_end. Раньше это были
// два почти идентичных блока по 25 строк, отличающихся лишь stage и иконкой.
function replaceTimeAction(stage) {
  return async (ctx) => {
    await ctx.answerCbQuery();
    const profile = await ensureProfile(ctx);
    if (!profile) return;

    try {
      const result = await replaceTime(profile.fio, profile.workplace, stage);

      if (result.notFound) {
        await ctx.replyWithHTML(formatNoSheetMessage(result, profile.workplace));
        return;
      }

      console.log('время записано', `replace_${stage}`);
      clearState(ctx.from.id);
      const icon = stage === 'start' ? '🟢' : '🔴';
      const label = stage === 'start' ? 'Старт' : 'Конец';
      await ctx.replyWithHTML(
        `${icon} <b>${label} смены</b> заменён: <code>${esc(result.timeValue)}</code>`,
        getMenuForRole(ctx.from.id)
      );
    } catch (error) {
      console.error('ошибка Google Sheets', error);
      await ctx.replyWithHTML('⚠️ Не удалось записать время.\nПопробуйте ещё раз или обратитесь к администратору.');
    }
  };
}

bot.action('replace_start', replaceTimeAction('start'));
bot.action('replace_end', replaceTimeAction('end'));

bot.action('skip_mileage', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);
  const savedMileage = state?.savedMileage;

  if (state?.mileageProcessing) {
    setState(ctx.from.id, { ...state, mileageProcessing: false, awaitingMileagePhoto: false, awaitingManualMileage: false });
    clearState(ctx.from.id);
    await ctx.replyWithHTML('⏭️ Обработка фото отменена.', getMenuForRole(ctx.from.id));
    return;
  }

  if (savedMileage) {
    clearState(ctx.from.id);
    await ctx.replyWithHTML('⬅️ Возвращаю в меню.', getMenuForRole(ctx.from.id));
    return;
  }

  await ctx.replyWithHTML(
    '⚠️ <b>Пропустить пробег?</b>\n\nПробег не будет записан в таблицу.',
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ Да, пропустить', 'confirm_skip_mileage')],
      [Markup.button.callback('❌ Отмена', 'cancel_skip_mileage')]
    ])
  );
});

bot.action('confirm_skip_mileage', async (ctx) => {
  await ctx.answerCbQuery('⏭️ Пропущено');
  clearState(ctx.from.id);
  console.log('пропуск пробега подтверждён');
  await ctx.replyWithHTML('⏭️ Пробег пропущен.', getMenuForRole(ctx.from.id));
});

bot.action('cancel_skip_mileage', async (ctx) => {
  await ctx.answerCbQuery('Отменено');
  try { await ctx.deleteMessage(); } catch {}
});

bot.action('edit_mileage', async (ctx) => {
  await ctx.answerCbQuery();
  const state = getState(ctx.from.id);

  if (!state?.mileageRow || !state?.day || !state?.stage) {
    await ctx.replyWithHTML(`⚠️ Сначала нажмите «${BUTTONS.mileage}».`, getMenuForRole(ctx.from.id));
    return;
  }

  setState(ctx.from.id, { ...state, mileageProcessing: false, awaitingManualMileage: true, awaitingMileagePhoto: false });
  await ctx.replyWithHTML('✏️ <b>Ввод пробега вручную</b>\n\nВведите пробег только цифрами или загрузите фото повторно.', manualMileageKeyboard());
});

async function handleRouteSheetPhoto(ctx, state, fileId) {
  const telegramId = ctx.from.id;
  console.log('фото маршрутного листа получено');
  const date = getTodayText();
  const routeSheetNumber = getNextRouteSheetNumber(state, date);
  logRouteSheetPhoto(telegramId, fileId, state, date, routeSheetNumber);

  try {
    const forwarded = await sendPhotoToRouteSheetChat(ctx, fileId, buildRouteSheetCaption(state, routeSheetNumber));

    if (!forwarded) {
      await ctx.replyWithHTML('⚠️ Временные проблемы с отправкой.\nСообщите администратору.', routeSheetKeyboard());
      return;
    }

    await ctx.replyWithHTML(`✅ <b>Маршрутный лист №${routeSheetNumber}</b> отправлен.\n\nМожно отправить ещё одно фото.`, routeSheetKeyboard());
  } catch (error) {
    console.error('telegram send route sheet photo error', error);
    await ctx.replyWithHTML('⚠️ Не удалось отправить фото.\nПопробуйте ещё раз или обратитесь к администратору.', routeSheetKeyboard());
  }
}

async function finalizeReconciliationPostSend(ctx, state, telegramId, totalOrders) {
  const errors = [];

  if (totalOrders && totalOrders > 0 && state.fio && state.workplace) {
    const timezone = process.env.APP_TIMEZONE || 'Europe/Moscow';
    const { day } = getCurrentDateInfo(timezone);

    try {
      const result = await updateEfficiencyOrders(state.fio, state.workplace, day, totalOrders);
      if (result.ok) {
        console.log(`эффективность: записано ${totalOrders} заказов для ${state.fio}, день ${day}, ячейка ${result.cell}`);
      } else {
        console.error('эффективность: не удалось записать', result.error);
        errors.push('заказы в таблицу эффективности');
      }
    } catch (effError) {
      console.error('эффективность: ошибка записи', effError.message || effError);
      errors.push('заказы в таблицу эффективности');
    }

    try {
      const dayKey = getLbTodayKey();
      const oldOrders = getLbDayOrders(String(telegramId), dayKey);
      const profileLb = getFullProfile(telegramId);
      recordLeaderboardOrders(String(telegramId), state.fio, state.workplace, totalOrders, profileLb.courierType);
      await handleLeaderboardNotifications(ctx, String(telegramId), state.fio, state.workplace, totalOrders, oldOrders);
      addXp(telegramId, getXpForAction('reconciliation'), 'Сверка');
      updateChallengeProgress(telegramId, 'reconciliations');
    } catch (lbErr) {
      console.error('leaderboard record error', lbErr.message || lbErr);
      errors.push('рейтинг');
    }
  }

  if (errors.length > 0) {
    try {
      await ctx.replyWithHTML(
        `⚠️ <b>Фото отправлены, но не удалось записать:</b>\n` +
        errors.map((e) => `• ${esc(e)}`).join('\n') +
        '\n\nСообщите администратору.',
        getMenuForRole(telegramId)
      );
    } catch (notifyErr) {
      console.error('failed to notify user about reconciliation errors', notifyErr.message);
    }
  }
}

async function handleReconciliationPhoto(ctx, state, fileId) {
  const telegramId = ctx.from.id;
  const photosSent = (state.reconciliationPhotosSent || 0) + 1;
  const total = state.reconciliationTotal || 1;
  const isTerminal = state.device === 'Терминал';
  const isTerminalFirstPhoto = isTerminal && photosSent === 1;

  if (isTerminalFirstPhoto) {
    const cashInfo = await recognizeReconciliationCashSafe(ctx, fileId, 'terminal_first_photo');
    const shouldAttachCash = cashInfo.valid && Number(cashInfo.amount) >= 1 && Number(cashInfo.orders) > 0;
    const cashFormatted = shouldAttachCash ? formatMoneyRu(cashInfo.amount) : null;

    const captionLines = [
      `📊 Сверки — Терминал (статистика)`,
      `👤 ${esc(getEmployeeDisplayName(state.fio))}`,
      `🏬 ${esc(state.workplace || 'не указано')}`
    ];

    if (shouldAttachCash && cashFormatted) {
      const rawAmount = Number(cashInfo.amount);
      if (!Number.isFinite(rawAmount) || rawAmount < 1 || rawAmount > MAX_REASONABLE_CASH_AMOUNT) {
        console.log('сверка OCR: сумма наличных вне допустимого диапазона', rawAmount);
      } else {
        const previousPending = getPendingCash(telegramId);
        const previousAmount = Number(previousPending?.amount || 0);
        const totalAmount = roundMoney(
          Number.isFinite(previousAmount) && previousAmount >= 1
            ? previousAmount + rawAmount
            : rawAmount
        );
        const totalFormatted = formatMoneyRu(totalAmount);
        const currentNumberOnly = formatMoneyRuNumber(rawAmount) || String(cashFormatted).replace(/\s*₽$/, '');

        captionLines.push(`💵 К сдаче в следующую смену: <code>${esc(currentNumberOnly)}</code> ₽`);

        setPendingCash(telegramId, {
          amount: totalAmount,
          formatted: totalFormatted,
          orders: cashInfo.orders,
          workplace: state.workplace || null,
          sourceLabel: 'Терминал',
          updatedAt: new Date().toISOString(),
          fileId
        });
      }
    }

    const caption = truncateCaption(captionLines.join('\n'));

    console.log('фото сверок получено', `${photosSent}/${total}`, '(статистика)');
    logReconciliationPhoto(telegramId, fileId, state, 'Терминал (статистика)');
    appendLog(reconciliationLogPath, {
      at: new Date().toISOString(),
      type: 'cash_detection',
      telegramId,
      fileId,
      workplace: state?.workplace || null,
      label: 'Терминал (статистика)',
      cashOrders: cashInfo.orders,
      cashAmount: cashInfo.amount,
      totalOrders: cashInfo.totalOrders,
      cashApplied: Boolean(shouldAttachCash),
      reason: cashInfo.reason || null
    });

    setState(telegramId, {
      ...state,
      reconciliationPhotosSent: photosSent,
      reconciliationPhoto1FileId: fileId,
      reconciliationPhoto1Caption: caption,
      reconciliationPhoto1TotalOrders: cashInfo.totalOrders || null,
      reconciliationPhoto1OcrReason: cashInfo.reason || null
    });

    await ctx.replyWithHTML(
      `✅ Фото <b>1</b> из <b>2</b> (статистика) получено.\n\n` +
      `📷 Теперь отправьте фото <b>2 из 2</b>: <b>🧾 Чек</b>`,
      routeSheetKeyboard()
    );
    return;
  }

  if (isTerminal && photosSent === 2) {
    console.log('фото сверок получено', `${photosSent}/${total}`, '(чек)');
    logReconciliationPhoto(telegramId, fileId, state, 'Терминал (чек)');
    appendLog(reconciliationLogPath, {
      at: new Date().toISOString(),
      type: 'cash_detection',
      telegramId,
      fileId,
      workplace: state?.workplace || null,
      label: 'Терминал (чек)',
      cashOrders: 0,
      cashAmount: 0,
      cashApplied: false,
      reason: 'чек — OCR пропущен'
    });

    const photo1FileId = state.reconciliationPhoto1FileId;
    const photo1Caption = state.reconciliationPhoto1Caption || '';

    try {
      const forwarded = await sendMediaGroupToReconciliationChat(ctx, [
        { fileId: photo1FileId, caption: photo1Caption },
        { fileId, caption: '' }
      ]);

      if (!forwarded) {
        await ctx.replyWithHTML('⚠️ Временные проблемы с отправкой.\nСообщите администратору.', routeSheetKeyboard());
        return;
      }

      clearState(telegramId);
      const ocrWarning = !state.reconciliationPhoto1TotalOrders && state.reconciliationPhoto1OcrReason
        ? `\n\n⚠️ OCR не распознал заказы/наличные. Фото отправлены, но данные не записаны автоматически.`
        : '';
      await ctx.replyWithHTML(`✅ <b>Все фото (2 шт.) отправлены.</b>${ocrWarning}`, getMenuForRole(ctx.from.id));

      const totalOrders = state.reconciliationPhoto1TotalOrders;
      await finalizeReconciliationPostSend(ctx, state, telegramId, totalOrders);
    } catch (error) {
      console.error('telegram send reconciliation album error', error);
      await ctx.replyWithHTML('⚠️ Не удалось отправить фото.\nПопробуйте ещё раз или обратитесь к администратору.', routeSheetKeyboard());
    }
    return;
  }

  const label = 'Пин-Панель';
  const cashInfo = await recognizeReconciliationCashSafe(ctx, fileId, 'pin_panel');
  const shouldAttachCash = cashInfo.valid && Number(cashInfo.amount) >= 1 && Number(cashInfo.orders) > 0;
  const cashFormatted = shouldAttachCash ? formatMoneyRu(cashInfo.amount) : null;

  const captionLines = [
    `📊 Сверки — ${esc(label)}`,
    `👤 ${esc(getEmployeeDisplayName(state.fio))}`,
    `🏬 ${esc(state.workplace || 'не указано')}`
  ];

  if (shouldAttachCash && cashFormatted) {
    const rawAmount = Number(cashInfo.amount);
    if (!Number.isFinite(rawAmount) || rawAmount < 1 || rawAmount > MAX_REASONABLE_CASH_AMOUNT) {
      console.log('сверка OCR: сумма наличных вне допустимого диапазона', rawAmount);
    } else {
      const previousPending = getPendingCash(telegramId);
      const previousAmount = Number(previousPending?.amount || 0);
      const totalAmount = roundMoney(
        Number.isFinite(previousAmount) && previousAmount >= 1
          ? previousAmount + rawAmount
          : rawAmount
      );
      const totalFormatted = formatMoneyRu(totalAmount);
      const currentNumberOnly = formatMoneyRuNumber(rawAmount) || String(cashFormatted).replace(/\s*₽$/, '');

      captionLines.push(`💵 К сдаче в следующую смену: <code>${esc(currentNumberOnly)}</code> ₽`);

      setPendingCash(telegramId, {
        amount: totalAmount,
        formatted: totalFormatted,
        orders: cashInfo.orders,
        workplace: state.workplace || null,
        sourceLabel: label,
        updatedAt: new Date().toISOString(),
        fileId
      });
    }
  }

  const caption = truncateCaption(captionLines.join('\n'));

  console.log('фото сверок получено', `${photosSent}/${total}`);
  logReconciliationPhoto(telegramId, fileId, state, label);
  appendLog(reconciliationLogPath, {
    at: new Date().toISOString(),
    type: 'cash_detection',
    telegramId,
    fileId,
    workplace: state?.workplace || null,
    label,
    cashOrders: cashInfo.orders,
    cashAmount: cashInfo.amount,
    totalOrders: cashInfo.totalOrders,
    cashApplied: Boolean(shouldAttachCash),
    reason: cashInfo.reason || null
  });

  try {
    const forwarded = await sendPhotoToReconciliationChat(ctx, fileId, caption);

    if (!forwarded) {
      await ctx.replyWithHTML('⚠️ Временные проблемы с отправкой.\nСообщите администратору.', routeSheetKeyboard());
      return;
    }

    clearState(telegramId);
    const ocrWarning = shouldWarnAboutReconciliationOcr(cashInfo)
      ? `\n\n⚠️ OCR не распознал заказы/наличные. Фото отправлено, но данные не записаны автоматически.`
      : '';
    await ctx.replyWithHTML(`✅ <b>Все фото (${total} шт.) отправлены.</b>${ocrWarning}`, getMenuForRole(ctx.from.id));

    const totalOrders = cashInfo.totalOrders;
    await finalizeReconciliationPostSend(ctx, state, telegramId, totalOrders);
  } catch (error) {
    console.error('telegram send reconciliation photo error', error);
    await ctx.replyWithHTML('⚠️ Не удалось отправить фото.\nПопробуйте ещё раз или обратитесь к администратору.', routeSheetKeyboard());
  }
}

async function handleMileagePhoto(ctx, state, fileId) {
  const telegramId = ctx.from.id;
  console.log('фото получено');
  logMileagePhoto(telegramId, fileId, state);

  const photoState = {
    ...state,
    awaitingMileagePhoto: false,
    awaitingManualMileage: false,
    photoReceived: true,
    fileId,
    mileageProcessing: true
  };
  setState(telegramId, photoState);

  const ocrAvailable = isRapidOcrEnabled();
  if (!ocrAvailable) {
    setState(telegramId, {
      ...photoState,
      mileageProcessing: false,
      awaitingMileagePhoto: true,
      awaitingManualMileage: true,
      recognizedMileage: null,
      ocrValue: null
    });
    sendPhotoToWorkChat(ctx, fileId, buildPhotoCaption(state)).catch((error) => {
      console.error('telegram send photo error', error);
    });
    await ctx.replyWithHTML('⚠️ Авто-распознавание сейчас недоступно.\nВведите пробег вручную или нажмите «⏭️ Пропустить».', mileageConfirmKeyboard());
    return;
  }

  const ocrHealthy = await checkRapidOcrHealth();
  if (!ocrHealthy) {
    console.warn('RapidOCR health check failed, falling back to manual input');
    setState(telegramId, {
      ...photoState,
      mileageProcessing: false,
      awaitingMileagePhoto: true,
      awaitingManualMileage: true,
      recognizedMileage: null,
      ocrValue: null
    });
    sendPhotoToWorkChat(ctx, fileId, buildPhotoCaption(state)).catch((error) => {
      console.error('telegram send photo error', error);
    });
    await ctx.replyWithHTML('⚠️ Сервер распознавания недоступен.\nВведите пробег вручную или нажмите «⏭️ Пропустить».', mileageConfirmKeyboard());
    return;
  }

  await ctx.replyWithHTML('📸 Фото принято. Считываю пробег...');

  const chatId = ctx.chat.id;
  const telegram = ctx.telegram;

  const MILEAGE_TIMEOUT_MS = 45000;

  const bgPromise = processMileagePhotoInBackground(telegram, chatId, telegramId, photoState, fileId, photoState);

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error(' mileage processing timeout')), MILEAGE_TIMEOUT_MS)
  );

  Promise.race([bgPromise, timeoutPromise]).catch((err) => {
    console.error('mileage bg error:', err.message);
    if (err.message && err.message.includes('timeout')) {
      telegram.sendMessage(chatId, '⚠️ Превышено время распознавания. Введите пробег вручную или нажмите «⏭️ Пропустить».', { parse_mode: 'HTML' }).catch(() => {});
    }
  });
}

async function processMileagePhotoInBackground(telegram, chatId, telegramId, originalState, fileId, photoState) {
  const sendMsg = async (html, extra) => {
    try {
      await telegram.sendMessage(chatId, html, { parse_mode: 'HTML', ...(extra || {}) });
    } catch (e) {
      console.error('background sendMsg error', e.message);
    }
  };

  try {
    console.log('mileage bg: start processing', { telegramId, fileId });

    const [recognitionOptions] = await Promise.all([
      buildMileageRecognitionOptions(originalState),
      forwardPhoto({ telegram }, fileId, buildPhotoCaption(originalState), 'work').catch((error) => {
        console.error('telegram send photo error', error);
      })
    ]);
    console.log('mileage bg: recognition options built', recognitionOptions);

    const sourceBuffer = await downloadTelegramFile({ telegram }, fileId);
    console.log('mileage bg: file downloaded', { size: sourceBuffer?.length });

    const ocrResult = await recognizeMileage({ telegram, chat: { id: chatId } }, fileId, {
      ...recognitionOptions,
      sourceBuffer,
      onStatus: async (msg) => {
        try { await sendMsg(msg); } catch (e) { /* ignore */ }
      }
    });

    const mileageValue = ocrResult?.mileage || null;
    const ocrCandidates = ocrResult?.candidates || [];
    console.log('mileage bg: OCR result', { mileageValue, candidateCount: ocrCandidates.length });

    if (!mileageValue) {
      if (sourceBuffer) {
        saveOcrDebugImage(sourceBuffer, {
          status: ocrCandidates.length > 0 ? 'ocr_weak' : 'ocr_fail',
          ocrResult: ocrCandidates.length > 0 ? ocrCandidates[0].mileage : null,
          userCorrectedValue: null,
          telegramId,
          stage: originalState.stage,
          workplace: originalState.workplace,
          fio: originalState.fio,
          fileId
        });
      }

      const cs = getState(telegramId);
      if (cs?.fileId === fileId) {
        setState(telegramId, {
          ...photoState,
          mileageProcessing: false,
          awaitingMileagePhoto: true,
          awaitingManualMileage: true,
          recognizedMileage: null,
          ocrValue: null
        });
      }

      let failMsg = '⚠️ <b>Не удалось распознать пробег</b>\n\n';
      if (ocrCandidates.length > 0) {
        const candidateList = ocrCandidates.slice(0, 3).map((c) => `<code>${c.mileage}</code> км`).join(', ');
        failMsg += `Возможные значения: ${candidateList}\n\n`;
      }
      failMsg += 'Отправьте фото повторно крупным планом, введите вручную или нажмите «⏭️ Пропустить».';
      await sendMsg(failMsg, mileageConfirmKeyboard());
      return;
    }

    // OCR успешно распознал — сохраняем в любом случае, даже если пользователь
    // нажимал кнопки во время обработки. Используем originalState как fallback.
    await saveMileageFromState(
      { from: { id: telegramId }, telegram, replyWithHTML: sendMsg },
      mileageValue,
      { sourceBuffer, telegram, chatId, fallbackState: originalState }
    );
  } catch (error) {
    console.error('background mileage processing error', error);
    await sendMsg('⚠️ <b>Ошибка обработки фото</b>\nПопробуйте ещё раз.', mileageConfirmKeyboard());
  } finally {
    const cs = getState(telegramId);
    if (cs && cs.fileId === fileId && cs.mileageProcessing) {
      setState(telegramId, {
        ...cs,
        mileageProcessing: false,
        awaitingMileagePhoto: true,
        awaitingManualMileage: true
      });
    }
  }
}

bot.on('photo', async (ctx) => {
  if (isLogist(ctx.from.id)) {
    await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
    return;
  }
  const telegramId = ctx.from.id;
  const state = getState(telegramId);

  const photos = ctx.message.photo;
  const bestPhoto = photos[photos.length - 1];
  const fileId = bestPhoto.file_id;

  if (state?.awaitingRouteSheetPhoto) {
    return handleRouteSheetPhoto(ctx, state, fileId);
  }

  if (state?.awaitingReconciliationPhoto) {
    return handleReconciliationPhoto(ctx, state, fileId);
  }

  if (!state?.awaitingMileagePhoto) {
    await ctx.replyWithHTML(`⚠️ Сначала нажмите «${BUTTONS.mileage}».`, getMenuForRole(ctx.from.id));
    return;
  }

  return handleMileagePhoto(ctx, state, fileId);
});

async function handleManualTime(ctx, state, text) {
  const telegramId = ctx.from.id;
  const timeValue = normalizeTimeValue(text);

  if (!timeValue) {
    await ctx.replyWithHTML(
      '❌ Неверный формат времени.\n\n' +
      'Поддерживаются: <code>7</code>, <code>7,5</code>, <code>07:30</code>, <code>08:46</code>, <code>08.46</code>, <code>8 14</code> (часы 0–24).\n' +
      'Минуты округляются до ближайших 30.'
    );
    return;
  }

  try {
    await updateCourierTime(state.courierRow, state.day, state.stage, timeValue, state.workplace);
    clearState(telegramId);
    console.log('время изменено', state.stage);
    const icon = state.stage === 'start' ? '🟢' : '🔴';
    const label = state.stage === 'start' ? 'Старт' : 'Конец';
    await ctx.replyWithHTML(`${icon} <b>${label} смены</b> изменён: <code>${esc(timeValue)}</code>`, getMenuForRole(ctx.from.id));
  } catch (error) {
    console.error('ошибка Google Sheets', error);
    await ctx.replyWithHTML('⚠️ Не удалось изменить время.\nПопробуйте ещё раз или обратитесь к администратору.');
  }
}

async function requireFio(ctx) {
  const fio = getUserField(ctx.from.id, 'fio');
  if (!fio) {
    await askForFio(ctx);
    return null;
  }
  return fio;
}

// ─── Хендлеры, вынесенные из bot.on('text') для читабельности ───

async function handleSwitchUser(ctx, state, text, telegramId) {
  setState(telegramId, { awaitingSwitchUser: true });
  await ctx.replyWithHTML(
    '⚠️ <b>Смена сотрудника</b>\n\nВсе данные (ФИО, номер машины, магазин, устройство) будут удалены.\n\nВы уверены?',
    switchUserKeyboard()
  );
}

async function handleSheetsInfo(ctx, state, text, telegramId) {
  const hasAccess = isAdminUser(telegramId) || isSheetAccessUser(telegramId) || getUserRole(telegramId) === 'logist';
  if (!hasAccess) {
    // Раньше предлагали «нажмите Мой ID», но эта кнопка спрятана в
    // подменю Управление — пользователь не знал куда идти. Теперь
    // inline-кнопка прямо здесь.
    await ctx.replyWithHTML(
      '⛔ У вас нет доступа к этому разделу.\n\n' +
      'Получите ваш Telegram ID и отправьте его администратору.',
      Markup.inlineKeyboard([
        [Markup.button.callback('🆔 Получить мой ID', 'show_my_id')]
      ])
    );
    return;
  }
  const cm = getCurrentMonthKey();
  const nm = getNextMonthKey();
  let msg = `📋 <b>Привязка таблиц</b>\n\n🗓 Активный месяц: <code>${cm}</code>\n🗓 Следующий месяц: <code>${nm}</code>\n\n`;
  for (const wp of WORKPLACES) {
    const info = resolveSheetInfo(wp);
    const activeId = getWorkplaceSheetIdByMonth(wp, cm);
    const nextId = getWorkplaceSheetIdByMonth(wp, nm);
    msg += `🏬 <b>${esc(wp)}</b>\n`;
    msg += `   Текущий: ${activeId ? '✅ привязана' : '❌ нет'}\n`;
    msg += `   Следующий: ${nextId ? '✅ привязана' : '❌ нет'}\n`;
    msg += `   Источник: ${esc(info.source)}\n\n`;
  }
  msg += `<b>Команды:</b>\n`;
  msg += `<code>/sheet east URL</code> — привязать для ИМ Восток\n`;
  msg += `<code>/sheet center URL</code> — привязать для ИМ Центр\n`;
  msg += `<code>/sheet east active URL</code> — на текущий месяц\n`;
  msg += `<code>/sheet east next URL</code> — на следующий\n`;
  msg += `<code>/sheet</code> — подробный список`;
  await ctx.replyWithHTML(msg);
}

async function handleMyId(ctx) {
  const userId = ctx.from.id;
  const firstName = ctx.from.first_name || '';
  const lastName = ctx.from.last_name || '';
  const username = ctx.from.username ? `@${ctx.from.username}` : '';
  const displayName = [firstName, lastName].filter(Boolean).join(' ') || 'Без имени';

  await ctx.replyWithHTML(
    `🆔 <b>Ваш Telegram ID:</b> <code>${userId}</code>\n\n` +
    'Сообщите этот ID администратору для получения доступа к разделу «📋 Таблицы».'
  );

  await notifyAdmins(
    `🆔 <b>Запрос доступа к Таблицам</b>\n\n` +
    `👤 ${esc(displayName)} ${esc(username)}\n` +
    `🆔 <code>${userId}</code>\n\n` +
    `Дать доступ: <code>/sheet_access ${userId}</code>`
  );
}

async function handleUpdateEditText(ctx, state, text) {
  if (!isAdminUser(ctx.from.id)) {
    clearState(ctx.from.id);
    return;
  }
  const editVersion = state.editVersion;
  const pending = _pendingUpdates[editVersion];
  clearState(ctx.from.id);
  if (!pending) {
    await ctx.replyWithHTML('⚠️ Обновление уже обработано или устарело.');
    return;
  }
  const customHighlights = text.split('\n').map((l) => l.trim()).filter(Boolean).slice(0, 4);
  const fullMessage = (
    `🆕 <b><i>Обновление бота v${esc(editVersion)}</i></b>\n\n` +
    '<b>Коротко, что изменили:</b>\n' +
    customHighlights.map((item) => `• ${esc(item)}`).join('\n') +
    '\n\n💙 Хорошей смены!'
  );
  _pendingUpdates[editVersion] = { ...pending, message: fullMessage };
  savePendingUpdates();
  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('✅ Отправить', `upd_send:${editVersion}`),
      Markup.button.callback('✏️ Изменить текст', `upd_edit:${editVersion}`)
    ],
    [Markup.button.callback('⏭️ Пропустить', `upd_skip:${editVersion}`)]
  ]);
  await ctx.replyWithHTML('<b>Предпросмотр:</b>\n\n' + fullMessage, keyboard);
}

async function handleManualMileageInput(ctx, state, text) {
  if (!/^\d{2,6}$/.test(text)) {
    await ctx.replyWithHTML('❌ Введите пробег от <b>2 до 6 цифр</b>.\n\nНапример: <code>25408</code>', manualMileageKeyboard());
    return;
  }
  await saveMileageFromState(ctx, Number(text));
}

// ─── Dispatcher для bot.on('text') ───
// Каждая запись описывает один маршрут. Раньше всё это было ifelse'ами
// длиной в 200+ строк — теперь сразу видно, кто что обрабатывает.
//
// Поля:
//   match(text, state) → bool — кастомное условие (выполняется ПЕРВЫМ если есть)
//   state: 'awaitingFoo' — выполняется при state.awaitingFoo === true
//   button: BUTTONS.foo — точное совпадение текста
//   legacy: ['Старый текст', ...] — алиасы для обратной совместимости
//   handler: (ctx, state, text, telegramId) → Promise
//
// Порядок ВАЖЕН: state-маршруты должны быть выше button-маршрутов,
// чтобы юзер при заполнении формы не «выпадал» в меню.

const TEXT_ROUTES = [
  // 1) «Назад в меню» — общая кнопка
  { match: (text) => ['🏠 В меню', '⬅️ Назад', 'Назад'].includes(text) || text === BUTTONS.back, handler: (ctx) => backToMainMenu(ctx) },

  // 2) State-based: пользователь сейчас что-то вводит
  { state: 'awaitingCarNumber', handler: (ctx, s, text) => saveCarNumber(ctx, text) },
  { state: 'awaitingWorkplace', handler: (ctx, s, text) => saveWorkplace(ctx, text) },
  { state: 'awaitingDevice', handler: (ctx, s, text) => saveDevice(ctx, text) },
  { state: 'awaitingFio', handler: (ctx, s, text) => authorizeFio(ctx, text) },
  { state: 'awaitingRoleChoice', handler: (ctx) => ctx.replyWithHTML('⚠️ Выберите роль кнопкой выше.', roleChoiceKeyboard()) },
  { state: 'awaitingManualTime', handler: (ctx, state, text) => handleManualTime(ctx, state, text) },
  { state: 'awaitingUpdateEdit', handler: (ctx, state, text) => handleUpdateEditText(ctx, state, text) },
  { state: 'awaitingManualMileage', handler: (ctx, state, text) => handleManualMileageInput(ctx, state, text) },

  // 3) Кнопки главного меню
  { button: BUTTONS.punchTime, legacy: ['Время смены', 'Внести время смены', '⏱ Время'], handler: (ctx) => punchTimeFlow(ctx) },
  { button: BUTTONS.mileage, legacy: ['Внести пробег', '🚗 Пробег'], handler: (ctx) => mileageFlow(ctx) },
  { button: BUTTONS.routeSheet, legacy: ['Маршрутный лист', '📄 Маршрутник'], handler: (ctx) => routeSheetFlow(ctx) },
  { button: BUTTONS.reconciliation, legacy: ['Сверки', '📊 Сверки'], handler: (ctx) => reconciliationFlow(ctx) },
  { button: BUTTONS.cashCheck, legacy: ['Деньги к сдаче', '💵 Наличные'], handler: (ctx) => showPendingCashStatus(ctx) },
  { button: BUTTONS.issues, legacy: ['Проблема с заказом', '⚠️ Проблема'], handler: (ctx) => showIssuesMenu(ctx) },
  { button: BUTTONS.leaderBoard, legacy: ['Лидерборд', '🏆 Лидерборд'], handler: (ctx) => showLeaderboardMenu(ctx) },
  { button: BUTTONS.cashCollect, handler: (ctx) => showDebtorsList(ctx) },
  { button: BUTTONS.openShop, handler: (ctx) => openShopNotify(ctx) },

  // 4) Меню настроек
  { button: BUTTONS.settings, legacy: ['Настройки'], handler: async (ctx, s, text, id) => ctx.replyWithHTML('⚙️ <b>Настройки</b>', getSettingsMenuForRole(id)) },
  { button: BUTTONS.profile, legacy: ['Профиль'], handler: async (ctx, s, text, id) => ctx.replyWithHTML('✏️ <b>Профиль</b>', getProfileMenuForRole(ctx.from.id)) },
  { button: BUTTONS.help, legacy: ['Помощь'], handler: (ctx) => sendHelp(ctx) },

  // 5) Профиль (требуют ФИО)
  { button: BUTTONS.changeCar, legacy: ['Изменить номер машины', 'Номер машины'], handler: async (ctx) => {
    if (isLogist(ctx.from.id)) {
      await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
      return;
    }
    const fio = await requireFio(ctx);
    if (fio) await askForCarNumber(ctx, fio);
  }},
  { button: BUTTONS.changeWorkplace, legacy: ['Изменить интернет-магазин', 'Поменять магазин', 'Магазин'], handler: async (ctx) => {
    const fio = await requireFio(ctx);
    if (fio) await askForWorkplace(ctx, fio);
  }},
  { button: BUTTONS.changeDevice, legacy: ['Изменить устройство', 'Устройство'], handler: async (ctx) => {
    if (isLogist(ctx.from.id)) {
      await ctx.replyWithHTML('❌ Эта функция доступна только курьерам.', getMenuForRole(ctx.from.id));
      return;
    }
    const fio = await requireFio(ctx);
    if (fio) await askForDevice(ctx, fio);
  }},
  { button: BUTTONS.switchUser, legacy: ['Поменять сотрудника', 'Сменить сотрудника', 'Сотрудник'], handler: handleSwitchUser },

  // 6) Настройки (Таблицы, Мой ID, История сборов)
  { button: BUTTONS.sheetInfo, legacy: ['Таблицы'], handler: handleSheetsInfo },
  { button: BUTTONS.myId, legacy: ['Мой ID'], handler: handleMyId },
  { button: BUTTONS.cashHistory, handler: (ctx) => showCashHistory(ctx) }
];

function matchTextRoute(route, text, state) {
  if (typeof route.match === 'function' && route.match(text, state)) return true;
  if (route.state && state?.[route.state]) return true;
  if (route.button) {
    if (text === route.button) return true;
    if (Array.isArray(route.legacy) && route.legacy.includes(text)) return true;
  }
  return false;
}

bot.on('text', async (ctx) => {
  const telegramId = ctx.from.id;
  const text = ctx.message.text.trim();
  const state = getState(telegramId);

  for (const route of TEXT_ROUTES) {
    if (matchTextRoute(route, text, state)) {
      return route.handler(ctx, state, text, telegramId);
    }
  }

  // Fallback: текст не подошёл ни под одну ветку
  await ctx.replyWithHTML('Выберите действие в меню или используйте /help.', getMenuForRole(telegramId));
});

bot.catch((error, ctx) => {
  console.error('bot error', error.message);
});

process.on('uncaughtException', (error) => {
  console.error('uncaught exception:', error);
  shutdown('uncaughtException');
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  console.error('unhandled rejection:', reason);
  shutdown('unhandledRejection');
  process.exit(1);
});

const LAUNCH_RETRIES = LIMITS.LAUNCH_RETRIES;
const LAUNCH_BASE_DELAY = LIMITS.LAUNCH_BASE_DELAY_MS;
const LAUNCH_MAX_DELAY = LIMITS.LAUNCH_MAX_DELAY_MS;

// Глобальные таймеры — храним, чтобы при ретрае не плодить дубликаты
let _backupInitialTimer = null;
let _backupIntervalTimer = null;

async function setupBotCommands() {
  try {
    await bot.telegram.setMyCommands([
      { command: 'start', description: 'Начать работу' },
      { command: 'help', description: 'Помощь' },
      { command: 'car', description: 'Изменить номер машины' },
      { command: 'workplace', description: 'Изменить магазин' },
      { command: 'device', description: 'Изменить устройство' },
      { command: 'cancel', description: 'Отмена' },
      { command: 'role', description: 'Сменить роль (админ)' }
    ], { scope: { type: 'all_private_chats' } });
  } catch (e) {
    console.error('setMyCommands private error', e.message);
  }

  // Чистим команды для групп/админов/дефолта (бот предназначен только для приватов)
  await Promise.all([
    bot.telegram.deleteMyCommands({ scope: { type: 'all_group_chats' } })
      .catch((e) => console.error('deleteMyCommands group error', e.message)),
    bot.telegram.deleteMyCommands({ scope: { type: 'all_chat_administrators' } })
      .catch((e) => console.error('deleteMyCommands admins error', e.message)),
    bot.telegram.deleteMyCommands()
      .catch((e) => console.error('deleteMyCommands default error', e.message))
  ]);
}

async function startBot(retry = 0) {
  if (process.env.BOT_DISABLED === 'true') {
    console.log('bot disabled — .env BOT_DISABLED=true');
    return;
  }
  try {
    const { version, changed, changedFiles, updates } = checkVersion();
    initGoogleSheets();
    const removedMonths = cleanupOldMonths();
    if (removedMonths > 0) {
      console.log(`cleaned up ${removedMonths} old month(s) from storage`);
    }

    // Автоматическая генерация челленджей для всех курьеров
    try {
      const allIds = getAllUserIds();
      let generated = 0;
      for (const id of allIds) {
        const role = getUserRole(id);
        if (role !== 'courier') continue;
        const profile = getFullProfile(id);
        if (!profile.courierType) continue;
        generateWeeklyChallenges(id, profile.courierType);
        generated++;
      }
      if (generated > 0) {
        console.log(`weekly challenges generated for ${generated} couriers`);
      }
    } catch (e) {
      console.error('weekly challenges generation error', e.message);
    }

    // ВАЖНО: в Telegraf 4 у bot.launch() нет коллбэка после старта — он
    // принимает options-объект. Раньше код внутри () => {...} никогда не
    // выполнялся, поэтому на проде не было setMyCommands и авто-бэкапов.
    // Теперь всё это вынесено наружу.

    // Команды Telegram и стикерпаки — fire-and-forget до launch
    setupBotCommands().catch((e) => console.error('setupBotCommands fatal', e.message));
    importConfiguredFunStickerSets({ telegram: bot.telegram }).catch((error) => {
      console.error('fun sticker import fatal', error.message || error);
    });

    // Бэкапы — только при первом запуске, чтобы ретраи не плодили таймеры
    if (retry === 0) {
      if (_backupInitialTimer) clearTimeout(_backupInitialTimer);
      if (_backupIntervalTimer) clearInterval(_backupIntervalTimer);
      _backupInitialTimer = setTimeout(() => {
        runBackupCycle().catch((e) => console.error('initial backup error', e.message));
      }, 5000);
      _backupIntervalTimer = setInterval(() => {
        runBackupCycle().catch((e) => console.error('backup cycle error', e.message));
      }, BACKUP_INTERVAL_MS);
      _backupInitialTimer.unref?.();
      _backupIntervalTimer.unref?.();
    }

    // Уведомление админам об обновлении — только при changed && первом запуске
    if (changed && retry === 0) {
      setTimeout(() => {
        askAdminsAboutUpdate(version, changedFiles, updates).catch((error) => {
          console.error('admin update ask fatal', error.message || error);
        });
      }, 3000);
    }

    // bot.launch() возвращает Promise, который резолвится только при stop().
    // НЕ ставим await — иначе всё, что после, не выполнится.
    bot.launch();
    console.log(`bot started v${version}${changed ? ' (updated)' : ''}`);
  } catch (error) {
    const delay = Math.min(LAUNCH_BASE_DELAY * Math.pow(2, retry), LAUNCH_MAX_DELAY);
    console.error(`bot launch error (attempt ${retry + 1}/${LAUNCH_RETRIES}):`, error?.message || error);
    if (retry < LAUNCH_RETRIES) {
      console.error(`retrying in ${delay / 1000}s ...`);
      setTimeout(() => startBot(retry + 1), delay);
    } else {
      console.error('max launch retries reached, exiting');
      process.exit(1);
    }
  }
}

startBot();

let _shutdownInProgress = false;

function flushAllSync() {
  try { flushStateNow(); } catch (e) { console.error('flushStateNow failed', e.message); }
  try { flushStorageNow(); } catch (e) { console.error('flushStorageNow failed', e.message); }
  try { flushFunReactionsNow(); } catch (e) { console.error('flushFunReactionsNow failed', e.message); }
  try { flushLeaderboardNow(); } catch (e) { console.error('flushLeaderboardNow failed', e.message); }
}

function shutdown(signal) {
  if (_shutdownInProgress) return;
  _shutdownInProgress = true;

  console.log(`shutdown initiated by ${signal}`);
  try {
    checkpoint();
  } catch (_) {}
  flushAllSync();

  try {
    makeBackupSync('pre-shutdown');
  } catch (e) {
    console.error('pre-shutdown backup failed', e.message);
  }

  try {
    bot.stop(signal);
  } catch (e) {
    console.error('bot.stop failed', e.message);
  }
}

function makeBackupSync(reason = 'auto') {
  const now = new Date();
  const ts = now.toISOString().replace(/[.:]/g, '-');
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
  try {
    checkpoint();
  } catch (_) {}
  for (const filename of BACKUP_FILES) {
    const src = path.join(__dirname, filename);
    const dst = path.join(BACKUP_DIR, `${filename.replace('.json', '')}-${reason}-${ts}.json`);
    try {
      if (fs.existsSync(src)) {
        fs.copyFileSync(src, dst);
      }
    } catch (_) {}
  }
}

process.once('SIGINT', () => shutdown('SIGINT'));
process.once('SIGTERM', () => shutdown('SIGTERM'));
// SIGUSR2 — pm2 graceful reload и nodemon restart. Без этого хука перезапуски
// в dev/staging могли терять in-memory state и недозаписанные данные.
process.once('SIGUSR2', () => shutdown('SIGUSR2'));
// beforeExit — последний шанс сохранить данные при штатном выходе.
process.on('beforeExit', () => {
  if (_shutdownInProgress) return;
  flushAllSync();
});
