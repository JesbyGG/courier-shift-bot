# Стиль кода и договорённости

## Общие правила

1. **Везде async/await**. Не используем цепочки `.then()` / `.catch()`.
2. **Обработка ошибок**: `try { ... } catch (e) { console.error('context:', e); }`
   - Пользователю показываем: `ctx.replyWithHTML('⚠️ Что-то пошло не так...')`
3. **HTML-разметка**: `replyWithHTML()` с тегами `<b>`, `<code>`, `<i>`.
   - Экранирование спецсимволов через `esc()` (определена в `bot.js`).
4. **Клавиатуры**:
   - Reply: `Markup.keyboard([['btn1', 'btn2'], ['btn3']]).resize()`
   - Inline: `Markup.inlineKeyboard([[Markup.button.callback('text', 'data')]])`
   - Все тексты кнопок — в `config.js BUTTONS`.
5. **Именованные функции**: `async function showDebtorsList(ctx) { ... }`, затем привязка через `bot.action('...', handler)`.
6. **Google Sheets**: всегда через `sheetsRequest()` с retry (до 3 попыток).
7. **SQLite**: prepared statements, transactions для атомарности.
8. **Конфигурация**: не хардкодить магические числа — использовать `config.js LIMITS`.
9. **Магазины**: не хардкодить 'ИМ Восток' / 'ИМ Центр' — использовать `WORKPLACES`, `WORKPLACE_KEY_MAP`, `WORKPLACE_FEATURES`.

## Форматирование денег

```javascript
function formatMoneyRu(amount) {
  // Пример: 12897.27 → "12 897,27"
  // Используется для отображения сумм в сообщениях
}
```

## Кодировка и локаль

- Часовой пояс: `process.env.APP_TIMEZONE || 'Europe/Moscow'`
- Даты: формат `DD.MM.YYYY` для отображения, `YYYY-MM-DD` для ключей
- ФИО: нормализация через `normalizeFio()` (ё→е, пробелы, lowerCase)

## Импорты

```javascript
const { Telegraf, Markup } = require('telegraf');
const { WORKPLACES, DEVICES, ROLES, LIMITS, WORKPLACE_FEATURES, WORKPLACE_KEY_MAP, BUTTONS } = require('./config');
```

## Функции-утилиты из utils.js

| Функция | Назначение |
|---------|------------|
| `normalizeFio(fio)` | Нормализация ФИО для сравнения |
| `normalizeFioWords(fio)` | Нормализация + сортировка слов |
| `getColumnLetter(n)` | Число → буква колонки (1→A, 27→AA) |
| `getCourierColumnsByDay(day)` | {startColumn, endColumn, hoursColumn} для курьеров |
| `getMileageColumnsByDay(day)` | {startColumn, endColumn, totalColumn} для пробега |
| `roundMinutesToHalfHour(h, m)` | Округление минут до 0,5 часа |
| `roundTimeToHalfHour(date)` | Округление Date до 0,5 часа |
| `getCurrentDateInfo(tz)` | {dateText, day, date} в нужном часовом поясе |
| `isEmptyCell(value)` | true для '', null, undefined. "0" и "1" НЕ пустые |
| `isScheduleMarker(value)` | true только для "1" (маркер графика) |

## Константы из config.js

```javascript
WORKPLACES = ['ИМ Восток', 'ИМ Центр']
DEVICES = ['Терминал', 'Пин-Панель']
ROLES = ['Курьер', 'Логист']
WORKPLACE_KEY_MAP = { 'ИМ Восток': 'east', 'ИМ Центр': 'center' }
WORKPLACE_FEATURES = {
  'ИМ Восток': { cashCollection: true, leaderboard: true },
  'ИМ Центр': { cashCollection: false, leaderboard: true }
}
LIMITS = {
  MAX_LOG_SIZE_BYTES: 52428800,
  MAX_OCR_FEEDBACK: 500,
  BACKUP_INTERVAL_MS: 3600000,
  BACKUP_RETENTION_MS: 604800000,
  FUN_REACTION_CLEANUP_INTERVAL_MS: 3600000,
  TELEGRAM_CAPTION_LIMIT: 1024,
  MILEAGE_MIN_DIGITS: 2,
  MILEAGE_MAX_DIGITS: 6,
  CAR_NUMBER_MIN_LENGTH: 4,
  CAR_NUMBER_MAX_LENGTH: 12,
  LAUNCH_RETRIES: 10,
  LAUNCH_BASE_DELAY_MS: 5000,
  LAUNCH_MAX_DELAY_MS: 120000
}
SHEET_TEMPLATE = {
  courier: { firstDayStartCol: 6, blockSize: 3, fioStartRow: 3 },
  mileage: { firstDayStartCol: 4, blockSize: 3, fioStartRow: 3 }
}
```
